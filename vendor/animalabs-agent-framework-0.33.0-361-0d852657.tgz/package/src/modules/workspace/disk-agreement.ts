/**
 * Physical disk-agreement evidence (P): for each mount and path, what disk held
 * when it last agreed with the workspace store, or what the module last wrote
 * there or adopted from it.
 *
 * P describes disk, and disk does not rewind with a branch switch, so P lives
 * in global chronicle records (RecordJournal) rather than branch state: after
 * a rollback selects an older tree, P still says what disk holds, and a
 * difference reads as a store-side change, never as a disk edit. Branch-local
 * intent — tombstones, store origin, conflicts — lives in BranchIntents and
 * rewinds with the tree.
 *
 * P is evidence about one directory, so each mount also records the identity of
 * the root that evidence was gathered under (sameRootIdentity says when two
 * name the same directory). A root that isn't that directory any more (an
 * unmounted drive whose mountpoint is now empty, a replaced directory) is an
 * unavailable mount, never a disk on which every file was deleted; only an
 * explicit acceptance takes it, and that starts its evidence afresh. A place,
 * where a walk stopped (`walks`), binds no root: it only says where the next
 * walk starts, in whatever directory the root is by then.
 *
 * Every transition is write-ahead (see reconcile.ts): an `intent` entry
 * (`pending`, with the prior value and the expected one) is durable before the
 * disk effect or tree adoption it announces, and the completion `set` is
 * appended only after that effect is durable. One tree adoption has no
 * intent: a drop, which removes the store's copy of a disk version the
 * workspace can't hold, forgets P first, so a crash before the removal leaves
 * P unknown, never a wrong adoption. A pending adoption resolves at its next
 * observation, by the tree. A pending disk effect resolves there only when
 * disk shows it didn't happen (the prior) or can't tell (`interrupted`, a
 * sticky conflict resolved explicitly, or by disk and the store coming to
 * agree); one that shows on disk is completed only by a push whose barriers
 * succeed, since its completion releases a draft's protection.
 */

import { AsyncLocalStorage } from 'node:async_hooks';
import { resolve } from 'node:path';
import type { JsStore } from '@animalabs/chronicle';
import { RecordJournal } from '../../record-journal.js';
import { Refusal, onlyTheHost } from './answers.js';

const UNTIL_REOPENED = "the workspace can't check its files against disk until its store is reopened";
const REOPEN = onlyTheHost('reopen it with a restart');

export class EvidenceUnavailable extends Refusal {
  constructor(readonly why: string) {
    super(`${UNTIL_REOPENED}: ${why}. ${REOPEN}`);
  }
}

export function rootUnreadable(err: EvidenceUnavailable): string {
  return `the root disk last agreed with can't be read until the store is reopened: ${err.why}. ${REOPEN}`;
}

export const callGate = new AsyncLocalStorage<{ passed: boolean }>();

/** Everything `stat` says about a file that can vouch for unchanged bytes. */
export interface Fingerprint {
  size: number;
  mtimeNs: string;
  ctimeNs: string;
  ino: string;
  dev: string;
  /** When the bytes were hashed (ms). Timestamps within 2 s of it can't vouch. */
  hashedAt: number;
}

/**
 * `mode`: the permission bits disk held (`st_mode & 0o777`). Evidence from
 * before modes were recorded, or recorded after the kernel refused a
 * widening of the workspace's own change, has none: a sync takes disk's mode
 * in.
 */
export type Agreed =
  | { kind: 'absent' }
  | { kind: 'content'; hash: string; size: number; fp?: Fingerprint; mode?: number };

export type Candidate = { kind: 'absent' } | { kind: 'content'; hash: string };

export interface Pending {
  kind: 'pending';
  /** What the module is about to do: change disk, or adopt disk into the tree. */
  effect: 'disk' | 'adopt';
  /** P before the intent (null: unknown). */
  prior: Agreed | null;
  expect: Candidate;
  /** Branch the intent was recorded on (an adoption's meaning is branch-relative). */
  branchId: string;
  /**
   * For a write whose plan gives the file a mode: the mode it saw (`from`)
   * and the one it gives (`to`); a write that creates the file records `to`
   * for both. A push that goes on as our own narrowing push, stopped before
   * its bytes, records that push's `from`, the old bytes' own mode, and the
   * store's mode now, or where the store records none, the mode the stopped
   * push narrowed to, whether or not it gives a mode itself. It narrows to
   * `from & to` before the bytes and widens to `to` after them, so a stop
   * leaves disk at one of those three, with the old bytes or the new, and
   * those are the push's own. A file that has setuid or setgid
   * when the write checks it loses them before the bytes too, a chmod that
   * keeps the permission bits it has then, so a stop after that chmod alone
   * leaves disk at the mode the write saw, less those bits.
   */
  modes?: { from: number; to: number };
}

export interface Interrupted {
  kind: 'interrupted';
  /** The values disk could have held after the interrupted effect. */
  candidates: Candidate[];
}

export type Physical = Agreed | Pending | Interrupted;

/**
 * Which directory a mount root is: its device and inode, and its birth time
 * in nanoseconds as the runtime reports it, where that is above zero and isn't
 * its ctime, as decimal strings.
 */
export interface RootIdentity {
  dev: string;
  ino: string;
  born?: string;
}

/** Whether two configured roots name the same path, whatever their spelling
 *  (a trailing slash, a relative form). A symlinked alias is another path. */
function sameRootPath(a: string, b: string): boolean {
  return resolve(a) === resolve(b);
}

/**
 * Whether the directory seen `now` is the one `recorded`: the same inode, and
 * not born after the recorded one where `now`'s filesystem keeps a birth time
 * fixed (`bornFixed`), since ext4 gives a directory made where one was removed
 * its inode again, while overlayfs gives a directory copied up from a lower
 * layer a later birth time under the same inode; and the same device, or the
 * same birth time on another device, since macOS can give a volume another
 * device number after a reboot. A birth time in whole seconds doesn't count
 * across devices: filesystems made in the same second can give their roots
 * one inode (2 on ext4) and one birth time.
 */
export function sameRootIdentity(recorded: RootIdentity, now: RootIdentity, bornFixed: boolean): boolean {
  if (recorded.ino !== now.ino || (bornFixed && bornLater(recorded, now))) return false;
  if (recorded.dev === now.dev) return true;
  return fractional(recorded.born) && recorded.born === now.born;
}

export function onlyDeviceDiffers(recorded: RootIdentity, now: RootIdentity, bornFixed: boolean): boolean {
  return !sameRootIdentity(recorded, now, bornFixed) && recorded.ino === now.ino && recorded.dev !== now.dev && !(bornFixed && bornLater(recorded, now));
}

function bornLater(recorded: RootIdentity, now: RootIdentity): boolean {
  return recorded.born !== undefined && now.born !== undefined && BigInt(now.born) > BigInt(recorded.born);
}

function fractional(born: string | undefined): boolean {
  return born !== undefined && !born.endsWith('000000000');
}

type JournalEntry =
  | { t: 'mount'; mount: string; root: string }
  /** The root's identity; with `reset`, an accepted new root, whose evidence starts empty. */
  | { t: 'root'; mount: string; identity: RootIdentity; reset?: true }
  | { t: 'set'; mount: string; path: string; value: Physical }
  | { t: 'forget'; mount: string; path: string }
  /**
   * Where a capped walk of `scope` stopped (the last entry it took), or null
   * once a walk covered the scope. It carries no `path` field: agent-framework
   * 0.22 replays an entry it doesn't know as a `forget` of `entry.path`, and
   * so leaves the evidence alone when there is none.
   */
  | { t: 'walk'; mount: string; scope: string; after: string | null };

interface MountEvidence {
  root: string;
  identity?: RootIdentity;
  paths: Map<string, Physical>;
  /** By scope ('' for the mount root): where the next walk of it resumes. */
  walks: Map<string, string>;
}

interface Snapshot {
  mounts: Record<string, {
    root: string;
    identity?: RootIdentity;
    paths: Record<string, Physical>;
    walks?: Record<string, string>;
  }>;
}

export const DISK_AGREEMENT_RECORD_TYPE = 'workspace/disk-agreement';

/** Checkpoint once the tail outgrows this many entries, or the live paths, whichever is larger. */
const MIN_CHECKPOINT_TAIL = 1000;

export function candidateOf(value: Agreed): Candidate {
  return value.kind === 'absent' ? { kind: 'absent' } : { kind: 'content', hash: value.hash };
}

export function sameCandidate(a: Candidate, b: Candidate): boolean {
  return a.kind === b.kind && (a.kind === 'absent' || a.hash === (b as { hash: string }).hash);
}

/** A record with no mode claimed: a content record's, and a pending intent's own modes and its prior's. */
function withoutModes(value: Physical): Physical {
  if (value.kind === 'content' && value.mode !== undefined) {
    const { mode: _mode, ...rest } = value;
    return rest;
  }
  if (value.kind === 'pending') {
    const { modes: _modes, ...intent } = value;
    if (intent.prior?.kind !== 'content' || intent.prior.mode === undefined) return intent;
    const { mode: _mode, ...prior } = intent.prior;
    return { ...intent, prior };
  }
  return value;
}

export class DiskAgreement {
  private readonly store: JsStore;
  private readonly journal: RecordJournal<JournalEntry, Snapshot>;
  private readonly mounts = new Map<string, MountEvidence>();
  private configured: Array<{ name: string; root: string }> = [];
  /**
   * An append of evidence (or a rebuild) not yet made durable. Cleared only
   * by a barrier that succeeds, so a failed barrier stays owed: a later pass
   * with nothing new to record still settles it before deciding anything. A
   * place owes none (recordWalk).
   */
  private unsynced = false;
  /**
   * Whether memory holds a whole state: false until a rebuild first runs to
   * its end. A rebuild fills a new map and swaps it in only at its end, so
   * one that throws partway leaves whatever whole state came before it.
   */
  private whole = false;
  /** Whether this host observes file modes (not on Windows): where it doesn't, no record it writes claims one. */
  private readonly modesObserved: () => boolean;

  constructor(store: JsStore, opts: { modesObserved?: () => boolean } = {}) {
    this.store = store;
    this.journal = new RecordJournal<JournalEntry, Snapshot>(store, { type: DISK_AGREEMENT_RECORD_TYPE });
    this.modesObserved = opts.modesObserved ?? (() => true);
  }

  /**
   * Rebuild P from the journal for the configured mounts. A mount whose
   * recorded root differs from its configured one starts empty: evidence
   * about another directory says nothing about this one.
   */
  open(mounts: Array<{ name: string; root: string }>): void {
    this.configured = mounts;
    this.rebuild();
  }

  /**
   * Re-read the journal when an earlier write left it unreconciled, and throw
   * once an append failed inside the store. P may then lack what that append
   * recorded (the store may hold it where this process can't read it back),
   * and a decision from stale P can record what reopening contradicts, such
   * as a conflict that stays after the right evidence is back. So until the
   * store is reopened, no evidence is read (but for rootIdentityForRead's
   * one exception), written or checkpointed, and every pass and tool call
   * that needs it fails. The same holds, the exception included, when the
   * open's rebuild threw: there is no whole evidence to read.
   */
  ensureReconciled(): void {
    if (this.journal.needsReopen) {
      throw new EvidenceUnavailable('an append to its record of what disk last agreed with failed inside the store, so that record may lack what the append held');
    }
    if (!this.whole) {
      throw new EvidenceUnavailable('reading back its record of what disk last agreed with failed');
    }
    if (this.journal.needsReconcile) this.rebuild();
    const gate = callGate.getStore();
    if (gate) gate.passed = true;
  }

  get awaitsReopen(): boolean {
    return this.journal.needsReopen || !this.whole;
  }

  /** Whether evidence recorded so far still awaits a barrier. */
  get needsBarrier(): boolean {
    return this.unsynced;
  }

  /**
   * Replay the journal into memory. Records that read back are not proven
   * durable — a previous owner may have appended them and died before any
   * barrier — so evidence rebuilt here owes one, whether at open or after an
   * ambiguous append.
   */
  private rebuild(): void {
    this.unsynced = true;
    const { snapshot, entries } = this.journal.load();
    const replayed = new Map<string, MountEvidence>();
    for (const [name, mount] of Object.entries(snapshot?.mounts ?? {})) {
      replayed.set(name, {
        root: mount.root,
        ...(mount.identity ? { identity: mount.identity } : {}),
        paths: new Map(Object.entries(mount.paths)),
        walks: new Map(Object.entries(mount.walks ?? {})),
      });
    }
    for (const { entry } of entries) {
      if (entry.t === 'mount') {
        const existing = replayed.get(entry.mount);
        if (!existing || !sameRootPath(existing.root, entry.root)) {
          replayed.set(entry.mount, { root: entry.root, paths: new Map(), walks: new Map() });
        }
        continue;
      }
      const mount = replayed.get(entry.mount);
      if (mount) apply(mount, entry);
    }
    // Filled apart and swapped in at the end, so an append that throws here
    // leaves memory as it was, whole, rather than with the mounts after it
    // missing. Nothing reaches that today: only an open with a moved mount
    // appends here, the workspace opens each agreement once, and after the
    // open a rebuild finds every mount's record and appends none.
    const rebuilt = new Map<string, MountEvidence>();
    for (const { name, root } of this.configured) {
      const found = replayed.get(name);
      if (found && sameRootPath(found.root, root)) {
        rebuilt.set(name, found);
      } else {
        rebuilt.set(name, { root, paths: new Map(), walks: new Map() });
        this.journal.append({ t: 'mount', mount: name, root });
      }
    }
    this.mounts.clear();
    for (const [name, mount] of rebuilt) this.mounts.set(name, mount);
    this.whole = true;
  }

  /** The identity of the root this mount's evidence was gathered under, once any was. */
  rootIdentity(mount: string): RootIdentity | undefined {
    this.ensureReconciled();
    return this.mounts.get(mount)?.identity;
  }

  /**
   * The identity a disk read checks the mount's root against: the one in
   * memory once memory is whole, in every state of the journal, and an error
   * until then. It is the last identity whose append succeeded, since write()
   * appends before it applies, and no reconcile can change it, since root
   * entries are written without a sync; were one made durable, its failed
   * sync would leave the identity from before it: an old one, which refuses
   * the new root, or none, as for a mount with no recorded identity. This
   * is the one exception to ensureReconciled's "no evidence is read": the
   * layer stops reading so that a decision from stale evidence can't record
   * what reopening contradicts, and a read records nothing. Refusing reads
   * instead would stop every host read of the workspace's disk until a
   * restart.
   */
  rootIdentityForRead(mount: string): RootIdentity | undefined {
    if (!this.whole) this.ensureReconciled(); // throws: there's no whole state to read
    return this.mounts.get(mount)?.identity;
  }

  /**
   * Record the root's identity just before the first evidence a mount gains:
   * the caller saw it as the root while gathering that evidence. Once one is
   * recorded, the same directory seen on another device, or with a birth
   * time the record lacks, replaces it and keeps the evidence; another
   * directory is acceptRoot's alone.
   */
  recordRootIdentity(mount: string, identity: RootIdentity): void {
    const recorded = this.rootIdentity(mount);
    if (recorded !== undefined) {
      if (!sameRootIdentity(recorded, identity, false)) return;
      const renumbered = recorded.dev !== identity.dev;
      const bornLearned = recorded.born === undefined && identity.born !== undefined;
      if (!renumbered && !bornLearned) return;
    }
    this.write({ t: 'root', mount, identity }, {});
  }

  /**
   * Take the root as it is now, at the operator's word: record its identity
   * and forget every path's evidence, which described another directory.
   */
  acceptRoot(mount: string, identity: RootIdentity): void {
    this.write({ t: 'root', mount, identity, reset: true }, {});
  }

  get(mount: string, path: string): Physical | undefined {
    this.ensureReconciled(); // an ambiguous append may have landed: read it back first
    return this.mounts.get(mount)?.paths.get(path);
  }

  /** Every path with evidence under a prefix ('' for the whole mount). */
  paths(mount: string, prefix = ''): Array<[string, Physical]> {
    this.ensureReconciled();
    const paths = this.mounts.get(mount)?.paths;
    if (!paths) return [];
    const out: Array<[string, Physical]> = [];
    for (const [path, value] of paths) {
      if (prefix === '' || path === prefix || path.startsWith(prefix + '/')) out.push([path, value]);
    }
    return out;
  }

  /**
   * Where the next walk of `scope` ('' for the mount root) resumes: the last
   * entry a walk of it took before its cap stopped it, if one did.
   */
  walkResumesAfter(mount: string, scope: string): string | undefined {
    this.ensureReconciled();
    return this.mounts.get(mount)?.walks.get(scope);
  }

  /**
   * Record where a walk of `scope` stopped (`after`), or that one covered it
   * (null). Kept with the evidence so a restart resumes there too. A place
   * that's lost costs coverage, never a decision: an append that didn't land
   * loses one, and a checkpoint written by a version that doesn't keep them
   * (0.22) loses them all, and each scope's walks start at its top again.
   * So recording one owes no barrier: a pass that moves only its place makes
   * no store sync, and the place becomes durable with the next one.
   */
  recordWalk(mount: string, scope: string, after: string | null): void {
    if ((this.walkResumesAfter(mount, scope) ?? null) === after) return;
    this.write({ t: 'walk', mount, scope, after }, {});
  }

  /**
   * Record an intent. `durable` makes it (and every append before it) stable
   * before the caller performs the effect; batches pass it on their last one.
   */
  intend(mount: string, path: string, intent: Omit<Pending, 'kind'>, opts: { durable?: boolean } = {}): void {
    this.write({ t: 'set', mount, path, value: { kind: 'pending', ...intent } }, { durable: opts.durable });
  }

  /**
   * Record agreed evidence. `afterCommittedState` when it asserts a tree
   * commit made just before (the commit is synced first).
   */
  set(mount: string, path: string, value: Agreed | Interrupted, opts: { afterCommittedState?: boolean } = {}): void {
    this.write({ t: 'set', mount, path, value }, { afterCommittedState: opts.afterCommittedState });
  }

  /** Forget a path: P becomes unknown, the most conservative evidence. */
  forget(mount: string, path: string): void {
    if (this.get(mount, path) === undefined) return;
    this.write({ t: 'forget', mount, path }, {});
  }

  /**
   * Put back exactly the evidence a path had before an intent whose effect
   * never touched it — whatever kind it was (agreed, pending, interrupted, or
   * unknown) — so the intent leaves no trace in what P says; where modes go
   * unobserved, less any mode it carried, as every record written there.
   */
  restore(mount: string, path: string, value: Physical | undefined): void {
    if (value === undefined) this.forget(mount, path);
    else this.write({ t: 'set', mount, path, value }, {});
  }

  private write(entry: JournalEntry, opts: { durable?: boolean; afterCommittedState?: boolean }): void {
    this.ensureReconciled();
    // A host that doesn't observe modes has none that's true to record: a
    // record it writes carries no mode, and a host that observes them reads
    // the path's mode as unknown, as for evidence from before modes were
    // recorded. This holds whatever built the record: disk, the store's
    // entry, or an earlier record a POSIX host wrote, put back by a restore.
    // (A checkpoint re-serializes the evidence as it stands, other hosts'
    // records included, as replaying the journal would.)
    if (entry.t === 'set' && !this.modesObserved()) entry = { ...entry, value: withoutModes(entry.value) };
    // Evidence is owed a barrier until proven durable: a failed append may
    // still have landed. A place isn't (recordWalk).
    if (entry.t !== 'walk') this.unsynced = true;
    this.journal.append(entry, opts);
    if (opts.durable) this.unsynced = false; // synced after this append, and so everything before it
    const mount = this.mounts.get((entry as { mount: string }).mount);
    if (mount) apply(mount, entry);
  }

  /** Checkpoint when the tail has outgrown the live evidence. */
  maybeCheckpoint(): void {
    // Like every entry point: an ambiguous write is read back first.
    this.ensureReconciled();
    let live = 0;
    for (const mount of this.mounts.values()) live += mount.paths.size;
    if (this.journal.entriesSinceCheckpoint < Math.max(MIN_CHECKPOINT_TAIL, live)) return;
    const snapshot: Snapshot = { mounts: {} };
    for (const [name, mount] of this.mounts) {
      snapshot.mounts[name] = {
        root: mount.root,
        ...(mount.identity ? { identity: mount.identity } : {}),
        paths: Object.fromEntries(mount.paths),
        ...(mount.walks.size > 0 ? { walks: Object.fromEntries(mount.walks) } : {}),
      };
    }
    this.journal.checkpoint(snapshot);
  }

  /** Make every append so far stable. Throws, and stays owed, if the sync fails. */
  barrier(): void {
    this.store.sync();
    this.unsynced = false;
  }
}

/** Apply one entry to a mount's evidence; one of a kind this version doesn't know changes nothing. */
function apply(mount: MountEvidence, entry: JournalEntry): void {
  if (entry.t === 'root') applyRoot(mount, entry);
  else if (entry.t === 'set') mount.paths.set(entry.path, entry.value);
  else if (entry.t === 'forget') mount.paths.delete(entry.path);
  else if (entry.t === 'walk') {
    if (entry.after === null) mount.walks.delete(entry.scope);
    else mount.walks.set(entry.scope, entry.after);
  }
}

function applyRoot(mount: MountEvidence, entry: Extract<JournalEntry, { t: 'root' }>): void {
  mount.identity = entry.identity;
  if (entry.reset) {
    // Evidence about another directory says nothing about this one, and the
    // accepted root's walks start at its top.
    mount.paths.clear();
    mount.walks.clear();
  }
}
