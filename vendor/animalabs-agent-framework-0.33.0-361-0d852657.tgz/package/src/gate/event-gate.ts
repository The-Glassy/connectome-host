/**
 * EventGate — file-driven inference gating with per-policy debounce.
 *
 * Reads policies from a `gate.json` config file. Policies are evaluated in
 * order — first match wins. Each policy specifies a behavior: "always"
 * (trigger immediately), "skip" (don't trigger), or { debounce: ms }
 * (batch events per-policy, deliver when timer fires).
 *
 * The gate controls inference triggering only. Events always enter context
 * and are always dispatched to modules — the gate decides whether to spend
 * inference tokens, not whether the agent should know about the event.
 */

import { NOTICE_TAG } from '../notice-tags.js';
import { cutToFit, quotedJson, quotedValue, suppliedValue } from '../supplied-text.js';
import { existsSync, readFileSync, writeFileSync, mkdirSync } from 'node:fs';
import { basename, dirname, join } from 'node:path';
import { GateScript } from './gate-script.js';
import { SuppressScripts, type SuppressScriptEvent } from './suppress-scripts.js';
import { firstCatchAll, namesSomething } from './rule-scope.js';
import { canonical, duplicateName, lastRecipePath, noChanges, reconcileLine, reconcileWithRecipe, ruleName, type WrittenConfig } from './recipe-reconcile.js';
import { closestNames, isNearMiss } from '../closest-names.js';
import { MAX_TIMER_MS } from '../deadline-timer.js';
import { safeSlice } from '../safe-slice.js';

import type { ToolDefinition } from '../types/events.js';
import type { TraceEventInput } from '../types/trace.js';
import type {
  GateConfig,
  GatePolicy,
  GatePolicyMatch,
  SuppressConfig,
  GateBehavior,
  GateDecision,
  GateEntryRef,
  WakeLine,
  GateEventInfo,
  GatePolicyStats,
  GateStatus,
  ShadowWarning,
  GateProbeRow,
  JudgeConfig,
  JudgeEventSummary,
  JudgeFn,
  JudgeVerdict,
  UpcomingWake,
} from './types.js';

// Re-export types consumers need
export type {
  GateConfig, GateOptions, GateDecision, GateEntryRef, GateEventInfo, WakeLine,
  JudgeConfig, JudgeEventSummary, JudgeFn, JudgeRequest, JudgeVerdict, ReplyJudgeOptions, UpcomingWake,
} from './types.js';

// ---------------------------------------------------------------------------
// Constants
// ---------------------------------------------------------------------------

/** Max content length stored in pending debounce events. */
const MAX_CONTENT_SNIPPET = 200;
/** Max content length shown in onWake trace summaries. */
const MAX_TRACE_SNIPPET = 80;
/** Max events buffered during inference before oldest are dropped. */
const MAX_INFERENCE_BUFFER = 100;
/** Minimum interval between filesystem checks for config changes (ms). */
const RELOAD_THROTTLE_MS = 1000;

/**
 * Parse a gate file's text as JSON. Some Windows editors save UTF-8 with a
 * leading U+FEFF (BOM), which `readFileSync(…, 'utf-8')` keeps and
 * `JSON.parse` rejects; drop exactly one before parsing (#395).
 */
function parseGateJson(text: string): unknown {
  return JSON.parse(text.charCodeAt(0) === 0xfeff ? text.slice(1) : text);
}
/** Minimum debounce value (ms). */
const MIN_DEBOUNCE_MS = 100;
/** Maximum debounce value (ms). */
const MAX_DEBOUNCE_MS = 300_000;
/** Maximum `judge.maxWaitMs` (ms): an hour. */
const MAX_JUDGE_WAIT_MS = 3_600_000;
/** Longest `judge.instructions` (characters) a rule may hold: they go to the
 *  judge with every batch, so they're kept short. */
const MAX_JUDGE_INSTRUCTIONS = 4_000;
/** How long a judge request may take by default (ms) before onError decides. */
const DEFAULT_JUDGE_TIMEOUT_MS = 20_000;
/** Judge failures in a row after which gate_status names the judge as failing. */
const JUDGE_FAILING_STREAK = 3;

/** Whether a check made at `last` is still fresh at `now`, less than the
 *  reload throttle ago. A clock stepped backwards since makes it stale, so
 *  the next check runs rather than wait for the clock to catch up. */
function checkedRecently(now: number, last: number): boolean {
  const elapsed = now - last;
  return elapsed >= 0 && elapsed < RELOAD_THROTTLE_MS;
}

/** A read that failed because nothing is at the path. Any other failure
 *  (EACCES on a directory, ELOOP, ENOTDIR) is a file that's there but can't
 *  be read. */
function isMissing(err: unknown): boolean {
  return (err as NodeJS.ErrnoException | null)?.code === 'ENOENT';
}

// ---------------------------------------------------------------------------
// Default config
// ---------------------------------------------------------------------------

const DEFAULT_CONFIG: GateConfig = {
  policies: [],
  default: 'always',
};

// ---------------------------------------------------------------------------
// Internal types
// ---------------------------------------------------------------------------

interface PendingEvent {
  policyName: string;
  content: string;
  eventType: string;
  timestamp: number;
  /** The framework stores MCPL event content in the context window AT ARRIVAL
   *  (channel-incoming and push-event both addMessage before the gate decides
   *  anything). For those, the debounced wake must NOT re-quote the content —
   *  a [Gate:] copy delivered minutes later reads as a fresh, stale duplicate
   *  of a message the agent may have long since handled. */
  inContext: boolean;
  channelId?: string;
  /** Human-readable channel name (e.g. Discord channel name) when the event's
   *  metadata carries one — batched-wake lines render this instead of the raw
   *  composite channel id. */
  channelLabel?: string;
  /** Author id of the event (discord snowflake etc.), when the metadata carries
   *  one — a debounced wake names the newest such author as its counterparty. */
  authorId?: string;
  /** MCPL server id the event came from — the namespace for the counterparty
   *  (`<serverId>:user:<id>`), same as the direct channel-incoming path. */
  serverId?: string;
  /** `chat:addressed` (mention / reply-to-bot / DM): an addressed event outranks
   *  newer ambient chatter when a batched wake picks its provenance — the same
   *  rule the framework applies to the turn's speech locus. */
  addressed: boolean;
  /** The REGISTERED (composite) channel id the event arrived on, resolved by
   *  the host at enqueue time. Differs from `channelId` for push events,
   *  whose `channelId` is the adapter's raw id (a bare Discord snowflake for a
   *  DM) — unroutable. Absent when the host could not resolve one. */
  routeChannelId?: string;
  /** The event's own identity among what the framework stored at arrival:
   *  a channel message's id, a push event's event id (isNewestEntry). */
  messageId?: string;
  eventId?: string;
  /** GateEventInfo.recipients. */
  recipients?: readonly string[];
}

/** Where the host put a message the gate wrote: the agent whose window it
 *  went to; its stored id, once stored (absent while a surgery's hold, or
 *  its agent's recovery, keeps the write in memory); and `presented: false`
 *  when it wasn't presented to the agent: kept in memory, or stored while a
 *  turn of the agent's was alive, or with a presentation at rest that
 *  failed (#291's presentation index). The host marks the wake that goes with it from these. */
export interface WritePlacement {
  agent?: string;
  messageId?: string;
  presented?: false;
}

/**
 * Where a gate-requested wake came from, handed to the framework alongside the
 * reason so the turn's InferenceRequest can carry it (host telemetry stamps
 * "who woke the agent" from it). Ids only, never content or display names,
 * except `line`, which is the batch's own text for the agent's window.
 */
export interface WakeProvenance {
  /** Composite channel id of the chosen event — telemetry only, never a
   *  speech locus. Omitted for `mcpl:push-event` events, whose channel ids
   *  are raw server ids (unroutable and a second spelling of the same
   *  channel); the framework derives the composite id on the direct path. */
  channelId?: string;
  /** Server-namespaced author id: `<serverId>:user:<id>` (falls back to the
   *  channel id's first segment only when the event carried no server id). */
  counterparty?: string;
  /** True when the chosen event was `chat:addressed`. */
  addressed?: boolean;
  /** Speech locus for the wake: the routable channel of the chosen event,
   *  set ONLY when that event addressed the agent (mention / reply / DM) and
   *  the host resolved its registered channel. A batched wake used to carry
   *  no locus at all, so its reply fell back to the process-global
   *  most-recent-inbound channel — which any ambient message elsewhere,
   *  arriving a second after the DM that caused the wake, could retarget
   *  (2026-09-30: a DM reply published into a guild channel). Ambient-only
   *  batches still set nothing and keep the legacy fallback. */
  routeChannelId?: string;
  /** The server of `routeChannelId`'s channel, beside it whenever the chosen
   *  event named its server: channel ids are unique only within one
   *  server's connection (MCPL §14.2). */
  routeServerId?: string;
  /** Timestamp (ms) of the chosen event, so a consumer coalescing several
   *  requests can order by event recency, not by flush order. */
  at?: number;
  /** The batch's `[Gate: …]` line, when the gate handed it to the wake rather
   *  than wrote it: a WakeLine, the parts its text is rendered from when it's
   *  written (wakeLineText), decided by a fresh start of the wake's turn as
   *  WakeLine says. Unlike the fields above, this is content for the agent's
   *  window, not telemetry: it carries the channel's name as the agent is
   *  shown it. */
  line?: WakeLine;
}

interface DebounceState {
  timer: ReturnType<typeof setTimeout>;
  events: PendingEvent[];
  /** When the batch's first event arrived (ms), for a judge's maxWaitMs. */
  firstAt: number;
  /** When its timer fires (ms), as of its last re-arm (upcomingWakes). */
  dueAt: number;
  /** The judge the batch goes to when it fires, as its rule held it when the
   *  batch began: a rule removed or changed meanwhile has its batch judged
   *  as the rule it was asked. Absent for a debounce. */
  judge?: JudgeConfig;
}

/** A batch the reply judge is deciding now. */
interface JudgingState {
  events: PendingEvent[];
  judge: JudgeConfig;
  started: number;
  abort: AbortController;
  /** The judge's time limit, cleared once it's decided or the gate disposed. */
  timer?: ReturnType<typeof setTimeout>;
  /** Batches of the same rule that fired meanwhile, judged once this one is
   *  decided: delivered with it on reply, judged afresh on wait. */
  queued: PendingEvent[];
}

/** A rule's verdict counts and newest verdict (gate_status judgeState). */
interface JudgeRecord {
  verdicts: { reply: number; wait: number; error: number };
  last?: NonNullable<GatePolicyStats['judgeState']>['last'];
}

/** Token bucket for one (policy, key) pair under a rate_limit behavior. */
interface RateBucket {
  /** Tokens currently available. */
  tokens: number;
  /** Last epoch-ms timestamp the bucket was refilled. */
  lastRefill: number;
}

/** Synthetic key used when a policy has no `keyBy` or the field is missing. */
const SHARED_BUCKET_KEY = '__shared__';

interface CompiledPolicy {
  policy: GatePolicy;
  filterRegex?: RegExp;
  sourceRegex?: RegExp;
  channelRegex?: RegExp;
  mountRegex?: RegExp;
  pathRegex?: RegExp;
  tagsAnyRe?: RegExp[];
  tagsAllRe?: RegExp[];
  tagsNoneRe?: RegExp[];
}

interface PolicyStats {
  matchCount: number;
  lastMatchTimestamp: number | null;
}

// ---------------------------------------------------------------------------
// Glob matching (simple * wildcards)
// ---------------------------------------------------------------------------

function compileGlob(pattern: string): RegExp {
  // Escape everything except *, then replace * with .*
  const escaped = pattern.replace(/[.+?^${}()|[\]\\]/g, '\\$&');
  if (!pattern.includes('*')) {
    return new RegExp('^' + escaped + '$');
  }
  return new RegExp('^' + escaped.replace(/\*/g, '.*') + '$');
}

/**
 * Truthiness for `metadataTrue` matching. Stricter than JS `Boolean(x)`:
 * empty strings, empty arrays, and empty objects all count as false, so
 * `metadataTrue: ["mentionIds"]` doesn't match every event that happens
 * to carry an empty `mentionIds: []` array.
 */
function isMetadataTruthy(value: unknown): boolean {
  if (value === undefined || value === null) return false;
  if (typeof value === 'string') return value.length > 0;
  if (Array.isArray(value)) return value.length > 0;
  if (typeof value === 'object') return Object.keys(value).length > 0;
  return Boolean(value);
}

/**
 * Provenance of a batched wake: the newest ADDRESSED channel-bearing event
 * wins (mention / reply / DM outranks newer ambient chatter — the framework's
 * own locus rule); else the newest channel-bearing event. Channel, author and
 * addressed all come from that one event, so they can never disagree.
 */
export function wakeProvenance(events: PendingEvent[]): WakeProvenance | undefined {
  let newest: PendingEvent | undefined;
  let newestAddressed: PendingEvent | undefined;
  for (const e of events) {
    // A resolved route counts as naming a channel only for an ADDRESSED
    // event: a push whose origin declares only `mcplChannelId` (no raw
    // channel id, no author) is still a routable addressed message, and
    // skipping it would leave its wake on the most-recent-inbound fallback.
    // An ambient one stays out: the route is never reported for it, so as
    // the pick it would carry no telemetry at all and hide an earlier event
    // that names its channel and author.
    if (!e.channelId && !e.authorId && !(e.addressed && e.routeChannelId)) continue;
    if (!newest || e.timestamp >= newest.timestamp) newest = e;
    if (e.addressed && (!newestAddressed || e.timestamp >= newestAddressed.timestamp)) newestAddressed = e;
  }
  const pick = newestAddressed ?? newest;
  if (!pick) return undefined;
  // push-event channel ids are the adapter's raw ids (a Discord snowflake):
  // not a composite channel id, so not reported as one
  const channelId = pick.channelId && pick.eventType !== 'mcpl:push-event' ? pick.channelId : undefined;
  const ns = pick.serverId || (pick.channelId ? pick.channelId.split(':')[0] : '') || 'channel';
  return {
    ...(channelId ? { channelId } : {}),
    ...(pick.authorId ? { counterparty: `${ns}:user:${pick.authorId}` } : {}),
    ...(pick.addressed ? { addressed: true } : {}),
    ...(pick.addressed && pick.routeChannelId
      ? { routeChannelId: pick.routeChannelId, ...(pick.serverId ? { routeServerId: pick.serverId } : {}) }
      : {}),
    at: pick.timestamp,
  };
}

/** A `[Gate: …]` line's reference to messages already in the window: how
 *  many, in which channel, and how long ago the oldest arrived, as of `now`. */
function referenceLine(count: number, channel: string, oldest: number, now: number): string {
  const age = Math.round((now - oldest) / 1000);
  return `- ${count} message${count > 1 ? 's' : ''} in ${channel} ` +
    `(oldest ~${age}s ago) — already shown above at arrival; this is a ` +
    `batched wake, not new content`;
}

/** A handed batched-wake line's text (WakeLine), as it reads when written at
 *  `now`: the gate's words, its message's age counted to then. */
export function wakeLineText(line: WakeLine, now: number): string {
  return `[${NOTICE_TAG.gate}: 1 event matched]\n\n${referenceLine(1, line.shown, line.at, now)}`;
}

/** The event's own stored entry, as the framework is asked about it. */
function entryRef(event: PendingEvent): GateEntryRef {
  return {
    eventType: event.eventType,
    ...(event.serverId !== undefined ? { serverId: event.serverId } : {}),
    ...(event.channelId !== undefined ? { channelId: event.channelId } : {}),
    ...(event.messageId !== undefined ? { messageId: event.messageId } : {}),
    ...(event.eventId !== undefined ? { eventId: event.eventId } : {}),
  };
}

/**
 * Default route-channel resolution when the host supplies none: a
 * channel-incoming event's channel id is already the registered composite id;
 * a push event's is the adapter's raw id, which only the host can map.
 */
function defaultRouteChannel(info: GateEventInfo): string | undefined {
  return info.eventType === 'mcpl:channel-incoming' && info.channelId ? info.channelId : undefined;
}

/** Compact, log-friendly serialization of a GateBehavior. */
function formatBehavior(b: import('./types.js').GateBehavior): string {
  if (typeof b === 'string') return b;
  if ('debounce' in b) return `debounce:${b.debounce}`;
  if ('rate_limit' in b) {
    const k = b.rate_limit.keyBy ? `,keyBy:${b.rate_limit.keyBy}` : '';
    return `rate_limit:${b.rate_limit.tokens}/${b.rate_limit.refillIntervalMs}ms${k}`;
  }
  if ('passive_sample' in b) {
    const k = b.passive_sample.keyBy ? `,keyBy:${b.passive_sample.keyBy}` : '';
    return `passive_sample:${b.passive_sample.every}${k}`;
  }
  if ('judge' in b) {
    const w = b.judge.maxWaitMs !== undefined ? `,maxWait:${b.judge.maxWaitMs}` : '';
    return `judge:${b.judge.debounceMs}${w}`;
  }
  return 'unknown';
}

/** The quiet period (ms) of a batching behavior: a debounce's, or a judge's. */
function batchQuietMs(b: GateBehavior): number | undefined {
  if (typeof b !== 'object') return undefined;
  if ('debounce' in b) return b.debounce;
  if ('judge' in b) return b.judge.debounceMs;
  return undefined;
}

/**
 * Stable fingerprint for a GateBehavior, used during reload to detect
 * config changes that invalidate per-policy state. JSON.stringify is
 * deterministic for our small, flat behavior shapes — keys appear in
 * declaration order — so this is enough to spot any change in tokens,
 * refillIntervalMs, keyBy, every, or debounce duration.
 */
function behaviorFingerprint(b: import('./types.js').GateBehavior): string {
  return typeof b === 'string' ? b : JSON.stringify(b);
}

// ---------------------------------------------------------------------------
// Reading rules
// ---------------------------------------------------------------------------

// A rule is read as written when it can be, and every problem it has is named.
// gate.json and the host's starting rules are what a deployment already runs,
// so a rule with a problem is read the way earlier releases read it, and no
// event that woke the agent there goes quiet: a behavior the gate doesn't know
// is read as "always"; a field of the wrong type, one slip from one the gate
// reads there, or one the gate reads at another level of the rule (a match's
// "tagsAny" beside "name"), as left out, its problem naming where it's read;
// and a number out of range the way the starting rules ran it, but for a
// debounce, read at its nearest bound, which can send a batch later or sooner
// but drops no event in it, and a refill interval of 0, read as refilling at
// once. A rule is left out only where earlier releases refused it. One that
// skips or defers is read past a problem too, holding back what they held back:
// left out, the events it held back would go on to the rules after it, where a
// rate limit, a sample or a debounce could spend them and then hold back an
// event that woke the agent before. Under a default that holds events back, a
// file that leaves out a rule that could wake the agent isn't used, since that
// would hold back what the rule was written to wake on; earlier releases didn't
// use it either. A change through addPolicy, whose caller is there to fix it,
// refuses any problem, and nothing is saved. A field name that is no slip of
// one the gate reads there, and that it reads at no other level, changes
// nothing, a slip of another level's field included: it loads, and a note names
// it with the fields its place holds. In a rule, a name holding a field's whole
// name is such a name beside that field, an extra that explains it, and a slip
// of the field where it's given in the field's place (fieldNames); at
// gate.json's top, where it can be a label of the file, it's such a name either
// way. A file earlier releases loaded loads as they read it: a slip of
// "policies", a list of rules parked under a name the gate doesn't read, a
// rule's fields at gate.json's top and a "policies" that isn't a list each do
// nothing, and a note names each, so where "policies" writes no rules the file
// has none, and under "skip" or "defer" it holds back every event, as it did. A
// "policies" holding nothing writes no rules, as one left out does. A null is a
// field left out, and so is "", with a note: earlier releases read most fields
// that way, and none narrows anything by them. Where they refused a rule or a
// file for a null or a "" (a passthrough, a behavior's kind, gate.json's
// default), it now loads without it.

const CONFIG_FIELDS = ['default', 'policies'];
const POLICY_FIELDS = ['name', 'match', 'behavior', 'resets', 'passthrough', 'suppress'];
const MATCH_FIELDS = [
  'scope', 'source', 'channel', 'mount', 'pathGlob', 'tagsAny', 'tagsAll', 'tagsNone', 'metadataTrue', 'filter',
];
const FILTER_FIELDS = ['type', 'pattern'];
const BEHAVIOR_KINDS = ['debounce', 'rate_limit', 'passive_sample', 'judge'] as const;
const RATE_LIMIT_FIELDS = ['tokens', 'refillIntervalMs', 'keyBy'];
const PASSIVE_SAMPLE_FIELDS = ['every', 'keyBy'];
const JUDGE_FIELDS = ['debounceMs', 'maxWaitMs', 'instructions'];
const SUPPRESS_FIELDS = ['description', 'script'];

function isPlainObject(value: unknown): value is Record<string, unknown> {
  return value !== null && typeof value === 'object' && !Array.isArray(value);
}

/** A value that sets nothing: null, "", an empty list, or an object holding only such values. */
function holdsNothing(value: unknown): boolean {
  return value === null || value === '' || (Array.isArray(value) && value.length === 0)
    || (isPlainObject(value) && Object.values(value).every(holdsNothing));
}

/**
 * Whether a failed write left its file as it was: writeFileSync reports a
 * failure once it has the file open, so it may have changed it, as its write
 * or its close.
 */
function beforeWriting(err: unknown): boolean {
  const syscall = (err as NodeJS.ErrnoException).syscall;
  return syscall !== 'write' && syscall !== 'close';
}

/**
 * A change's refusal where gate.json has no rule list it could edit without
 * writing over what it holds: a list, JSON that isn't an object, or a
 * "policies" that isn't a list and holds something. `runs` is what the gate
 * runs meanwhile (rulesRun).
 */
function noListRefusal(noList: string, runs: string, path: string): string {
  return `${noList}, so it has no list of rules a change could edit without writing over what it holds, and nothing `
    + `was saved. Meanwhile the gate runs ${runs}. Until gate.json, at ${path}, is an object whose "policies" is a list `
    + 'holding its rules, a change is refused the same way.';
}

/**
 * A change's refusal where gate.json is there but couldn't be used as a file
 * a change edits: it couldn't be read, or it isn't JSON (`notJson`). Nothing is
 * written over it, so what it holds, often an operator's unfinished edit, stays
 * as it is. `runs` is what the gate runs meanwhile (rulesRun).
 */
function unusableRefusal(unusable: { error: string; notJson?: true }, runs: string, path: string): string {
  if (!unusable.notJson) {
    return `gate.json, at ${path}, couldn't be read (${unusable.error}), so a change can't edit it, and nothing was written `
      + `over it. Meanwhile the gate runs ${runs}. Whoever runs this host can make gate.json a file the gate can read; `
      + 'until then, a change is refused the same way.';
  }
  return `gate.json, at ${path}, isn't JSON the gate can read (${unusable.error}), so a change can't edit its rules without `
    + `writing over what it holds, and nothing was saved. Meanwhile the gate runs ${runs}. Until gate.json is JSON, a change `
    + 'is refused the same way.';
}

/**
 * A change's refusal at a start that didn't use gate.json, which has no rules
 * of its own (start-without): a change puts the rules gate.json then holds in
 * force, so it would take out of force what the start runs in its place.
 * `runs` is what the gate runs meanwhile (rulesRun); gate_status's entries
 * (notUsedClause, describeStart) say which rules keep gate.json out of use
 * and each fix.
 */
function notUsedRefusal(runs: string, path: string): string {
  return `gate.json, at ${path}, isn't used at this start, which runs as one without it does, and a change would put gate.json's rules in `
    + `force in place of what that runs, so nothing was saved. Meanwhile the gate runs ${runs}. gate_status says what keeps `
    + 'gate.json out of use and what would put it in use, such as giving it rules under "policies", or fixing the starting '
    + 'rules, which whoever runs this host can do, for the next start; until then, a change is refused the same way.';
}

function savedOnlyInForce(path: string, remedy: string | undefined): string {
  return remedy === undefined
    ? ''
    : ` gate.json, at ${path}, isn't in force, and a change is saved only if it brings it into force. ${remedy}`;
}

/**
 * A value as a message quotes it: its JSON, cut short when long, never inside a
 * surrogate pair, since the message reaches the agent's context.
 */
export function shownValue(value: unknown): string {
  if (value === undefined) return 'missing';
  // JSON writes NaN and the infinities as null.
  if (typeof value === 'number' && !Number.isFinite(value)) return String(value);
  let json: string;
  try {
    const stringified = JSON.stringify(value);
    json = stringified === undefined ? String(value) : quotedJson(stringified);
  } catch {
    json = String(value);
  }
  return json.length > 80 ? `${safeSlice(json, 0, 77)}...` : json;
}

/** Entries of a list as a message quotes them. */
function shownValues(values: readonly unknown[]): string {
  return values.map(shownValue).join(', ');
}

/** `a`, `a and b`, `a, b and c` (or "or"). */
function joinedList(items: readonly string[], joiner: 'and' | 'or' = 'and'): string {
  return items.length < 2 ? items.join('') : `${items.slice(0, -1).join(', ')} ${joiner} ${items[items.length - 1]}`;
}

const asGateNames = (path: string): string => path;

function namedBy(names: Readonly<Record<string, string>> | undefined): (path: string) => string {
  if (!names) return asGateNames;
  return (path) => {
    for (let end = path.length; end > 0; end = path.lastIndexOf('.', end - 1)) {
      const head = path.slice(0, end);
      if (Object.hasOwn(names, head)) return `${names[head]}${path.slice(end)}`;
    }
    return path;
  };
}

/** `"a"`, `"a" and "b"`, `"a", "b" and "c"` (or "or"). */
function quotedList(names: readonly string[], joiner: 'and' | 'or' = 'and'): string {
  return joinedList(names.map((n) => quotedValue(n)), joiner);
}

/** 1st, 2nd, 3rd, 4th, 11th, 21st. */
function ordinal(n: number): string {
  const tens = n % 100;
  const suffix = tens >= 11 && tens <= 13 ? 'th' : (['th', 'st', 'nd', 'rd'][n % 10] ?? 'th');
  return `${n}${suffix}`;
}

/** A message part as one sentence, for joining several. */
function sentence(text: string): string {
  return /[.?!]$/.test(text) ? text : `${text}.`;
}

/** How a note speaks of what it checks: a rule's fields, or a tool's parameters. */
const RULE_FIELDS_TERMS = { unread: "which the gate doesn't read", listed: 'Its fields are' };
const TOOL_PARAMETERS_TERMS = { unread: "which it doesn't take", listed: 'Its parameters are' };

/** A field name one slip from one or more the gate reads in its place. */
interface Slip {
  key: string;
  /** Every field it could be meant for, in closestNames' order: `tags` is part of "tagsAny", "tagsAll" and "tagsNone". */
  meant: string[];
}

/**
 * An object's field names that the gate doesn't read in its place: slips of
 * one it does, and the rest. A name is a slip of each field isNearMiss finds
 * it close to and, where `held`, of each whose whole name it holds, ignoring
 * case, that the object doesn't give: sent in that field's place, it's the
 * field under another name (`matchTags` with no `match`), where beside it,
 * it's an extra. The object is one withoutEmpty read, so a field given as
 * null or "" isn't given.
 */
function fieldNames(
  obj: Record<string, unknown>, fields: readonly string[], held = true,
): { slips: Slip[]; unread: string[] } {
  const slips: Slip[] = [];
  const unread: string[] = [];
  for (const key of Object.keys(obj)) {
    if (obj[key] === undefined || fields.includes(key)) continue;
    // Every field the gate reads has four characters or more, so holding one
    // needs no length of its own here. A field of two characters or fewer
    // would be held by names that have nothing to do with it ("valid" holds
    // "id"), and holding it would need the three characters isNearMiss asks
    // of a part.
    const holds = (field: string): boolean => key.toLowerCase().includes(field.toLowerCase());
    const near = fields.filter((field) => isNearMiss(key, field) || (held && !Object.hasOwn(obj, field) && holds(field)));
    if (near.length === 0) {
      unread.push(key);
      continue;
    }
    // closestNames keeps every name decided on above, in its order.
    slips.push({ key, meant: closestNames(key, near, near.length) });
  }
  return { slips, unread };
}

/** `"tags" (did you mean "tagsAny", "tagsAll" or "tagsNone"?)` */
function slipShown(slip: Slip): string {
  return `${quotedValue(slip.key)} (did you mean ${quotedList(slip.meant, 'or')}?)`;
}

/** Names an object has that are fields read at another level, with where that is (`homes`). */
interface Misplaced {
  keys: string[];
  homes: string[];
}

/**
 * An object's names that do nothing in its place, split into those that are
 * fields read elsewhere, grouped by where (`homesOf`), and the rest.
 */
function placedElsewhere(
  unread: readonly string[], homesOf: (key: string) => string[],
): { misplaced: Misplaced[]; rest: string[] } {
  const misplaced: Misplaced[] = [];
  const rest: string[] = [];
  for (const key of unread) {
    const homes = homesOf(key);
    if (homes.length === 0) {
      rest.push(key);
      continue;
    }
    const same = misplaced.find((m) => m.homes.join() === homes.join());
    if (same) same.keys.push(key);
    else misplaced.push({ keys: [key], homes });
  }
  return { misplaced, rest };
}

/** `"tagsAny", a field of "match"`; `"tagsAny" and "source", fields of "match"` */
function misplacedShown(m: Misplaced): string {
  return `${quotedList(m.keys)}, ${m.keys.length === 1 ? 'a field' : 'fields'} of ${joinedList(m.homes)}`;
}

/**
 * The levels of a gate.json the gate reads fields at, each as a message names
 * it, `file` naming the file itself.
 */
function fieldLevels(file: string, named: (path: string) => string = asGateNames): ReadonlyArray<{ name: string; fields: readonly string[] }> {
  return [
    { name: file, fields: CONFIG_FIELDS },
    { name: 'a rule', fields: POLICY_FIELDS },
    { name: '"match"', fields: MATCH_FIELDS },
    { name: '"match.filter"', fields: FILTER_FIELDS },
    { name: '"behavior"', fields: BEHAVIOR_KINDS },
    { name: `"${named('behavior.rate_limit')}"`, fields: RATE_LIMIT_FIELDS },
    { name: `"${named('behavior.passive_sample')}"`, fields: PASSIVE_SAMPLE_FIELDS },
    { name: `"${named('behavior.judge')}"`, fields: JUDGE_FIELDS },
  ];
}

/** Where a name is a field the gate reads, at a level other than the one whose fields are `here`. */
function homesOf(file: string, here: readonly string[], named?: (path: string) => string): (key: string) => string[] {
  return (key) => fieldLevels(file, named)
    .filter((level) => level.fields !== here && level.fields.includes(key))
    .map((level) => level.name);
}

/** Where each field of an object schema's nested objects is taken: `tagsAny` in "match". */
function nestedFields(properties: Readonly<Record<string, unknown>>, path = ''): Map<string, string[]> {
  const homes = new Map<string, string[]>();
  const add = (field: string, where: string) => homes.set(field, [...(homes.get(field) ?? []), where]);
  for (const [name, schema] of Object.entries(properties)) {
    if (!isPlainObject(schema) || !isPlainObject(schema.properties)) continue;
    const where = path ? `${path}.${name}` : name;
    for (const field of Object.keys(schema.properties)) add(field, `"${where}"`);
    for (const [field, inner] of nestedFields(schema.properties, where)) for (const at of inner) add(field, at);
  }
  return homes;
}

/** A note naming the fields an object has that do nothing in its place, with the fields that do. */
function noteUnread(
  where: string, unread: readonly string[], fields: readonly string[], notes: string[], terms = RULE_FIELDS_TERMS,
): void {
  if (unread.length === 0) return;
  notes.push(
    `${where} has ${quotedList(unread)}, ${terms.unread}, so ${unread.length === 1 ? 'it does' : 'they do'} `
    + `nothing. ${terms.listed} ${quotedList(fields)}.`,
  );
}

/**
 * A tool's input, its parameters given by its schema's `properties`, read as a
 * rule's fields are: a null or "" parameter is left out (a note names each "",
 * with what leaving it out does where `means` says), a slip of a parameter
 * (fieldNames) is refused, naming the one meant, and so is a field of one of
 * its object parameters given on its own, naming that parameter; any other
 * name is noted, or named in that refusal. Returns the input without what was
 * left out.
 */
export function checkToolInput(
  tool: string, input: Record<string, unknown>, properties: Readonly<Record<string, unknown>>, notes: string[],
  means: Readonly<Record<string, string>> = {},
): Record<string, unknown> {
  const params = Object.keys(properties);
  const given = withoutEmpty(tool, input, notes, means);
  const { slips, unread } = fieldNames(given, params);
  const homes = nestedFields(properties);
  const { misplaced, rest } = placedElsewhere(unread, (key) => homes.get(key) ?? []);
  if (slips.length > 0 || misplaced.length > 0) {
    // Every name it doesn't take is named, so the call that follows the refusal doesn't count on one.
    const has = [
      ...(slips.length > 0 ? [`${slips.map(slipShown).join(' and ')}, ${TOOL_PARAMETERS_TERMS.unread}`] : []),
      ...misplaced.map((m) => `${misplacedShown(m)}, ${TOOL_PARAMETERS_TERMS.unread} here`),
      ...(rest.length > 0 ? [`${quotedList(rest)}, ${TOOL_PARAMETERS_TERMS.unread}`] : []),
    ];
    // Where a field has one home, show it there, as the call would give it. A
    // value shownValue cuts short isn't one the call could give, so then the
    // parameter is named alone.
    const moves = misplaced.filter((m) => m.homes.length === 1).map((m) => {
      const it = m.keys.length === 1 ? 'it' : 'them';
      const shown = m.keys.map((key) => [key, shownValue(given[key])] as const);
      return shown.every(([key, value]) => value === JSON.stringify(given[key]))
        ? `Put ${it} in ${m.homes[0]}: {${shown.map(([key, value]) => `${JSON.stringify(key)}: ${value}`).join(', ')}}.`
        : `Put ${it} in ${m.homes[0]}.`;
    });
    throw new Error(
      `${tool} has ${has.join(', and ')}, so nothing was saved. ${moves.map((move) => `${move} `).join('')}`
      + `${TOOL_PARAMETERS_TERMS.listed} ${quotedList(params)}.`,
    );
  }
  noteUnread(tool, rest, params, notes, TOOL_PARAMETERS_TERMS);
  return given;
}

/**
 * An object's fields as the gate reads them: a null or "" is a field left out,
 * and a note names each "", with what leaving it out does where that's more
 * than setting no constraint (`means`, by field). Every other field stays an
 * own field of the copy, "__proto__" included, which JSON gives as one: set by
 * assignment, it would make its value the copy's prototype, whose fields the
 * gate would then read as the object's own.
 */
function withoutEmpty(
  where: string, obj: Record<string, unknown>, notes: string[], means: Readonly<Record<string, string>> = {},
): Record<string, unknown> {
  const kept: Array<[string, unknown]> = [];
  const empty: string[] = [];
  for (const [key, value] of Object.entries(obj)) {
    if (value === null || value === undefined) continue;
    if (value === '') empty.push(key);
    else kept.push([key, value]);
  }
  const out: Record<string, unknown> = Object.fromEntries(kept);
  if (empty.length > 0) {
    const meant = empty.flatMap((key) => {
      // An own field only: a name such as "constructor" would find Object.prototype's.
      const what = Object.hasOwn(means, key) ? means[key] : undefined;
      return what ? [what] : [];
    });
    notes.push(
      `${where} has ${quotedList(empty)} as "", so ${empty.length === 1 ? "it's" : "they're"} left out`
      + `${meant.length > 0 ? `: ${meant.join(', and ')}` : ''}.`,
    );
  }
  return out;
}

/** What leaving out a rule's field does, where that's more than setting no constraint. */
const RULE_LEFT_OUT = { behavior: 'a rule without one has the behavior "always"', match: 'a rule without one matches every event' };
/** The same for gate.json's own fields, under the default it then has. */
function configLeftOut(defaultBehavior: unknown): Record<string, string> {
  return {
    default: 'its default is "always"',
    policies: defaultBehavior === 'skip' || defaultBehavior === 'defer'
      ? `it has no rules, so under its default, "${defaultBehavior}", every event is held back`
      : 'it has no rules, so every event gets the default, "always"',
  };
}

/** A problem a rule has. */
interface RuleProblem {
  /** What's wrong: the field, what it holds, and what's needed. */
  text: string;
  /** How the rule is read past it ("so …"), the way earlier releases read it.
   *  Absent where they refused the rule, which is then left out. */
  read?: string;
  /** The reading only narrows what the rule matches (an empty scope entry),
   *  so a rule that holds events back holds back no more for it. */
  narrows?: boolean;
}

/** A rule as the gate reads it. */
interface RuleReading {
  /** How messages name it: `Rule "x"`, or its place when it has no name. */
  where: string;
  /** The rule as read, unless a problem has no reading. */
  policy?: GatePolicy;
  /** It wakes on none of what it matches, even where it can't be read: it
   *  skips or defers, or it's a rate limit whose tokens are a number not over
   *  0. Left out, such a rule holds back nothing it was written to wake on,
   *  though what it matches goes on to the rules after it, as for any rule
   *  left out. */
  quiet: boolean;
  /** Every problem it has, in the order its fields are read. */
  problems: RuleProblem[];
  /** Its fields that do nothing, and those given as "", each a sentence. */
  notes: string[];
  /** Set where it would be in force, and nothing left in its match narrows it. */
  matchesAll?: boolean;
}

/**
 * A rule's notes, ending with what a match that narrows nothing does. A
 * refusal says it of the rule read without what's wrong in its match, as
 * earlier releases read it, since that's why what's wrong there matters.
 */
function notesOf(reading: RuleReading, refused = false): string[] {
  if (!reading.matchesAll) return reading.notes;
  return [...reading.notes, refused
    ? "Read without what's wrong in its match, as earlier releases read it, the rule would match every event."
    : `${reading.where}: nothing left in match narrows the rule, so it matches every event.`];
}

/** Where a rule's fields are read into: the rule's name in messages, its problems, and its notes. */
interface Reader {
  where: string;
  /** How messages name the file the rule is in, for a field of the file's own put in the rule. */
  file: string;
  named: (path: string) => string;
  problems: RuleProblem[];
  notes: string[];
  /** Set where its rate limit's tokens are a number not over 0, so it wakes on none of what it matches. */
  noTokens?: boolean;
  /** Set where its match is left with nothing that narrows it, once something in it was named. */
  matchesAll?: boolean;
}

/** How a slip is read: as a field left out, which does nothing. */
const SLIP_READ = 'so it does nothing';
/** How a field of the wrong type is read: as one left out. */
const DROPPED = 'so the rule is read without it';

/**
 * An object's field names, at `level` of the rule (such as "match"): a slip of
 * a field is a problem, read as the field left out, and so is a field the gate
 * reads at another level, named with where that is (`misplacedReadOf` says
 * how the rule then reads, where that's more than the field doing nothing);
 * any other name the gate doesn't read is noted.
 */
function readFieldNames(
  r: Reader, level: string | null, obj: Record<string, unknown>, fields: readonly string[],
  readOf: (slip: Slip) => string = () => SLIP_READ,
  misplacedReadOf: (m: Misplaced) => string | undefined = () => undefined,
): void {
  const { slips, unread } = fieldNames(obj, fields);
  const { misplaced, rest } = placedElsewhere(unread, homesOf(r.file, fields, r.named));
  const shown = level === null ? null : r.named(level);
  noteUnread(shown ? `${r.where}: ${shown}` : r.where, rest, fields, r.notes);
  for (const slip of slips) {
    r.problems.push({ text: `${shown ?? 'it'} has ${slipShown(slip)}, which the gate doesn't read`, read: readOf(slip) });
  }
  for (const m of misplaced) {
    r.problems.push({
      text: `${shown ?? 'it'} has ${misplacedShown(m)}, which the gate doesn't read here`,
      read: misplacedReadOf(m) ?? (m.keys.length === 1 ? SLIP_READ : 'so they do nothing'),
    });
  }
}

/** "so that entry is dropped", "so those entries are dropped". */
function droppedEntries(count: number): string {
  return count === 1 ? 'so that entry is dropped' : 'so those entries are dropped';
}

/**
 * A rule, read as written, or past each problem it has. `unnamed` names a rule
 * without a name in messages, and `file` the file it's in.
 */
function readRule(raw: unknown, unnamed: string, file = 'gate.json', named: (path: string) => string = asGateNames): RuleReading {
  if (!isPlainObject(raw)) {
    return {
      where: unnamed,
      problems: [{ text: `it's ${shownValue(raw)}, where a rule is an object, such as {"name": "my-rule", "behavior": "always"}` }],
      notes: [],
      quiet: false,
    };
  }
  const name = nameOf(raw);
  const r: Reader = { where: name ? `Rule ${quotedValue(name)}` : unnamed, file, named, problems: [], notes: [] };
  const obj = withoutEmpty(r.where, raw, r.notes, RULE_LEFT_OUT);
  // Field names first, so a slip of one is named before what its absence does.
  readFieldNames(r, null, obj, POLICY_FIELDS, (slip) => {
    if (slip.meant.includes('behavior') && obj.behavior === undefined) return 'so the rule\'s behavior is "always"';
    if (slip.meant.includes('match') && obj.match === undefined) return 'so the rule matches every event';
    return SLIP_READ;
  }, (m) => {
    const of = (fields: readonly string[]) => m.keys.some((key) => fields.includes(key));
    if (obj.match === undefined && (of(MATCH_FIELDS) || of(FILTER_FIELDS))) return 'so the rule matches every event';
    if (obj.behavior === undefined && (of(BEHAVIOR_KINDS) || of(RATE_LIMIT_FIELDS) || of(PASSIVE_SAMPLE_FIELDS) || of(JUDGE_FIELDS))) {
      return 'so the rule\'s behavior is "always"';
    }
    return undefined;
  });
  if (!name) {
    r.problems.push({
      text: obj.name === undefined ? 'it has no "name"' : `name is ${shownValue(obj.name)}, where a non-empty string is needed`,
    });
  }
  const { behavior, kind } = readBehavior(r, obj.behavior);
  const match = readMatch(r, obj.match);
  const resets = readResets(r, obj.resets);
  const passthrough = readPassthrough(r, obj.passthrough, kind);
  const suppress = readSuppress(r, obj.suppress, obj.behavior, match, obj.match);
  const reading: RuleReading = {
    where: r.where, problems: r.problems, notes: r.notes, quiet: kind === 'skip' || kind === 'defer' || r.noTokens === true,
  };
  if (name && behavior && r.problems.every((p) => p.read !== undefined)) {
    const policy: GatePolicy = { name, match, behavior };
    if (resets) policy.resets = resets;
    if (passthrough) policy.passthrough = true;
    if (suppress) policy.suppress = suppress;
    reading.policy = policy;
    if (r.matchesAll) reading.matchesAll = true;
  }
  return reading;
}

type BehaviorKind = 'always' | 'defer' | 'skip' | (typeof BEHAVIOR_KINDS)[number];

const BEHAVIORS_NEEDED = '"always", "defer" or "skip", or an object holding one of "debounce", "rate_limit", "passive_sample" and "judge"';

/**
 * A rule's behavior: "always" when left out; one of the three names; or an
 * object holding one of the timing kinds. Anything else but a list or an
 * object was read as "always", a rule that wakes on every event it matches,
 * and is read so; a list, or an object holding none of the kinds, was
 * refused, and the rule is left out. Of
 * two kinds or more, "debounce", then "rate_limit", then "passive_sample" was
 * the one read, whatever their order, and is read so; "judge", newer than
 * those, is read only where none of them is given. Each other kind is read
 * on its own as well, so that a refusal names its problems too, and a load
 * reads past them, since it isn't read either way. `kind` is the behavior's
 * kind even where it can't be read, for passthrough's check.
 */
function readBehavior(r: Reader, value: unknown): { behavior?: GateBehavior | undefined; kind?: BehaviorKind | undefined } {
  if (value === undefined) return { behavior: 'always', kind: 'always' };
  if (value === 'always' || value === 'defer' || value === 'skip') return { behavior: value, kind: value };
  if (!isPlainObject(value)) {
    if (Array.isArray(value)) {
      r.problems.push({ text: `behavior is ${shownValue(value)}, where ${BEHAVIORS_NEEDED} is needed` });
      return {};
    }
    r.problems.push({ text: `behavior is ${shownValue(value)}, where ${BEHAVIORS_NEEDED} is needed`, read: 'so it\'s read as "always"' });
    return { behavior: 'always', kind: 'always' };
  }
  const b = withoutEmpty(`${r.where}: behavior`, value, r.notes);
  readFieldNames(r, 'behavior', b, BEHAVIOR_KINDS);
  const kinds = BEHAVIOR_KINDS.filter((k) => b[k] !== undefined);
  const kind = kinds[0];
  if (kind === undefined) {
    r.problems.push({ text: 'behavior holds none of "debounce", "rate_limit", "passive_sample" and "judge"' });
    return {};
  }
  if (kinds.length > 1) {
    r.problems.push({ text: `behavior holds ${quotedList(kinds)}, and a rule has one behavior`, read: `so only its "${kind}" is read` });
  }
  const behavior = READ_KIND[kind](r, b[kind]);
  for (const other of kinds.slice(1)) {
    const unread: Reader = { where: r.where, file: r.file, named: r.named, problems: [], notes: [] };
    READ_KIND[other](unread, b[other]);
    for (const p of unread.problems) r.problems.push({ text: p.text, read: `which goes unread with the rest of "${other}"` });
  }
  return { behavior, kind };
}

/**
 * A debounce: a number of milliseconds. One out of the gate's range is read
 * at its nearest bound. Earlier releases refused it in gate.json and ran it
 * as written in the starting rules, where one over 2,147,483,647 ms ran after
 * 1 ms, the most a timer takes; read at the bound, a batch goes out later or
 * sooner than it did there, and every event in it is still delivered.
 */
function readDebounce(r: Reader, ms: unknown): GateBehavior | undefined {
  if (typeof ms !== 'number' || !Number.isFinite(ms)) {
    r.problems.push({ text: `${r.named('behavior.debounce')} is ${shownValue(ms)}, where a number of milliseconds is needed, such as 60000` });
    return undefined;
  }
  if (ms < MIN_DEBOUNCE_MS) {
    r.problems.push({
      text: `${r.named('behavior.debounce')} is ${ms} ms, under the ${MIN_DEBOUNCE_MS} ms minimum`, read: `so it's read as ${MIN_DEBOUNCE_MS} ms`,
    });
    return { debounce: MIN_DEBOUNCE_MS };
  }
  if (ms > MAX_DEBOUNCE_MS) {
    r.problems.push({
      text: `${r.named('behavior.debounce')} is ${ms} ms, over the ${MAX_DEBOUNCE_MS} ms maximum`, read: `so it's read as ${MAX_DEBOUNCE_MS} ms`,
    });
    return { debounce: MAX_DEBOUNCE_MS };
  }
  return { debounce: ms };
}

/**
 * A rate limit. A refill interval under 0 ran as a bucket that never refills,
 * waking on its first tokens and then on none of what the rule matched, and
 * is read so. One of 0 refilled the bucket once and then never, its clock left
 * at NaN; it's read as refilling at once, every time, so the rule limits
 * nothing, which holds back nothing it woke the agent on (applyRateLimit). A
 * rule whose tokens aren't a positive number is left out, as earlier releases'
 * check refused it. Tokens that are a number not over 0, which ran unchecked
 * from the starting rules, woke the agent on nothing the rule matched, so that
 * rule is quiet (noTokens): leaving it out holds back nothing it was written
 * to wake on, though what it matches goes on to the rules after it, as for any
 * rule left out.
 */
function readRateLimit(r: Reader, value: unknown): GateBehavior | undefined {
  if (!isPlainObject(value)) {
    r.problems.push({
      text: `${r.named('behavior.rate_limit')} is ${shownValue(value)}, where an object is needed, such as {"tokens": 3, "refillIntervalMs": 60000}`,
    });
    return undefined;
  }
  const conf = withoutEmpty(`${r.where}: ${r.named('behavior.rate_limit')}`, value, r.notes, { keyBy: 'every event the rule matches shares one bucket' });
  readFieldNames(r, 'behavior.rate_limit', conf, RATE_LIMIT_FIELDS);
  const tokens = conf.tokens;
  const refill = conf.refillIntervalMs;
  const tokensUsable = typeof tokens === 'number' && Number.isFinite(tokens) && tokens > 0;
  if (typeof tokens === 'number' && !(tokens > 0)) r.noTokens = true;
  if (!tokensUsable) {
    r.problems.push({ text: `${r.named('behavior.rate_limit.tokens')} is ${shownValue(tokens)}, where a positive number is needed` });
  }
  const refillUsable = typeof refill === 'number' && Number.isFinite(refill);
  if (!refillUsable) {
    r.problems.push({
      text: `${r.named('behavior.rate_limit.refillIntervalMs')} is ${shownValue(refill)}, where a positive number of milliseconds is needed`,
    });
  } else if (refill <= 0) {
    r.problems.push({
      text: `${r.named('behavior.rate_limit.refillIntervalMs')} is ${refill}, where a positive number of milliseconds is needed`,
      read: refill === 0
        ? 'so its tokens refill at once, and it limits nothing it matches'
        : "so its tokens never refill, and once they're spent it wakes the agent on nothing it matches",
    });
  }
  const keyBy = readKeyBy(r, 'rate_limit', conf.keyBy);
  if (!tokensUsable || !refillUsable) return undefined;
  const out: { tokens: number; refillIntervalMs: number; keyBy?: string } = { tokens, refillIntervalMs: refill };
  if (keyBy !== undefined) out.keyBy = keyBy;
  return { rate_limit: out };
}

/**
 * A sample. A step at or under 0 sampled every event, as 1 does, and a
 * fraction its next whole number, since the count was compared with it, so
 * each is read that way.
 */
function readPassiveSample(r: Reader, value: unknown): GateBehavior | undefined {
  if (!isPlainObject(value)) {
    r.problems.push({ text: `${r.named('behavior.passive_sample')} is ${shownValue(value)}, where an object is needed, such as {"every": 10}` });
    return undefined;
  }
  const conf = withoutEmpty(`${r.where}: ${r.named('behavior.passive_sample')}`, value, r.notes, { keyBy: 'every event the rule matches shares one count' });
  readFieldNames(r, 'behavior.passive_sample', conf, PASSIVE_SAMPLE_FIELDS);
  const given = conf.every;
  let every: number | undefined;
  if (typeof given !== 'number' || !Number.isFinite(given)) {
    r.problems.push({ text: `${r.named('behavior.passive_sample.every')} is ${shownValue(given)}, where a whole number of 1 or more is needed` });
  } else if (Number.isInteger(given) && given > 0) {
    every = given;
  } else {
    every = given <= 0 ? 1 : Math.ceil(given);
    r.problems.push({
      text: `${r.named('behavior.passive_sample.every')} is ${given}, ${given <= 0 ? 'under 1' : 'not a whole number'}`,
      read: `so it's read as ${every}`,
    });
  }
  const keyBy = readKeyBy(r, 'passive_sample', conf.keyBy);
  if (every === undefined) return undefined;
  const out: { every: number; keyBy?: string } = { every };
  if (keyBy !== undefined) out.keyBy = keyBy;
  return { passive_sample: out };
}

/**
 * A judge: a debounce's quiet period, read as `debounce` is, with at its
 * nearest bound one out of range; an optional longest wait, from that
 * quiet period to an hour, likewise; and the agent's optional instructions to
 * the judge, text of at most MAX_JUDGE_INSTRUCTIONS characters. Earlier
 * releases knew no judge, so nothing deployed has one: a rule whose judge
 * can't be read is left out, and its instructions, which go to a model with
 * every batch, are never cut to fit.
 */
function readJudge(r: Reader, value: unknown): GateBehavior | undefined {
  if (!isPlainObject(value)) {
    r.problems.push({
      text: `${r.named('behavior.judge')} is ${shownValue(value)}, where an object is needed, such as {"debounceMs": 30000, "instructions": "..."}`,
    });
    return undefined;
  }
  const conf = withoutEmpty(`${r.where}: ${r.named('behavior.judge')}`, value, r.notes, {
    maxWaitMs: 'a batch is judged only after its quiet period',
    instructions: 'the judge decides without the agent\'s word',
  });
  readFieldNames(r, 'behavior.judge', conf, JUDGE_FIELDS);
  let ok = true;
  const ms = conf.debounceMs;
  let debounceMs: number | undefined;
  if (typeof ms !== 'number' || !Number.isFinite(ms)) {
    r.problems.push({ text: `${r.named('behavior.judge.debounceMs')} is ${shownValue(ms)}, where a number of milliseconds is needed, such as 30000` });
    ok = false;
  } else if (ms < MIN_DEBOUNCE_MS) {
    r.problems.push({
      text: `${r.named('behavior.judge.debounceMs')} is ${ms} ms, under the ${MIN_DEBOUNCE_MS} ms minimum`, read: `so it's read as ${MIN_DEBOUNCE_MS} ms`,
    });
    debounceMs = MIN_DEBOUNCE_MS;
  } else if (ms > MAX_DEBOUNCE_MS) {
    r.problems.push({
      text: `${r.named('behavior.judge.debounceMs')} is ${ms} ms, over the ${MAX_DEBOUNCE_MS} ms maximum`, read: `so it's read as ${MAX_DEBOUNCE_MS} ms`,
    });
    debounceMs = MAX_DEBOUNCE_MS;
  } else {
    debounceMs = ms;
  }
  let maxWaitMs: number | undefined;
  const wait = conf.maxWaitMs;
  if (wait !== undefined) {
    if (typeof wait !== 'number' || !Number.isFinite(wait)) {
      r.problems.push({ text: `${r.named('behavior.judge.maxWaitMs')} is ${shownValue(wait)}, where a number of milliseconds is needed, such as 120000` });
      ok = false;
    } else {
      const floor = debounceMs ?? MIN_DEBOUNCE_MS;
      if (wait < floor) {
        r.problems.push({
          text: `${r.named('behavior.judge.maxWaitMs')} is ${wait} ms, under the rule's ${floor} ms quiet period`,
          read: `so it's read as ${floor} ms`,
        });
        maxWaitMs = floor;
      } else if (wait > MAX_JUDGE_WAIT_MS) {
        r.problems.push({
          text: `${r.named('behavior.judge.maxWaitMs')} is ${wait} ms, over the ${MAX_JUDGE_WAIT_MS} ms maximum`,
          read: `so it's read as ${MAX_JUDGE_WAIT_MS} ms`,
        });
        maxWaitMs = MAX_JUDGE_WAIT_MS;
      } else {
        maxWaitMs = wait;
      }
    }
  }
  const said = conf.instructions;
  let instructions: string | undefined;
  if (said !== undefined) {
    if (typeof said !== 'string') {
      r.problems.push({ text: `${r.named('behavior.judge.instructions')} is ${shownValue(said)}, where text is needed` });
      ok = false;
    } else if (said.length > MAX_JUDGE_INSTRUCTIONS) {
      r.problems.push({
        text: `${r.named('behavior.judge.instructions')} is ${said.length} characters long, over the ${MAX_JUDGE_INSTRUCTIONS}-character maximum`,
      });
      ok = false;
    } else {
      instructions = said;
    }
  }
  if (!ok || debounceMs === undefined) return undefined;
  const out: JudgeConfig = { debounceMs };
  if (maxWaitMs !== undefined) out.maxWaitMs = maxWaitMs;
  if (instructions !== undefined) out.instructions = instructions;
  return { judge: out };
}

/** How each kind of behavior object is read. */
const READ_KIND: Readonly<Record<(typeof BEHAVIOR_KINDS)[number], (r: Reader, value: unknown) => GateBehavior | undefined>> = {
  debounce: readDebounce,
  rate_limit: readRateLimit,
  passive_sample: readPassiveSample,
  judge: readJudge,
};

/** A timing kind's keyBy: a field name. One of another type was read as none. */
function readKeyBy(r: Reader, kind: 'rate_limit' | 'passive_sample', value: unknown): string | undefined {
  if (value === undefined) return undefined;
  if (typeof value === 'string') return value;
  r.problems.push({
    text: `${r.named(`behavior.${kind}.keyBy`)} is ${shownValue(value)}, where a field name is needed, such as "channelId"`,
    read: `so it does nothing, and every event the rule matches shares one ${kind === 'rate_limit' ? 'bucket' : 'count'}`,
  });
  return undefined;
}

/**
 * A rule's match: every field optional, and one left out matches anything. A
 * field of the wrong type, or an entry of one in a list, was dropped, which
 * widened the rule, and is read so; an empty entry in a list, dropped, but for
 * one in `scope`, which was kept and narrows the rule, since no event's type is
 * "". A match that isn't an object matched every event, and so does one left
 * with nothing that narrows it, which readRule notes, for a rule it can read,
 * where something in the match was named: dropped, left out or unread.
 */
function readMatch(r: Reader, value: unknown): GatePolicyMatch {
  const match: GatePolicyMatch = {};
  if (value === undefined) return match;
  if (!isPlainObject(value)) {
    r.problems.push({
      text: `match is ${shownValue(value)}, where an object is needed, such as {"source": "discord"}`,
      read: 'so the rule matches every event',
    });
    return match;
  }
  const named = r.problems.length + r.notes.length;
  const m = withoutEmpty(`${r.where}: match`, value, r.notes);
  readFieldNames(r, 'match', m, MATCH_FIELDS);

  if (m.scope !== undefined) {
    if (!Array.isArray(m.scope)) {
      r.problems.push({
        text: `match.scope is ${shownValue(m.scope)}, where a list of event types is needed, such as ["mcpl:channel-incoming"]`,
        read: 'so the rule matches every type of event',
      });
    } else {
      const types = m.scope.filter((s): s is string => typeof s === 'string');
      const dropped = m.scope.filter((s) => typeof s !== 'string');
      if (dropped.length > 0) {
        r.problems.push({
          text: `match.scope holds ${shownValues(dropped)}, which ${dropped.length === 1 ? "isn't an event type" : "aren't event types"}`,
          read: types.length > 0 ? droppedEntries(dropped.length) : `${droppedEntries(dropped.length)}, and the rule matches every type of event`,
        });
      }
      if (types.includes('')) {
        r.problems.push({
          text: 'match.scope holds "", and no event\'s type is ""',
          read: types.every((t) => t === '') ? 'so the rule matches no event' : 'so that entry matches no event',
          narrows: true,
        });
      }
      match.scope = types;
    }
  }
  for (const [field, example] of [
    ['source', '"discord"'], ['channel', '"discord:*:12345"'], ['mount', '"project"'], ['pathGlob', '"notes/*.md"'],
  ] as const) {
    const given = m[field];
    if (given === undefined) continue;
    if (typeof given === 'string') match[field] = given;
    else r.problems.push({ text: `match.${field} is ${shownValue(given)}, where a string is needed, such as ${example}`, read: DROPPED });
  }
  for (const [field, example] of [
    ['metadataTrue', '["mentioned"]'], ['tagsAny', '["chat:ambient"]'], ['tagsAll', '["chat:ambient"]'], ['tagsNone', '["chat:ambient"]'],
  ] as const) {
    const given = m[field];
    if (given === undefined) continue;
    if (!Array.isArray(given)) {
      r.problems.push({
        text: `match.${field} is ${shownValue(given)}, where a list of non-empty strings is needed, such as ${example}`, read: DROPPED,
      });
      continue;
    }
    const kept = given.filter((s): s is string => typeof s === 'string' && s.length > 0);
    const dropped = given.filter((s) => typeof s !== 'string' || s.length === 0);
    if (dropped.length > 0) {
      r.problems.push({
        text: `match.${field} holds ${shownValues(dropped)}, where each entry is a non-empty string`,
        read: kept.length > 0 ? droppedEntries(dropped.length) : `${droppedEntries(dropped.length)}, and with none left the list narrows nothing`,
      });
    }
    if (kept.length > 0) match[field] = kept;
  }

  if (m.filter !== undefined) {
    if (!isPlainObject(m.filter)) {
      r.problems.push({
        text: `match.filter is ${shownValue(m.filter)}, where an object is needed, such as {"type": "text", "pattern": "release"}`,
        read: DROPPED,
      });
    } else {
      // An empty pattern matches every event's content, so a filter with one
      // narrows nothing, as before, and it's left out, its other problems named.
      const emptyPattern = m.filter.pattern === '';
      const f = withoutEmpty(`${r.where}: match.filter`, emptyPattern ? { ...m.filter, pattern: undefined } : m.filter, r.notes);
      readFieldNames(r, 'match.filter', f, FILTER_FIELDS);
      const without = 'so the rule is read without its filter';
      const type = f.type === 'text' || f.type === 'regex' ? f.type : undefined;
      if (type === undefined) {
        r.problems.push({ text: `match.filter.type is ${shownValue(f.type)}, where "text" or "regex" is needed`, read: without });
      }
      if (emptyPattern) {
        r.notes.push(`${r.where}: match.filter's pattern is "", so the filter narrows nothing, and it's left out.`);
      } else if (typeof f.pattern !== 'string') {
        r.problems.push({
          text: `match.filter.pattern is ${shownValue(f.pattern)}, where the text or regular expression to look for is needed`,
          read: without,
        });
      } else if (type === 'text') {
        match.filter = { type, pattern: f.pattern };
      } else if (type === 'regex') {
        try {
          new RegExp(f.pattern);
          match.filter = { type, pattern: f.pattern };
        } catch (e) {
          r.problems.push({
            text: `match.filter.pattern isn't a regular expression the gate can read (${quotedValue(errorText(e))}), so fix it, `
              + 'or give match.filter.type "text" to look for the pattern as plain text',
          });
        }
      }
    }
  }

  // Left with nothing that narrows it once something in it was named, it
  // matches every event. Empty lists and nulls alone always meant no
  // constraint, and name nothing.
  if (!matchNarrows(match) && r.problems.length + r.notes.length > named) r.matchesAll = true;
  return match;
}

/** A rule's resets: names of rules whose state it clears when it fires. An entry that isn't a name was dropped. */
function readResets(r: Reader, value: unknown): string[] | undefined {
  if (value === undefined) return undefined;
  if (!Array.isArray(value)) {
    r.problems.push({
      text: `resets is ${shownValue(value)}, where a list of rule names is needed, such as ["other-rule"]`,
      read: 'so the rule resets no other',
    });
    return undefined;
  }
  // Unknown names are ignored at runtime, so reload races don't blow up.
  const names = value.filter((s): s is string => typeof s === 'string' && s.length > 0);
  const dropped = value.filter((s) => typeof s !== 'string' || s.length === 0);
  if (dropped.length > 0) {
    r.problems.push({
      text: `resets holds ${shownValues(dropped)}, where each entry is a rule's name`,
      read: names.length > 0 ? droppedEntries(dropped.length) : `${droppedEntries(dropped.length)}, and the rule resets no other`,
    });
  }
  return names.length > 0 ? names : undefined;
}

/**
 * A rule's passthrough. It's meaningful only on the counting behaviors, where
 * "matched but didn't fire" is a distinct outcome that can fall through. On
 * always, defer, skip or a debounce it would be a no-op at best and a
 * misleading promise at worst, so it's refused rather than ignored.
 */
function readPassthrough(r: Reader, value: unknown, kind: BehaviorKind | undefined): boolean {
  if (value === undefined || value === false) return false;
  if (value !== true) {
    r.problems.push({ text: `passthrough is ${shownValue(value)}, where true or false is needed` });
    return false;
  }
  if (kind === undefined || kind === 'rate_limit' || kind === 'passive_sample') return true;
  const given = kind === 'always' || kind === 'defer' || kind === 'skip' ? `behavior "${kind}"` : r.named(`behavior.${kind}`);
  r.problems.push({
    text: `passthrough is true, and only a ${r.named('behavior.rate_limit')} or ${r.named('behavior.passive_sample')} rule passes on `
      + `an event it matches without waking on it; with ${given}, leave passthrough out`,
  });
  return false;
}

/** Whether a match narrows what it matches: anything but an empty scope. */
export function matchNarrows(match: GatePolicyMatch): boolean {
  return Object.entries(match).some(([field, v]) => !(field === 'scope' && Array.isArray(v) && v.length === 0));
}

/**
 * Whether a suppress rule's match names what it hides: an event type, or a
 * source, channel, mount, path or tag pattern that isn't only wildcards
 * (namesSomething), a metadata flag, or a content filter. A pattern of
 * wildcards alone, such as `source: "*"`, or only `tagsNone`, takes every
 * event, which a suppress rule may not.
 */
function suppressMatchNarrows(match: GatePolicyMatch): boolean {
  if ((match.scope ?? []).length > 0 || (match.metadataTrue ?? []).length > 0 || match.filter !== undefined) return true;
  if ([match.source, match.channel, match.mount, match.pathGlob].some(namesSomething)) return true;
  return [...(match.tagsAny ?? []), ...(match.tagsAll ?? [])].some(namesSomething);
}

/** Longest suppress description, in characters: the review sends it with every rule it judges. */
export const MAX_SUPPRESS_DESCRIPTION = 2_000;
/** Longest suppress script, in characters. */
export const MAX_SUPPRESS_SCRIPT = 20_000;
const SUPPRESS_EXAMPLE = '{"description": "the eye going on and off"}';

/**
 * A rule's `suppress`. Every problem with it is read as a rule that doesn't
 * suppress, which is how a release without suppression reads the rule:
 * its behavior then decides the event, and the event is rendered. The
 * behavior has to be written out as "defer" (or "skip"), not left to
 * default, because such a release reads a rule with no behavior as
 * "always" and would wake the agent on every event the rule was meant to
 * hide.
 */
function readSuppress(r: Reader, value: unknown, behavior: unknown, match: GatePolicyMatch, rawMatch: unknown): SuppressConfig | undefined {
  if (value === undefined || value === false) return undefined;
  const without = "so the rule doesn't suppress, and its behavior decides its events as for any other rule";
  if (!isPlainObject(value)) {
    r.problems.push({ text: `suppress is ${shownValue(value)}, where an object such as ${SUPPRESS_EXAMPLE} is needed`, read: without });
    return undefined;
  }
  const before = r.problems.length;
  // A script given as null or "" is a script that's missing, not one left
  // out: read as left out, the rule would hide every event its match takes.
  const { script: _givenScript, ...rest } = value;
  const emptyScript = Object.hasOwn(value, 'script') && (value.script === null || value.script === '');
  if (emptyScript) {
    r.problems.push({ text: `suppress.script is ${shownValue(value.script)}, where the source of a function such as "(event, state) => false" is needed`, read: without });
  }
  const given = withoutEmpty(`${r.where}: suppress`, emptyScript ? rest : value, r.notes);
  const reported = r.problems.length;
  readFieldNames(r, 'suppress', given, SUPPRESS_FIELDS);
  // A field it doesn't read can't be left aside here, as elsewhere in a
  // rule: one meant as a condition, left out, would hide every event the
  // match takes.
  const unread = Object.keys(given).filter((key) => !SUPPRESS_FIELDS.includes(key));
  if (unread.length > 0 && r.problems.length === reported) {
    r.problems.push({ text: `suppress has ${quotedList(unread)}, and a suppress rule reads only "description" and "script"`, read: without });
  }
  const config: SuppressConfig = { description: '' };
  if (typeof given.description !== 'string' || given.description.trim() === '') {
    r.problems.push({
      text: `suppress.description is ${given.description === undefined ? 'missing' : shownValue(given.description)}, where the rule's `
        + 'purpose in a few words is needed: the review checks what the rule hides against it',
      read: without,
    });
  } else if ([...given.description].length > MAX_SUPPRESS_DESCRIPTION) {
    r.problems.push({
      text: `suppress.description is ${[...given.description].length.toLocaleString('en-US')} characters, over the `
        + `${MAX_SUPPRESS_DESCRIPTION.toLocaleString('en-US')} allowed`,
      read: without,
    });
  } else {
    config.description = given.description.trim();
  }
  if (given.script !== undefined) {
    if (typeof given.script !== 'string' || given.script.trim() === '') {
      r.problems.push({ text: `suppress.script is ${shownValue(given.script)}, where the source of a function such as "(event, state) => false" is needed`, read: without });
    } else if ([...given.script].length > MAX_SUPPRESS_SCRIPT) {
      r.problems.push({
        text: `suppress.script is ${[...given.script].length.toLocaleString('en-US')} characters, over the ${MAX_SUPPRESS_SCRIPT.toLocaleString('en-US')} allowed`,
        read: without,
      });
    } else {
      // Parsed only, never run here: the script runs on its worker.
      try {
        new Function(`"use strict";\nreturn (${given.script}\n);`);
        config.script = given.script;
      } catch (e) {
        r.problems.push({ text: `suppress.script doesn't parse (${quotedValue(errorText(e))})`, read: without });
      }
    }
  }
  if (behavior !== 'defer' && behavior !== 'skip') {
    r.problems.push({
      text: `suppress is given, and a rule that suppresses needs "behavior": "defer" written out, so a release that `
        + `doesn't know "suppress" defers its events instead of waking you on them; it has `
        + (behavior === undefined ? 'no behavior' : `behavior ${shownValue(behavior)}`),
      read: without,
    });
  }
  // A match field the gate doesn't read would, left aside, hide more than was
  // written: the condition it was meant to add is gone.
  if (isPlainObject(rawMatch)) {
    const rawFilter = isPlainObject(rawMatch.filter) ? Object.keys(rawMatch.filter).filter((key) => !FILTER_FIELDS.includes(key)).map((key) => `filter.${key}`) : [];
    const unreadMatch = [...Object.keys(rawMatch).filter((key) => !MATCH_FIELDS.includes(key)), ...rawFilter];
    if (unreadMatch.length > 0) {
      r.problems.push({ text: `suppress is given, and match has ${quotedList(unreadMatch)}, which the gate doesn't read, so the rule would hide more than was written`, read: without });
    }
  }
  if (!suppressMatchNarrows(match)) {
    r.problems.push({
      text: 'suppress is given, and the rule\'s match names nothing it hides: a suppress rule needs a match that names '
        + 'a scope, a source, a channel, tags, a mount or path, metadata or a filter (not a pattern of wildcards alone, or tagsNone alone), '
        + 'so it can\'t hide everything',
      read: without,
    });
  }
  // Only a rule read without any problem suppresses: one read past a problem
  // (a slip of a field, a match read without a part of it) matches more, or
  // decides otherwise, than its author wrote, and hiding is what can't be
  // seen to go wrong. Its behavior decides its events instead.
  if (before > 0) {
    r.problems.push({ text: 'suppress is given on a rule with problems, and a rule suppresses only when it has none', read: without });
  }
  return r.problems.length === 0 ? config : undefined;
}

/** What a load or a start does with a rule. */
type RuleOutcome = 'as-written' | 'read' | 'left-out';

/**
 * A rule with no problem is in force as written. One with a problem is read
 * past it, the way earlier releases read it, so it wakes the agent wherever
 * they did and holds back what they held back, a rule that skips or defers
 * included. It's left out only where they refused it.
 */
function ruleOutcome(reading: RuleReading): RuleOutcome {
  if (reading.problems.length === 0) return 'as-written';
  return reading.policy === undefined ? 'left-out' : 'read';
}

/** What a load or a start says of a rule: how it's read past its problems, or that it's left out, and its notes. */
function readingSentences(reading: RuleReading, outcome: RuleOutcome): string[] {
  const said: string[] = [];
  if (outcome === 'read') {
    // Read past a problem that can widen it, a rule that holds events back holds back what it now matches.
    const behavior = reading.policy?.behavior;
    const holds = (behavior === 'skip' || behavior === 'defer') && reading.problems.some((p) => !p.narrows)
      ? ` Read so, it ${behavior === 'skip' ? 'skips' : 'defers'} every event it now matches, as earlier releases did.`
      : '';
    said.push(`${reading.where}: ${reading.problems.map((p) => `${p.text}, ${p.read}`).join('; ')}.${holds}`);
  } else if (outcome === 'left-out') {
    said.push(`${reading.where} is left out: ${reading.problems.map((p) => p.text).join('; ')}.`);
  }
  return [...said, ...notesOf(reading)];
}

/** addPolicy's refusal of a rule with problems: every one of them, and its notes. */
function refusalOf(reading: RuleReading): string {
  return [`${reading.where} wasn't saved: ${reading.problems.map((p) => p.text).join('; ')}.`, ...notesOf(reading, true)].join(' ');
}

/** gate.json, or the host's starting rules, as the gate reads them. */
type ConfigReading =
  /** Not used: why, and what a change would edit, since one that parses is
   *  edited as written, whether it's used or not (rulesForChange); where it's
   *  the rules left out, each one's name, or undefined for one without. */
  | { refused: string; listed: Listed; silenced?: Array<string | undefined> }
  | {
    /** What's in force from it. */
    config: GateConfig;
    /** Each rule as given, as read, and what's done with it. */
    rules: Array<{ raw: unknown; reading: RuleReading; outcome: RuleOutcome }>;
    /** What the gate says of it, each a sentence: its own problems and notes, then each rule's. */
    sentences: string[];
    /** Its own fields as loaded, and its rule list, each rule as written, for
     *  a write to edit by name; or, for one with no rule list to edit (a list,
     *  or a "policies" that isn't one and holds something), what it is instead. */
    listed: Listed;
  };

/** A gate.json's own fields and its rule list, as written, or why it has none a write could edit. */
type Listed = { top: Record<string, unknown>; rules: unknown[] } | { noList: string };

/** A rule's name as written, when it has a usable one. */
function nameOf(rule: unknown): string | undefined {
  return isPlainObject(rule) && typeof rule.name === 'string' && rule.name ? rule.name : undefined;
}

/** What a load of gate.json says, from what its reading says of it: nothing, when that's nothing. */
function loadNote(sentences: readonly string[]): string | null {
  return sentences.length > 0 ? `gate.json loaded. ${sentences.join(' ')}` : null;
}

/** The names of the rules a gate.json holds as written: none, for one with no rule list. */
function heldNames(listed: Listed): Set<string> {
  return new Set('noList' in listed ? [] : listed.rules.map(nameOf).filter((name): name is string => name !== undefined));
}

/**
 * gate.json, or the host's starting rules, read (`file` names which in
 * messages). A file earlier releases loaded loads as they read it, with a
 * note naming what they didn't read: a list is read as no rules under the
 * default "always", and a slip of "policies", a name the gate doesn't read
 * (a list of rules parked under one included), a field of a rule at the
 * file's top and a "policies" that isn't a list each as nothing, so where
 * "policies" writes no rules the file has none, and its default decides every
 * event. A "policies" holding nothing, an empty list or one that isn't a
 * list, writes no rules, as one left out does. Earlier releases refused it
 * whole where it isn't an object, or its default isn't one of the three, and
 * it isn't used. Each rule is read on its own. Under a default that holds
 * events back, a rule left out that could wake the agent would hold back what
 * it was written to wake on, so the file isn't used, as earlier releases,
 * which refused such a rule and so the file, didn't use it. `start` is what a
 * later start ran over a gate.json with no rules of its own, for its note: the
 * host's starting rules beside one with no rule list, or, where gate.json
 * isn't used at that start, the clause saying why and what runs instead
 * (notUsedClause), which the sentence saying it has no rules carries.
 */
function readConfig(
  raw: unknown, file: 'gate.json' | 'the starting config', start?: 'beside' | { notUsed: string },
): ConfigReading {
  const File = file === 'gate.json' ? file : 'The starting config';
  if (Array.isArray(raw)) {
    return {
      config: { policies: [], default: 'always' },
      rules: [],
      sentences: [
        `${File} is a list, where an object is needed, such as {"policies": [{"name": "my-rule", "behavior": "always"}]}, `
        + (start === 'beside'
          ? 'so none of it is read, and the gate runs the host\'s starting rules beside it, under the default, "always".'
          : 'so none of it is read, and every event gets the default, "always".'),
      ],
      listed: { noList: `${File} is a list` },
    };
  }
  if (!isPlainObject(raw)) return { refused: `${file} must be a JSON object`, listed: { noList: `${File} is ${shownValue(raw)}` } };

  const sentences: string[] = [];
  // At a start that doesn't use it, what having no rules does is that.
  const notUsedWhy = typeof start === 'object' ? start.notUsed : undefined;
  const notUsed = notUsedWhy === undefined ? undefined : `it has no rules, so ${notUsedWhy}`;
  const obj = withoutEmpty(file, raw, sentences, { ...configLeftOut(raw.default), ...(notUsed ? { policies: notUsed } : {}) });
  // Here a name holding "default" or "policies" isn't a slip of it: at the
  // top, such a name can be a label of the file ("policiesUpdated").
  const names = fieldNames(obj, CONFIG_FIELDS, false);
  const { misplaced, rest } = placedElsewhere(names.unread, homesOf(file, CONFIG_FIELDS));
  noteUnread(file, rest, CONFIG_FIELDS, sentences);
  for (const m of misplaced) {
    sentences.push(
      `${file} has ${misplacedShown(m)}, which the gate doesn't read here, so ${m.keys.length === 1 ? 'it does' : 'they do'} nothing.`,
    );
  }
  // A "policies" holding nothing writes no rules, as one left out does.
  const noPolicies = obj.policies === undefined || holdsNothing(obj.policies);
  // What a change edits, used or not: its own fields and rule list as written
  // (a list left out, null or "", or one holding nothing, is an empty one),
  // beside whatever else it holds; or, where "policies" isn't a list and holds
  // something, what it is instead, since a list there would write over it.
  const listed: Listed = noPolicies || Array.isArray(obj.policies)
    ? { top: raw, rules: Array.isArray(obj.policies) ? obj.policies : [] }
    : { noList: `${File}'s "policies" is ${shownValue(obj.policies)}` };
  const given = obj.default;
  if (given !== undefined && given !== 'always' && given !== 'defer' && given !== 'skip') {
    return { refused: `${file} "default" must be "always", "defer", or "skip", got: ${shownValue(given)}`, listed };
  }
  const defaultBehavior = given ?? 'always';
  // Beside a start that runs the host's starting rules, since it has no list to add them to, they're what its default
  // meets; at one that doesn't use it, what runs in its place is.
  const noRules = start === 'beside'
    ? `it has no rules, so the gate runs the host's starting rules beside it, under its default, "${defaultBehavior}"`
    : notUsed ?? configLeftOut(defaultBehavior).policies;
  for (const slip of names.slips) {
    let read = SLIP_READ;
    // Where "policies" writes no rules, what a slip of it holds leaves the file with none.
    if (slip.meant.includes('policies') && noPolicies) read = `and ${noRules}`;
    else if (slip.meant.includes('default') && obj.default === undefined) read = 'so its default is "always"';
    sentences.push(`${File} has ${slipShown(slip)}, which the gate doesn't read, ${read}.`);
  }
  const policies: unknown[] = Array.isArray(obj.policies) ? obj.policies : [];
  if (!Array.isArray(obj.policies) && obj.policies !== undefined) {
    sentences.push(
      `${File}'s "policies" is ${shownValue(obj.policies)}, where a list of rules is needed, such as `
      + `[{"name": "my-rule", "behavior": "always"}], and ${noRules}.`,
    );
  }

  const rules = policies.map((rule, i) => {
    const reading = readRule(rule, `The ${ordinal(i + 1)} rule`, file);
    return { raw: rule, reading, outcome: ruleOutcome(reading) };
  });
  if (defaultBehavior !== 'always') {
    const silenced = rules.filter((rule) => rule.outcome === 'left-out' && !rule.reading.quiet);
    if (silenced.length > 0) {
      const one = silenced.length === 1;
      return {
        refused: [
          `${file} leaves out ${one ? 'a rule' : 'rules'} that could wake the agent, and under its default, "${defaultBehavior}", `
          + `what ${one ? 'it was' : 'they were'} written to wake it on would be held back.`,
          ...silenced.flatMap((rule) => readingSentences(rule.reading, rule.outcome)),
        ].join(' '),
        listed,
        silenced: silenced.map((rule) => nameOf(rule.raw)),
      };
    }
  }
  for (const rule of rules) sentences.push(...readingSentences(rule.reading, rule.outcome));
  // A list with no rules, or none the gate reads, where no sentence above said it has none.
  if (notUsed !== undefined && !sentences.some((said) => said.includes(notUsed))) {
    sentences.push(`${File} has no rules${rules.length > 0 ? ' but ones the gate leaves out' : ''}, so ${notUsedWhy}.`);
  }
  return {
    config: {
      policies: rules.filter((rule) => rule.outcome !== 'left-out').map((rule) => rule.reading.policy as GatePolicy),
      default: defaultBehavior,
    },
    rules,
    sentences,
    listed,
  };
}

/** One of the host's starting rules: as given, with its name when it has one, and as read. */
interface StartingRule { name: string | undefined; raw: unknown; policy: GatePolicy | undefined; quiet: boolean }

/** The host's starting rules (initialConfig), read as gate.json is, for the seed and the reconcile. */
interface StartingRules {
  /** Why none of them is used, when that's so. */
  refusedWhole?: string;
  /** What they put in force when gate.json can't be loaded: each rule not left out, as read. */
  config?: GateConfig;
  /** With `config`, the starting config as given, which a first start writes,
   *  since gate.json is read the same way. */
  given?: unknown;
  /** Each starting rule as given, with its name when it has one, for the reconcile to add by name, and as read:
   *  the rule, unless it's left out, and whether it wakes on none of what it matches (RuleReading.quiet). */
  rules: StartingRule[];
  /** What the gate says of them, each a sentence. */
  sentences: string[];
}

function readStartingRules(raw: unknown): StartingRules {
  const read = readConfig(raw, 'the starting config');
  if ('refused' in read) return { refusedWhole: read.refused, rules: [], sentences: [] };
  return {
    config: read.config,
    given: raw,
    rules: read.rules.map((rule) => ({ name: nameOf(rule.raw), raw: rule.raw, policy: rule.reading.policy, quiet: rule.reading.quiet })),
    sentences: read.sentences,
  };
}

/**
 * The recipe the gate last applied (lastRecipePath), as written, or null when
 * it has none on record. It's read as the host's starting rules are, so a
 * recipe recorded as given reads back as the start read it. A record that
 * exists and isn't one the gate wrote (it can't be read, isn't JSON, is
 * refused as the starting rules are, or names a rule twice) gives null with
 * the reason, which quotes nothing from the file but a rule's name: a start
 * then removes and redefines nothing, as the first does, and says why.
 */
function readLastRecipe(path: string): { recipe: WrittenConfig | null; problem?: string } {
  if (!existsSync(path)) return { recipe: null };
  let raw: unknown;
  try {
    raw = parseGateJson(readFileSync(path, 'utf-8'));
  } catch (err) {
    const code = (err as NodeJS.ErrnoException).code;
    return { recipe: null, problem: code ? `reading it failed with ${code}` : "it isn't JSON" };
  }
  const read = readStartingRules(raw);
  if (read.refusedWhole !== undefined) return { recipe: null, problem: "it isn't read as the starting rules are" };
  const rules = read.rules.map((rule) => rule.raw);
  const twice = duplicateName(rules);
  if (twice !== undefined) return { recipe: null, problem: `it names the rule ${quotedValue(twice)} twice` };
  return { recipe: { rules, default: isPlainObject(raw) ? raw.default : undefined } };
}

/**
 * A rule's meaning, for the start's merge: the rule as the gate reads it,
 * where it reads, and as written where it doesn't. So a rule `wake_add_rule`
 * wrote as read agrees with the same rule written more briefly.
 */
function ruleMeaning(rule: unknown): string {
  const reading = readRule(rule, 'A rule');
  return reading.policy ? `read ${canonical(reading.policy)}` : `written ${canonical(rule)}`;
}

/** What a start's write of the host's starting rules to gate.json did. */
type StartWrite =
  | { kind: 'none' }
  /** A first start's write of the starting rules threw: at its open, or partway. */
  | { kind: 'seed-failed'; error: string; atOpen: boolean }
  /**
   * A later start's write to gate.json threw, or couldn't be made; `config` is
   * what it was writing: the rules it read plus the ones it was adding
   * (`names`), with the merge's other changes (`changing`: the rules it was
   * removing, redefining or moving, and "default").
   */
  | {
    kind: 'reconcile-failed'; names: string[]; changing?: string[]; error: string; atOpen: boolean; config: GateConfig;
    /** The text it was writing, whose reading is `config`, and what a load of it says, when the write itself failed. */
    text?: string;
    note?: string | null;
    sentences?: readonly string[];
  }
  /** A later start over a gate.json with no rule list to add the ones it lacks to: `config` is gate.json's default with them, which the gate runs beside it, unsaved. */
  | { kind: 'reconcile-unsaved'; names: string[]; error: string; config: GateConfig }
  /** A later start over a gate.json with no rules of its own (no rule list, an empty one, or one holding only rules the
   *  gate leaves out) whose default, `default`, holds events back, where the host's starting rules can't all be put in
   *  force beside it or in it: some that could wake the agent are left out (`leftOut`, by name, and `nameless`, a count of
   *  those with no name) or kept out by gate.json's rules of their names, which the gate leaves out (`heldOut`); or
   *  they're refused whole under their own default. gate.json isn't used at that start, which runs as one without it
   *  does. */
  | {
    kind: 'start-without'; default: NonNullable<GateConfig['default']>;
    leftOut?: string[]; nameless?: number; heldOut?: string[];
  };

/**
 * What gate_status says about the start, which stays until the next one: the
 * host's starting rules that couldn't be used and what the start did instead,
 * how it read them past problems, and rules a reconcile couldn't add. Worded
 * about the start, so later writes and reloads
 * leave it true; configSource says what's in force now. `held` is the names
 * of the rules gate.json holds as written, when it loaded.
 */
function describeStart(starting: StartingRules, write: StartWrite, held: ReadonlySet<string> | null): string | null {
  const parts: string[] = [];
  if (starting.refusedWhole !== undefined) {
    // gate.json's rules: as loaded, or as read before a write of the start's
    // own left it unable to load; or none, where gate.json wasn't used either.
    const instead = write.kind === 'start-without'
      ? `gate.json, which has no rules the gate reads, wasn't used either: under its default, "${write.default}", it would hold back every `
        + 'event, so the gate started with no rules, as a start without gate.json does. Giving gate.json rules under '
        + '"policies", or fixing the starting rules, puts rules in force (a fix to the starting rules, at the next start).'
      : held !== null || write.kind === 'reconcile-failed'
        ? "The gate started with gate.json's rules."
        : 'The gate started with no rules, as on a host without starting rules.';
    parts.push(`At start, the host's starting rules weren't used: ${sentence(starting.refusedWhole)} ${instead}`);
  }
  if (starting.sentences.length > 0) parts.push(`In the host's starting rules, ${starting.sentences.join(' ')}`);
  // A reconcile whose write failed and left gate.json loading: the rules it
  // was adding didn't reach it, unless the write landed before failing.
  if (write.kind === 'reconcile-failed' && held) {
    if (!write.names.every((name) => held.has(name))) {
      parts.push(
        `At start, the host's starting rules ${quotedList(write.names)} couldn't be added to gate.json (${write.error}), `
        + "so they weren't put in force. "
        + (write.text !== undefined
          ? 'Whoever runs this host can fix what kept them from being written.'
          : 'A start adds them once what kept them out is fixed.'),
      );
    }
    // The merge's other changes: removals, redefinitions, moves and the default.
    if (write.changing?.length) {
      parts.push(
        `At start, the recipe's changes to gate.json (${quotedList(write.changing)}) `
        + (write.atOpen
          ? `weren't saved (${write.error}), so the gate started with gate.json's rules as they were. `
          : `may not all have been saved (${write.error}): the gate started with gate.json as the write left it. `)
        + (write.text !== undefined
          ? 'Whoever runs this host can fix what kept them from being written.'
          : 'A start applies them once what kept them out is fixed.'),
      );
    }
  }
  return parts.length > 0 ? parts.join(' ') : null;
}

/**
 * Why gate.json, which has no rules of its own, isn't used at a start that runs
 * as one without it (start-without), and what runs in its place: the clause
 * after "it has no rules, so" in its note.
 */
function notUsedClause(write: Extract<StartWrite, { kind: 'start-without' }>, starting: StartingRules): string {
  const back = 'Giving gate.json rules under "policies"';
  const out = outOfForce(write);
  if (out) {
    return `it isn't used at this start: under its default, "${write.default}", ${out.said}, so the gate runs the starting `
      + `rules under their own default, "${starting.config?.default ?? 'always'}", as a start without gate.json does. ${back}, or ${out.fix}, puts it in use`
      + (out.nextStart ? ' (a fix to the starting rules, at the next start)' : '');
  }
  return `under its default, "${write.default}", it would hold back every event: it isn't used at this start, and the gate runs `
    + `no rules, as a start without gate.json does, so every event gets the default, "always". ${back}, or fixing the starting rules, puts rules in force`
    + ' (a fix to the starting rules, at the next start)';
}

/**
 * The starting rules a start that doesn't use gate.json couldn't put in force
 * beside it or in it, which could wake the agent, and what would put them in
 * force: null where the starting rules were refused whole.
 */
function outOfForce(write: Extract<StartWrite, { kind: 'start-without' }>): { said: string; fix: string; nextStart: boolean } | null {
  const nameless = write.nameless ?? 0;
  const left = [...(write.leftOut ?? []).map((name) => quotedValue(name)), ...(nameless === 0 ? [] : [nameless === 1 ? 'one with no name' : `${nameless} with no name`])];
  const held = write.heldOut ?? [];
  const said: string[] = [];
  const fix: string[] = [];
  if (left.length > 0) {
    said.push(`the host's starting rules would leave out ${joinedList(left)}, which could wake the agent`);
    fix.push(`fixing ${joinedList(left)} in the starting rules`);
  }
  if (held.length > 0) {
    said.push(`the host's ${quotedList(held)}, which could wake the agent, would be kept out by gate.json's `
      + `${held.length === 1 ? 'rule of that name' : 'rules of those names'}, which the gate leaves out`);
    fix.push(`fixing gate.json's ${quotedList(held)}`);
  }
  // While gate.json has no rules of its own, every one of them has to be put
  // in force for it to be used, so where both kinds keep it out, both fixes
  // are needed; giving gate.json rules of its own is the other way, which the
  // entry gives first.
  // The starting rules are read at a start, so a fix to them puts gate.json in
  // use from the next one.
  return said.length > 0
    ? { said: said.join(', and '), fix: fix.length > 1 ? `both ${fix.join(', and ')}` : fix[0]!, nextStart: left.length > 0 }
    : null;
}

/**
 * What gate_status says when the start left rules in force unsaved: a first
 * start's seed that failed, a reconcile whose write left gate.json unable to
 * load (`loaded` false), or, over a gate.json with no rule list (`loaded`
 * true), the starting rules it lacks, run beside it, or, over one with no rules
 * of its own, the starting rules run under their own default where gate.json
 * isn't used. It goes once gate.json is written, or a reload applies its text
 * or, but where the start ran rules beside or in place of such a gate.json,
 * finds it holding the text in force.
 */
function describeUnsaved(starting: StartingRules, write: StartWrite, loaded: boolean): string | null {
  if (write.kind === 'reconcile-unsaved') {
    if (!loaded) return null;
    return `At start, the host's starting rules ${quotedList(write.names)} couldn't be added to gate.json (${write.error}). `
      + `The gate runs them under gate.json's default, "${write.config.default ?? 'always'}", as if gate.json held them, but `
      + "they aren't saved in it: once gate.json changes and loads, what it holds is in force instead. Once gate.json has a "
      + 'list of rules under "policies", a start adds them to it, as to any gate.json with a list.';
  }
  if (write.kind === 'start-without') {
    // Starting rules refused whole put none in force, and describeStart says so.
    const out = outOfForce(write);
    if (!out) return null;
    return `At start, gate.json, which has no rules the gate reads, wasn't used: under its default, "${write.default}", ${out.said}. The gate `
      + `runs the starting rules under their own default, "${starting.config?.default ?? 'always'}", as a start without gate.json `
      + 'does, but they aren\'t saved in it: once gate.json changes and loads, what it holds is in force instead. Giving '
      + `gate.json rules under "policies", or ${out.fix}, puts it in use`
      + `${out.nextStart ? ' (a fix to the starting rules, at the next start)' : ''}.`;
  }
  if (loaded) return null;
  if (write.kind === 'seed-failed') {
    return write.atOpen
      ? `At start, gate.json couldn't be created (${write.error}), so the host's starting rules are in force but aren't saved in it. `
        + 'Whoever runs this host can fix what keeps it from being written.'
      : `At start, writing the host's starting rules to gate.json failed partway (${write.error}), so gate.json may be left `
        + "part-written. The starting rules are in force but aren't saved in it, and a restart before gate.json is fixed starts "
        + 'from them too. Whoever runs this host can fix what kept it from being written, and gate.json.';
  }
  if (write.kind === 'reconcile-failed') {
    // A write of the recipe's merge that did more than add rules, or one that only added them.
    const merging = (write.changing?.length ?? 0) > 0;
    const changes = quotedList([...write.names, ...(write.changing ?? [])]);
    const what = merging
      ? write.atOpen
        ? `the recipe's changes to gate.json (${changes}) couldn't be written (${write.error}), and gate.json couldn't be loaded after that`
        : `writing the recipe's changes to gate.json (${changes}) failed partway (${write.error}), so gate.json may be left part-written`
      : write.atOpen
        ? `the host's starting rules ${quotedList(write.names)} couldn't be added to gate.json (${write.error}), and gate.json `
          + "couldn't be loaded after that"
        : `adding the host's starting rules ${quotedList(write.names)} to gate.json failed partway (${write.error}), so gate.json `
          + 'may be left part-written';
    // What those rules hold that the gate reads past or leaves out, since
    // gate.json's own entry is now its load error.
    const read = write.sentences?.length ? `, read as a load reads them: ${write.sentences.join(' ')}` : '.';
    const runs = merging ? 'the rules that write held' : "the rules it read from gate.json and the ones it was adding";
    return `At start, ${what}. The gate runs ${runs}, which aren't saved${read} `
      + `A restart before gate.json is fixed starts from ${starting.config ? "the host's starting rules" : 'no rules'}. `
      + 'Whoever runs this host can fix what kept it from being written, and gate.json.';
  }
  return null;
}

// ---------------------------------------------------------------------------
// Shadow lint — prove (conservatively) when rule ordering makes a rule dead
// ---------------------------------------------------------------------------

/** Set-inclusion helper for exact-string lists. */
function subsetOf(a: string[], b: string[]): boolean {
  return a.every((x) => b.includes(x));
}

/** A glob field on the EARLIER rule is at least as broad as the LATER rule's
 *  when it's absent, the universal "*", or literally identical. Anything
 *  cleverer (real glob subsumption) is out of conservative scope. */
function globAtLeastAsBroad(earlier: string | undefined, later: string | undefined): boolean {
  if (earlier === undefined || earlier === '*') return true;
  return earlier === later;
}

/** The event types the gate can see from an MCPL server: its pushes and its
 *  channels' messages. */
export const MCPL_GATE_EVENT_TYPES: readonly string[] = ['mcpl:push-event', 'mcpl:channel-incoming'];

/** The event types a host knows a source sends (EventGate's
 *  `eventTypesFrom`), or undefined when it could send any. */
export type EventTypesFrom = (source: string) => readonly string[] | undefined;

/** The event types `rule` can match: its scope's, narrowed to those its
 *  source is known to send; 'all' when neither says. */
function typesSeenBy(rule: GatePolicy, eventTypesFrom?: EventTypesFrom): { types: string[] | 'all'; known: boolean } {
  const scope = rule.match.scope && rule.match.scope.length > 0 ? rule.match.scope : undefined;
  const source = rule.match.source;
  let sent: readonly string[] | undefined;
  if (eventTypesFrom && source !== undefined && !source.includes('*')) {
    try {
      sent = eventTypesFrom(source);
    } catch {
      sent = undefined;
    }
  }
  if (scope && sent) return { types: scope.filter((t) => sent!.includes(t)), known: true };
  if (scope) return { types: scope, known: true };
  if (sent) return { types: [...sent], known: true };
  return { types: 'all', known: false };
}

/**
 * Whether `earlier` provably matches events `later` would match, so that
 * `later` doesn't see them when `earlier` sits before it and consumes its
 * matches: the event types concerned, whether that's every event `later`
 * would match, and whether `later` is known to see those types. Returns null
 * when it can't be proven (which is not proof of safety — the lint is
 * deliberately one-sided so every note it emits is true).
 */
function subsumedEventTypes(
  earlier: GatePolicy,
  later: GatePolicy,
  eventTypesFrom?: EventTypesFrom,
): Omit<ShadowWarning, 'earlier' | 'later'> | null {
  const e = earlier.match;
  const l = later.match;

  // Event types: which of those `later` can match does `earlier` cover?
  const seen = typesSeenBy(later, eventTypesFrom);
  const earlierTypes = e.scope && e.scope.length > 0 ? e.scope : 'all';
  let eventTypes: string[] | 'all';
  let whole: boolean;
  let known = seen.known;
  if (earlierTypes === 'all') {
    eventTypes = seen.types;
    whole = true;
  } else if (seen.types === 'all') {
    // `later` matches every type; `earlier` only consumes its own scope, so
    // the overlap is partial — exactly those types, which may never reach
    // `later`.
    eventTypes = earlierTypes;
    whole = false;
  } else {
    const overlap = seen.types.filter((t) => earlierTypes.includes(t));
    if (overlap.length === 0) return null;
    eventTypes = overlap;
    whole = overlap.length === seen.types.length;
    known = true;
  }
  if (Array.isArray(eventTypes) && eventTypes.length === 0) return null;

  // Every remaining discriminator on `earlier` must be at least as broad as
  // `later`'s, otherwise some `later` events slip past `earlier`.
  if (!globAtLeastAsBroad(e.source, l.source)) return null;
  if (!globAtLeastAsBroad(e.channel, l.channel)) return null;
  if (!globAtLeastAsBroad(e.mount, l.mount)) return null;
  if (!globAtLeastAsBroad(e.pathGlob, l.pathGlob)) return null;

  if (e.filter) {
    if (!l.filter || e.filter.type !== l.filter.type || e.filter.pattern !== l.filter.pattern) {
      return null;
    }
  }

  // metadataTrue / tagsAny are OR-lists: earlier subsumes when later's list
  // is a subset of earlier's (any event satisfying later then satisfies
  // earlier too). tagsAll / tagsNone are AND/NOT constraints: earlier
  // subsumes when its constraints are a subset of later's.
  if (e.metadataTrue && e.metadataTrue.length > 0) {
    if (!l.metadataTrue || !subsetOf(l.metadataTrue, e.metadataTrue)) return null;
  }
  if (e.tagsAny && e.tagsAny.length > 0) {
    if (!l.tagsAny || !subsetOf(l.tagsAny, e.tagsAny)) return null;
  }
  if (e.tagsAll && !subsetOf(e.tagsAll, l.tagsAll ?? [])) return null;
  if (e.tagsNone && !subsetOf(e.tagsNone, l.tagsNone ?? [])) return null;

  return { eventTypes, whole, known };
}

/**
 * Find rules an earlier, broader rule keeps from applying (first match wins),
 * in whole or for some event types.
 * The 2026-08-08 Mythos incident is the canonical catch: a prepended
 * `{scope:[mcpl:channel-incoming]}` sampler silently made the
 * direct-address and mention rules dead for the whole incoming lane.
 * `passthrough` observers shadow nothing — non-firing matches fall through.
 * `eventTypesFrom` leaves out types a rule's source is known never to send:
 * a rule for an MCPL server's events isn't told about another rule that
 * takes every `external-message`.
 */
export function findShadowedPolicies(policies: GatePolicy[], eventTypesFrom?: EventTypesFrom): ShadowWarning[] {
  const out: ShadowWarning[] = [];
  for (let i = 0; i < policies.length; i++) {
    const earlier = policies[i];
    // A suppress rule lets addressed events and the heartbeat's by, so it
    // can't be said to take every event of a later rule.
    if (earlier.passthrough || earlier.suppress) continue;
    for (let j = i + 1; j < policies.length; j++) {
      const found = subsumedEventTypes(earlier, policies[j], eventTypesFrom);
      if (found) {
        out.push({ earlier: earlier.name, later: policies[j].name, ...found });
      }
    }
  }
  return out;
}

/** A ShadowWarning in words, used in tool results, traces, and gate_status
 *  alike so the same note reads the same way everywhere. It says which of
 *  three it is (the rule never applies; it misses some of its events; it
 *  may not be meant for those events at all) and what to do. */
export function formatShadowWarning(w: ShadowWarning): string {
  const later = quotedValue(w.later);
  const earlier = quotedValue(w.earlier);
  const move = `move ${later} above ${earlier} (wake_add_rule with the whole rule and insertBefore: ${quotedValue(w.earlier)})`;
  if (w.whole) {
    return `${later} never applies: ${earlier} comes first and matches every event ${later} would. `
      + `If ${later} should apply, ${move}, or narrow ${earlier}.`;
  }
  const types = w.eventTypes === 'all' ? 'all' : w.eventTypes.map((type) => quotedValue(type).slice(1, -1)).join(', ');
  if (w.known) {
    return `${earlier} comes first and takes ${later}'s ${types} events, so ${later} applies only to its others. `
      + `If it should apply to those too, ${move}.`;
  }
  return `${earlier} comes first and takes every ${types} event, so ${later} sees none. `
    + `Nothing to do unless ${later} is meant for ${types} events; then ${move}. `
    + `A scope on ${later} naming the event types it's for clears this note.`;
}

/** The text of a thrown value, for a log line. It never throws itself, whatever was thrown. */
function errorText(err: unknown): string {
  try {
    return err instanceof Error ? err.message : String(err);
  } catch {
    return 'a value that could not be printed';
  }
}

class PartialDelivery extends Error {
  constructor(readonly woke: readonly string[], readonly notWoken: readonly string[], cause: unknown) {
    super(errorText(cause), { cause });
  }
}

/**
 * Runs a batch's delivery to `woken`, which pushes each agent it wakes to
 * `woke`: a throw once any is woken is a PartialDelivery naming them and the
 * rest; one before any wake is thrown as it is.
 */
function deliveredTracking(woke: string[], woken: readonly string[], deliver: () => void): void {
  try {
    deliver();
  } catch (err) {
    if (woke.length === 0) throw err;
    throw new PartialDelivery(woke, woken.filter((name) => !woke.includes(name)), err);
  }
}

function deliveredInPart(err: unknown): string | undefined {
  if (!(err instanceof PartialDelivery)) return undefined;
  const one = err.notWoken.length === 1;
  return `woke ${joinedList(err.woke)}, and delivering it threw (${err.message}), `
    + `so it's dropped for ${joinedList(err.notWoken)}, who ${one ? "isn't" : "aren't"} woken`;
}

/**
 * Run a caller's callback once the change it's told of is made and traced. A
 * throw from it is logged, not thrown, so the call answers as the change it
 * made: told the change had failed, an agent could make it a second time.
 */
function afterChange(name: string, callback: () => void): void {
  try {
    callback();
  } catch (err) {
    console.error(`[gate] ${name} threw once the change was made, and the change stands: ${errorText(err)}`);
  }
}

/** The privileged-users file's error when some entries of its list aren't user ids. */
function skippedPrivilegedIds(skipped: unknown[], loaded: number, path: string): string {
  const one = skipped.length === 1;
  const shown = skipped.slice(0, 5).map((x) => {
    if (typeof x === 'number' && Number.isInteger(x)) {
      return `${x} (a number this large can't be read exactly: write the id as a string, in quotes)`;
    }
    const json = quotedValue(x);
    return json.length > 40 ? `${safeSlice(json, 0, 39)}…` : json;
  });
  const more = skipped.length > shown.length ? `, and ${skipped.length - shown.length} more` : '';
  const rest = loaded === 0
    ? 'no id loaded, so no one is privileged'
    : `the ${loaded === 1 ? 'one id that did load is' : `${loaded} ids that did load are`} privileged`;
  return `${skipped.length} ${one ? 'entry' : 'entries'} in the privileged-users file, at ${path}, ${one ? "isn't a user id" : "aren't user ids"}, `
    + `so ${one ? 'it was' : 'they were'} skipped: ${shown.join(', ')}${more}. A user id is a non-empty string, or a safe integer `
    + `(a whole number within 2^53 - 1 of zero); ${rest}. Once ${one ? 'that entry is a user id' : 'those entries are user ids'}, the gate `
    + 'reads the file again at its next check for changes.';
}

// ---------------------------------------------------------------------------
// EventGate
// ---------------------------------------------------------------------------

export class EventGate {
  private configPath: string;
  private config: GateConfig;
  /** Optional agent-authored programmable gate (gate.js). */
  private gateScript: GateScript;
  private compiledPolicies: CompiledPolicy[] = [];
  /** The text of gate.json whose rules are in force, from a load or a write
   *  (or the start's reconcile, whose write failed); or, while what's in force
   *  is what a start ran beside gate.json or in its place (configSource not
   *  "file"), gate.json's text as that start found it.
   *  A reload parses the file again only when its text differs; a file that
   *  holds it again after failing to load (a chmod that makes it readable,
   *  an edit undone) needs nothing applied, only its error cleared. */
  private configText: string | undefined;
  /** The notes on fields the text in force has that the gate doesn't read, if any. */
  private configNote: string | null = null;
  private lastReloadCheck: number = 0;
  private configSource: 'file' | 'initial' | 'default' = 'default';
  private lastReloadTimestamp: number | null = null;
  /** The current problem with each file the gate reads, one each, replaced
   *  whenever that file is read again (gate_status `errors`). */
  private configError: string | null = null;
  /** Whether gate.json's error is one that keeps what it holds out of force
   *  (configUnreadable), so gate_status says what's in force instead. */
  private configUnused = false;
  private configFix: string | null = null;
  private privilegedError: string | null = null;
  /** What the start did with the host's starting rules that it couldn't use
   *  or add (describeStart), kept apart from gate.json's own error, until the
   *  next start. */
  private startNotice: string | null = null;
  /** The rules in force that the start couldn't save (describeUnsaved),
   *  until gate.json is written or a reload applies its text. */
  private startUnsaved: string | null = null;
  /** What the start's merge of the recipe couldn't do (seedOrReconcile), said with startNotice until the next start. */
  private startMergeNote: string | null = null;
  /** Whether the start's unsaved rules (startUnsaved) are a merge's that did more than add rules. */
  private startUnsavedMerged = false;

  // Debounce state
  private debounceTimers = new Map<string, DebounceState>();

  // Reply judge state (`judge` rules). The judge itself, when the host wires
  // one; without it a judge rule's batch is delivered as a debounce's.
  private judgeFn: JudgeFn | undefined;
  private judgeTimeoutMs: number;
  private judgeOnError: 'wake' | 'skip';
  /** Per rule, the batch the judge is deciding now. */
  private judging = new Map<string, JudgingState>();
  /** Per rule, a batch that fired while a turn changing the judged context ran or the host was
   *  quiesced, held to be judged once both are clear: the judge reads the
   *  context the turn leaves, which may already answer it. */
  private judgeHeld = new Map<string, { events: PendingEvent[]; judge: JudgeConfig }>();
  private judgeRecords = new Map<string, JudgeRecord>();
  private changesJudgedContextFn: ((agentName: string) => boolean) | undefined;
  /** Lifetime count of events dropped from batches waiting on the judge, at
   *  the inference buffer's cap (MAX_INFERENCE_BUFFER per rule). */
  private droppedJudgeEvents = 0;
  /** Judge requests failed in a row, and the newest failure's reason: a host
   *  whose provider can't serve the judge's model fails every time, which
   *  gate_status says once it's a streak (judgeFailingNotice). */
  private judgeFailStreak = 0;
  private judgeLastFailure = '';

  // Rate-limit state — policy name → key → bucket.
  private rateLimitBuckets = new Map<string, Map<string, RateBucket>>();
  // Passive-sample state — policy name → key → counter (count since last fire).
  private passiveSampleCounters = new Map<string, Map<string, number>>();
  // Per-policy denial / fire counters for status reporting.
  private rateLimitDenied = new Map<string, number>();
  private passiveSampleFires = new Map<string, number>();

  // Inference buffering
  private inferring = new Set<string>();
  private inferenceBuffer: PendingEvent[] = [];
  /** Host quiesce suppression — see setQuiesced. */
  private quiesced = false;
  /** Lifetime count of buffer-cap evictions (see bufferForInference). */
  private droppedBufferedEvents = 0;

  // Per-policy stats
  private stats = new Map<string, PolicyStats>();
  /** Suppress rules' scripts and their state (suppress-scripts.ts), kept beside gate.json. */
  private readonly suppressScripts: SuppressScripts;

  // The shadow lint's last findings (see refreshShadowWarnings), recomputed
  // on every config change and fingerprinted so an unchanged set doesn't
  // re-trace.
  private shadowWarningsFingerprint = '[]';
  /** See the constructor's `eventTypesFrom`. */
  private eventTypesFromFn: EventTypesFrom | undefined;

  // Observability counters for events that didn't match any policy
  private totalEvaluations = 0;
  private defaultTriggered = 0;
  private defaultSkipped = 0;
  private defaultByEventType = new Map<string, { triggered: number; skipped: number }>();

  // Sleep state (set via the `sleep` tool). evaluate() suppresses non-privileged
  // wakes while now() < sleepUntil. A self-wake timer (sleepTimer) fires an
  // inference when the window expires, so `sleep(N)` means "wake me in N
  // seconds" rather than merely lifting suppression and waiting for an external
  // event.
  private sleepUntil = 0;
  private sleepNote: string | undefined;
  private sleepSuppressed = 0;
  private sleepTimer: ReturnType<typeof setTimeout> | null = null;
  private sleepAgent: string | undefined;
  // From dispose() on, no sleep or self-wake timer is armed, though a turn a
  // failed stop() left running can still ask for one.
  private disposed = false;

  // Self-wake timers per agent (skip_reply's wake_in_seconds). Unlike sleep,
  // a self-wake suppresses NOTHING — it means "if nothing else wakes me by
  // then, wake me". Any turn start for the agent cancels its pending
  // self-wake (an external wake supersedes it; the timer would otherwise
  // land as a redundant empty wake right after the turn).
  private selfWakeTimers = new Map<string, ReturnType<typeof setTimeout>>();
  /** When each agent's pending self-wake fires, and what armed it
   *  (upcomingWakes). Read only while its timer is in selfWakeTimers, so an
   *  entry a fire or a cancel left behind says nothing. */
  private selfWakeDue = new Map<string, { at: number; source: string }>();

  // Privileged users who may wake the agent through sleep. Hot-reloaded from
  // privilegedUsersPath on change.
  private privilegedUsersPath: string | undefined;
  private privilegedUserIds = new Set<string>();
  /** The privileged-users file's text as last read, whether or not it loaded;
   *  undefined when it was missing or its last read failed. */
  private privilegedText: string | undefined;
  private lastPrivilegedCheck = 0;

  // Dependency-injected callbacks
  private emitTrace: (event: TraceEventInput) => void;
  private addMessageFn: (
    participant: string,
    content: Array<{ type: 'text'; text: string }>,
    metadata?: Record<string, unknown>,
    /** Registry agent to deliver into; absent = primary (historical). */
    forAgent?: string,
    /** Out-param: where the message landed, for the wake that goes with it. */
    placement?: WritePlacement,
    /** The agents the row is for; absent: the host's default for the write.
     *  The host stamps those of them that read where it stores the row, and
     *  its default when none does. */
    audience?: readonly string[],
  ) => unknown;
  private requestInferenceFn: (agentName: string, reason: string, source: string, provenance?: WakeProvenance, after?: WritePlacement) => void;
  private getAgentNamesFn: () => string[];
  /** Delivery-time re-check: is this channel held from the recipients now? */
  private isHeldFn: (serverId: string | undefined, channelId: string | undefined) => boolean;
  private resolveRouteChannelFn: (info: GateEventInfo) => string | undefined;
  private channelShownFn?: (channel: { serverId: string; channelId: string }) => string;
  private isNewestEntryFn?: (entry: GateEntryRef, recipients?: readonly string[]) => boolean;
  /** Clock injection — keeps the new rate_limit / passive_sample paths
   *  testable without monkey-patching Date.now globally. */
  private now: () => number;

  constructor(opts: {
    configPath: string;
    initialConfig?: GateConfig;
    privilegedUsersPath?: string;
    emitTrace: (event: TraceEventInput) => void;
    addMessage: (
      participant: string,
      content: Array<{ type: 'text'; text: string }>,
      metadata?: Record<string, unknown>,
      forAgent?: string,
      placement?: WritePlacement,
      audience?: readonly string[],
    ) => unknown;
    /** `after`: the placement of the message the wake is for, when it has
     *  one, so the host can drop the wake once a request that carried the
     *  message is answered. */
    requestInference: (agentName: string, reason: string, source: string, provenance?: WakeProvenance, after?: WritePlacement) => void;
    getAgentNames: () => string[];
    /**
     * Whether a channel is held from the recipients (a tune-out epoch in
     * force). A held event never enters a batch — admission runs before the
     * gate — but a hold can begin after an event was batched; at delivery
     * the batch is re-checked and held events are dropped (#232 H3).
     */
    isHeld?: (serverId: string | undefined, channelId: string | undefined) => boolean;
    /** Optional clock — defaults to Date.now. Tests inject for deterministic time. */
    now?: () => number;
    /** Per-event timeout (ms) for the optional gate.js script. Default 50. */
    scriptTimeoutMs?: number;
    /** How long a suppress rule's script may take for one event before the event is shown (ms). Default 50. */
    suppressScriptTimeoutMs?: number;
    /** The reply judge `judge` rules ask (JudgeConfig). Absent: a judge
     *  rule's batch is delivered as a debounce's, and gate_status says so. */
    judge?: JudgeFn;
    /** Whether a turn of this agent changes the context the judge reads. Such
     *  turns, and only they, hold a judge rule's batch until they end, and one
     *  that starts while the judge decides stops the judge, whose batch is
     *  then judged after the turn. Absent: every agent's turns do. */
    changesJudgedContext?: (agentName: string) => boolean;
    /** How long a judge request may take (ms). Default 20,000. */
    judgeTimeoutMs?: number;
    /** What a judge failure does: wake (default) or skip. */
    judgeOnError?: 'wake' | 'skip';
    /** Map an event to the registered channel it arrived on (the host knows
     *  how push-event origins compose into channel ids). The gate routes a
     *  batched wake by it, tests a policy's `match.channel` against it when
     *  the event's own id misses, and keys `keyBy: "channelId"` counts on it.
     *  A resolver that throws counts as returning nothing. Default: a
     *  channel-incoming event's own channel id; nothing for push events, so
     *  a push then matches and counts by its own id alone. */
    resolveRouteChannel?: (info: GateEventInfo) => string | undefined;
    /** How the agent is shown a channel, its server's and its id (the
     *  framework's ChannelRegistry.nameShown): a batched wake's summary names
     *  each channel so, since two servers' channels can share an id. Default:
     *  the id. */
    channelShown?: (channel: { serverId: string; channelId: string }) => string;
    /** Whether an MCPL event's own context entry is still the newest entry in
     *  the window a batched wake's line would be written to, with nothing
     *  waiting to be written there. A batched wake for that one message
     *  doesn't write its line when it fires: it hands the line to the wake
     *  (WakeProvenance.line), for a fresh start of the wake's turn to decide
     *  (WakeLine). With `recipients`, the windows are those agents', each of
     *  which the event must be newest in. Absent: every batched wake writes
     *  its line, as before. */
    isNewestEntry?: (entry: GateEntryRef, recipients?: readonly string[]) => boolean;
    /** The event types the gate can see from a source, when the host knows
     *  them (an MCPL server's id: MCPL_GATE_EVENT_TYPES), else undefined.
     *  The rule-order notes (findShadowedPolicies) leave out types a rule's
     *  source never sends. Absent: any source can send any type. */
    eventTypesFrom?: EventTypesFrom;
  }) {
    this.configPath = opts.configPath;
    // Before the rules are read: a start's merge can clear a rule's state, its script's included.
    this.suppressScripts = new SuppressScripts({
      statePath: join(dirname(opts.configPath), 'suppress-state.json'),
      ...(opts.suppressScriptTimeoutMs !== undefined ? { timeoutMs: opts.suppressScriptTimeoutMs } : {}),
    });
    this.privilegedUsersPath = opts.privilegedUsersPath;
    this.emitTrace = opts.emitTrace;
    this.addMessageFn = opts.addMessage;
    this.requestInferenceFn = opts.requestInference;
    this.getAgentNamesFn = opts.getAgentNames;
    this.isHeldFn = opts.isHeld ?? (() => false);
    this.resolveRouteChannelFn = opts.resolveRouteChannel ?? defaultRouteChannel;
    this.channelShownFn = opts.channelShown;
    this.isNewestEntryFn = opts.isNewestEntry;
    this.eventTypesFromFn = opts.eventTypesFrom;
    this.now = opts.now ?? (() => Date.now());
    this.judgeFn = opts.judge;
    this.changesJudgedContextFn = opts.changesJudgedContext;
    this.judgeTimeoutMs = opts.judgeTimeoutMs !== undefined && Number.isFinite(opts.judgeTimeoutMs) && opts.judgeTimeoutMs > 0
      ? Math.min(opts.judgeTimeoutMs, MAX_TIMER_MS)
      : DEFAULT_JUDGE_TIMEOUT_MS;
    this.judgeOnError = opts.judgeOnError === 'skip' ? 'skip' : 'wake';
    this.loadPrivileged();

    // Seed or reconcile the on-disk config from the host's starting rules
    // (`initialConfig`), which are read as gate.json is, rule by rule: a rule
    // with a problem is read past it, or left out (readConfig).
    //
    // First start: write `initialConfig` as given, since gate.json is read the
    // same way, and record it as the recipe last applied, beside gate.json.
    // Later starts: merge the recipe into gate.json against that record,
    // three ways and as written (seedOrReconcile), so a rule the recipe
    // dropped, renamed, moved or redefined follows it, while a rule edited at
    // run time or by `workspace--edit _config/gate.json`, and one no recipe
    // declared, stays. `default` follows the same rule: an unedited one takes
    // the recipe's.
    const initial = opts.initialConfig;
    const starting = initial !== undefined ? readStartingRules(initial) : undefined;
    const write: StartWrite = starting ? this.seedOrReconcile(starting) : { kind: 'none' };

    // Load config: gate.json; without it, the starting rules as read, unless
    // none of them is used; and otherwise no rules, as a host without any has. When a
    // reconcile's own write left gate.json unable to load, the gate runs what
    // that write held, the rules it read as the recipe's merge changed them,
    // since a failed write of ours shouldn't take rules out of force. Over a gate.json
    // with no rule list to add them to, it runs gate.json's default with the
    // starting rules it lacks, as earlier releases did once they had written
    // them over it, where seedOrReconcile gives them (reconcile-unsaved). Where
    // gate.json has no rules of its own and they can't run beside it or be
    // added to it (start-without), earlier releases couldn't load what they
    // wrote and ran the starting rules from memory, so gate.json isn't used,
    // and the start runs as one without it does.
    const read = this.readConfigFile();
    if (read.state === 'loaded') {
      // Beside a gate.json with no rule list, the host's starting rules it
      // lacks, and its note says they run beside it, or, in place of one with
      // no rules of its own, those a start without it runs, and its note says
      // why.
      const beside = write.kind === 'reconcile-unsaved';
      const without = write.kind === 'start-without' ? write : null;
      this.config = beside ? write.config : without ? (starting?.config ?? { ...DEFAULT_CONFIG }) : read.config;
      this.configText = read.text;
      const start = beside ? 'beside' : without && starting ? { notUsed: notUsedClause(without, starting) } : undefined;
      const asStarted = start ? readConfig(parseGateJson(read.text), 'gate.json', start) : null;
      this.configNote = asStarted && 'sentences' in asStarted ? loadNote(asStarted.sentences) : read.note;
      this.configError = this.configNote;
      this.configSource = beside || starting?.config && without ? 'initial' : without ? 'default' : 'file';
      if (this.configNote) console.error(`[gate] ${this.configNote}`);
    } else if (write.kind === 'reconcile-failed') {
      this.config = write.config;
      // A change over the part-written gate.json is refused; once gate.json is
      // gone, this text is what a change edits, so every rule it holds keeps its name.
      this.configText = write.text;
      this.configNote = write.note ?? null;
      this.configSource = 'file';
    } else {
      this.config = starting?.config ?? { ...DEFAULT_CONFIG };
      this.configSource = starting?.config ? 'initial' : 'default';
    }
    // What the start did is kept apart from gate.json's load error, so the
    // load above can't clear it when it succeeds.
    if (starting) {
      const described = describeStart(starting, write, read.state === 'loaded' ? heldNames(read.listed) : null);
      this.startNotice = [described, this.startMergeNote].filter((part): part is string => part !== null).join(' ') || null;
      this.startUnsaved = describeUnsaved(starting, write, read.state === 'loaded');
      this.startUnsavedMerged = write.kind === 'reconcile-failed' && (write.changing?.length ?? 0) > 0;
    }
    for (const said of [this.startNotice, this.startUnsaved]) {
      if (said) console.error(`[gate] ${said}`);
    }
    this.compiledPolicies = this.compilePolicies(this.config);
    this.refreshShadowWarnings('startup');

    // Programmable gate: an optional agent-authored `gate.js` next to gate.json.
    // Absent ⇒ inactive (zero overhead beyond a throttled stat check).
    this.gateScript = new GateScript(
      join(dirname(this.configPath), 'gate.js'),
      opts.scriptTimeoutMs ?? 50,
      this.now,
    );
  }

  // =========================================================================
  // Config loading
  // =========================================================================

  /**
   * Write the starting rules to gate.json, as given, when it's absent, and
   * record them as the recipe last applied (lastRecipePath); or, when it
   * loads, merge them into its own rule list against that record, three ways
   * and as written (reconcileWithRecipe), and record them. A rule as the last
   * recipe left it follows the new one, a rule edited since keeps its edit, a
   * rule no recipe declared stays, and `default` follows the same rule. A
   * rule gate.json holds holds its name, whether the gate reads it or leaves
   * it out. gate.json is written before the record, so a stop between the two
   * leaves a state the next start reads rightly: the other order would make
   * the old recipe's rules read as edits. Nothing is recorded where gate.json
   * isn't written as the merge asks, or a name is given twice. Where
   * gate.json has no rules of its own and, under its default, one of them that
   * could wake the agent can't be put in force (left out, with no name, or kept
   * out by a rule of gate.json's of its name that the gate leaves out), or
   * they're refused whole and that default holds events back, gate.json isn't
   * used at this start, which runs as one without it does. Otherwise, where
   * gate.json has no rule list to add them to, it writes nothing, and the gate
   * runs beside it those of them it reads. Says what it did when that wasn't
   * simply done or not needed.
   */
  private seedOrReconcile(starting: StartingRules): StartWrite {
    const read = this.readConfigFile();
    if (read.state === 'absent') {
      if (!starting.config) return { kind: 'none' };
      try {
        mkdirSync(dirname(this.configPath), { recursive: true });
        writeFileSync(this.configPath, JSON.stringify(starting.given, null, 2) + '\n');
      } catch (err) {
        return { kind: 'seed-failed', error: errorText(err), atOpen: beforeWriting(err) };
      }
      const twice = duplicateName(starting.rules.map((rule) => rule.raw));
      if (twice !== undefined) {
        this.startMergeNote = `At start, the recipe names the rule ${quotedValue(twice)} twice, so gate.json was seeded with it as given and it `
          + "wasn't recorded as the recipe last applied: a later start merges the recipe by name, once gate.json and the recipe "
          + 'name each rule once.';
      } else {
        this.recordRecipe(lastRecipePath(this.configPath), starting.given, 'gate.json was seeded with the recipe');
      }
      return { kind: 'none' };
    }
    if (read.state !== 'loaded') return { kind: 'none' };
    const held = heldNames(read.listed);
    const fileDefault = read.config.default ?? 'always';
    // No rule list, an empty one, or one holding only rules the gate leaves out.
    const noRules = read.config.policies.length === 0;
    // Starting rules refused whole put none beside or in a gate.json with no
    // rules of its own, which holds events back. Earlier releases wrote them
    // over it or into it, couldn't load what they wrote, and ran them from
    // memory, so gate.json isn't used at this start either.
    if (noRules && starting.refusedWhole !== undefined && fileDefault !== 'always') {
      return { kind: 'start-without', default: fileDefault };
    }
    // Nor can a start put in force, beside or in a gate.json with no rules of
    // its own, a starting rule a load leaves out, one with no name, which it
    // can't add by name, or one whose name gate.json holds in a rule the gate
    // leaves out, which keeps the host's rule of that name out. Where, under
    // gate.json's default, one of them could wake the agent, earlier releases
    // ran the starting rules from memory: they couldn't load what they wrote
    // over gate.json or into it, or, refusing its rule, didn't load it at all.
    // So gate.json isn't used at this start, which runs as one without it does.
    if (noRules && fileDefault !== 'always') {
      const out = starting.rules.filter((rule) => !rule.quiet && (rule.policy === undefined || (rule.name !== undefined && held.has(rule.name))));
      if (out.length > 0) {
        const named = out.flatMap((rule) => (rule.name === undefined ? [] : [rule.name]));
        return {
          kind: 'start-without',
          default: fileDefault,
          leftOut: named.filter((name) => !held.has(name)),
          nameless: out.length - named.length,
          heldOut: named.filter((name) => held.has(name)),
        };
      }
    }
    if ('noList' in read.listed) {
      const missing = starting.rules.filter((rule): rule is StartingRule & { name: string } => rule.name !== undefined && !held.has(rule.name));
      if (missing.length === 0) return { kind: 'none' };
      const names = missing.map((rule) => rule.name);
      // Adding them would write over what gate.json holds. Earlier releases
      // wrote them over it and ran them under its default, so the gate runs
      // them so, unsaved, beside it.
      const error = `${read.listed.noList}, so there's no list of rules to add them to without writing over what it holds`;
      // The ones it runs: a starting rule left out is named as the starting rules are read.
      const running = missing.flatMap((rule) => (rule.policy === undefined ? [] : [rule.policy]));
      if (running.length === 0) return { kind: 'reconcile-failed', names, atOpen: true, config: read.config, error };
      return { kind: 'reconcile-unsaved', names: running.map((policy) => policy.name), error, config: { policies: running, default: fileDefault } };
    }
    // Starting rules refused whole have nothing to merge or record.
    if (starting.refusedWhole !== undefined) return { kind: 'none' };
    // The merge, as written: gate.json's rule list and default against the
    // recipe's, three ways, with the recipe last applied.
    const recordPath = lastRecipePath(this.configPath);
    const last = readLastRecipe(recordPath);
    const given = isPlainObject(starting.given) ? starting.given : {};
    let merged: ReturnType<typeof reconcileWithRecipe>;
    let appended = false;
    let appendedNote = '';
    try {
      merged = reconcileWithRecipe(
        { rules: read.listed.rules, default: read.listed.top.default },
        { rules: starting.rules.map((rule) => rule.raw), default: given.default },
        last.recipe,
        ruleMeaning,
      );
    } catch (err) {
      // A name given twice: a merge by name can't say which rule was meant.
      // So the start adds the rules gate.json lacks, after its own, as
      // earlier releases did, and removes, redefines and records nothing.
      const missing = starting.rules.filter((rule): rule is StartingRule & { name: string } => rule.name !== undefined && !held.has(rule.name));
      const lacked = [...new Set(missing.map((rule) => rule.name))];
      appended = true;
      // What it did is said once its write is made (appendedNote), and a
      // write that fails is said as any start's is.
      const why = `At start, ${errorText(err)}, and the merge with the recipe needs one rule per name, so it didn't run`;
      const remedy = 'Once gate.json and the recipe name each rule once, a start merges the recipe.';
      this.startMergeNote = `${why}. ${remedy}`;
      appendedNote = `${why}: `
        + (lacked.length > 0
          ? `the start added the rules gate.json lacked (${quotedList(lacked)}), after its own, and removed, redefined and recorded nothing. `
          : 'gate.json is as it was, and nothing was recorded. ')
        + remedy;
      merged = {
        rules: [...read.listed.rules, ...missing.map((rule) => rule.raw)],
        default: read.listed.top.default,
        defaultChanged: false,
        changes: { ...noChanges(), added: missing.map((rule) => rule.name) },
      };
    }
    const { changes } = merged;
    if (last.problem !== undefined) changes.recordUnreadable = last.problem;
    const top = { ...read.listed.top };
    if (merged.defaultChanged) {
      if (merged.default === undefined) delete top.default;
      else top.default = merged.default;
    }
    const reconciled = { ...top, policies: merged.rules };
    const names = [...changes.added, ...changes.restored];
    const changing = [...changes.removed, ...changes.updated, ...changes.moved, ...(changes.defaultChange ? ['default'] : [])];
    const written = canonical(reconciled) !== canonical({ ...read.listed.top, policies: read.listed.rules });
    if (written) {
      // What the write holds, as a load reads it, for a write that fails partway.
      const holds = readConfig(reconciled, 'gate.json');
      if ('refused' in holds) {
        // A write of ours doesn't take gate.json's own rules out of force:
        // nothing is written or recorded, so it loads as it did. (With no
        // rules of its own, gate.json isn't used at this start, above.)
        const error = 'with them, gate.json would leave out a rule that could wake the agent, and under its default, '
          + `"${changes.defaultChange?.to ?? read.config.default ?? 'always'}", it wouldn't be used`;
        return { kind: 'reconcile-failed', names, changing, atOpen: true, config: read.config, error };
      }
      const text = JSON.stringify(reconciled, null, 2) + '\n';
      try {
        writeFileSync(this.configPath, text);
      } catch (err) {
        return {
          kind: 'reconcile-failed',
          names,
          changing,
          error: errorText(err),
          atOpen: beforeWriting(err),
          config: holds.config,
          text,
          note: loadNote(holds.sentences),
          sentences: holds.sentences,
        };
      }
    }
    if (appended) this.startMergeNote = appendedNote;
    // Said before the record is written, so a failed record write still
    // leaves what the start did to gate.json named. A start that only added
    // rules, since the merge couldn't run, is said in startNotice instead.
    const line = appended ? null : reconcileLine(changes);
    if (line) console.error(line);
    if (line || names.length > 0) {
      this.emitTrace({
        type: 'gate:config-reconciled',
        configPath: this.configPath,
        ...changes,
        // Every name the start added to gate.json, as an append's trace gave.
        addedPolicies: names,
      });
    }
    if (!appended && (!last.recipe || canonical({ rules: last.recipe.rules, default: last.recipe.default }) !== canonical({ rules: starting.rules.map((rule) => rule.raw), default: given.default }))) {
      this.recordRecipe(recordPath, starting.given, written ? 'gate.json holds the recipe merged into it' : 'the merge left gate.json as it was');
    }
    return { kind: 'none' };
  }

  /**
   * Record the starting config, as given, as the recipe last applied, after
   * gate.json holds what the start merged (`holds` says what that is). A
   * write that fails is said with the start: the next start merges against
   * the record as the write left it.
   */
  private recordRecipe(recordPath: string, given: unknown, holds: string): void {
    try {
      writeFileSync(recordPath, JSON.stringify(given, null, 2) + '\n');
    } catch (err) {
      this.startMergeNote = `At start, ${holds}, and the gate runs it, but recording the recipe in ${basename(recordPath)} failed `
        + `(${errorText(err)}), so the next start merges against the record as this write left it. Whoever runs this host can `
        + 'fix what kept it from being written.';
    }
  }

  /**
   * gate.json as it is on disk: absent; loaded; refused, when it's JSON that
   * readConfig doesn't use; or unreadable, when it can't be read or isn't
   * JSON (`notJson`, where it could be read). A loaded file comes with its note,
   * which names what it holds that does nothing or is read past a problem, and
   * a loaded or refused one with its own fields and rule list as written, for a
   * write to edit (Listed).
   * Reading applies nothing: whoever applies a loaded config records its text
   * as `configText`. With `unlessUnchanged`, a file whose text is
   * `configText` comes back `unchanged`, unparsed, since the rules in force
   * came from it, or are what a start ran beside it or in its place.
   */
  private readConfigFile(opts?: { unlessUnchanged?: boolean }):
    | { state: 'absent' }
    | { state: 'unchanged' }
    | { state: 'loaded'; config: GateConfig; text: string; note: string | null; listed: Listed }
    | { state: 'refused'; error: string; listed: Listed; silenced?: Array<string | undefined> }
    | { state: 'unreadable'; error: string; notJson?: true } {
    let raw: string;
    try {
      raw = readFileSync(this.configPath, 'utf-8');
    } catch (err) {
      if (!isMissing(err)) {
        const why = quotedValue(errorText(err));
        return this.configUnreadable(
          why, `gate.json, at ${this.configPath}, can't be read: ${why}`,
          'Whoever runs this host can make it a file the gate can read, and the gate reads it again at its next check for changes.',
        );
      }
      // No file is no problem with it: the rules in force stay.
      this.configError = null;
      this.configUnused = false;
      return { state: 'absent' };
    }
    // A file holding the text in force has that text's notes as its error,
    // whatever a failed read or a look at other text since left there: beside
    // the host's starting rules, they say those run beside it.
    const inForce = raw === this.configText;
    if (opts?.unlessUnchanged && inForce) {
      this.configError = this.configNote;
      this.configUnused = false;
      return { state: 'unchanged' };
    }
    let parsed: unknown;
    try {
      parsed = parseGateJson(raw);
    } catch (err) {
      const why = quotedValue(errorText(err));
      return {
        ...this.configUnreadable(
          why, `gate.json, at ${this.configPath}, isn't JSON: ${why}`,
          "Once it's JSON, the gate reads it again at its next check for changes.",
        ),
        notJson: true,
      };
    }
    const read = readConfig(parsed, 'gate.json');
    // JSON the gate doesn't use is still the operator's file, edited as written.
    if ('refused' in read) {
      const problem = read.refused.startsWith('gate.json ')
        ? `gate.json, at ${this.configPath},${read.refused.slice('gate.json'.length)}`
        : read.refused;
      return {
        ...this.configUnreadable(read.refused, problem, 'Once gate.json is mended, the gate reads it again at its next check for changes.'),
        state: 'refused', listed: read.listed, silenced: read.silenced,
      };
    }
    // A field the gate doesn't read does nothing, and a rule is read past a
    // problem or left out, so the file loads, and each is named.
    const note = loadNote(read.sentences);
    this.configError = inForce ? this.configNote : note;
    this.configUnused = false;
    return { state: 'loaded', config: read.config, text: raw, note, listed: read.listed };
  }

  /**
   * gate.json's current error, replacing the last one, and traced and logged
   * when it's new, so an edit that doesn't load is in the log once.
   */
  private configUnreadable(why: string, problem: string, fix: string | null = null): { state: 'unreadable'; error: string } {
    if (problem !== this.configError) {
      console.error(`[gate] ${this.configPath} couldn't be used (${why}), so what it holds isn't in force${fix ? `. ${fix}` : ''}`);
      this.emitTrace({
        type: 'gate:config-error',
        error: why,
        configPath: this.configPath,
      });
    }
    this.configError = problem;
    this.configFix = fix;
    this.configUnused = true;
    return { state: 'unreadable', error: why };
  }

  /**
   * gate.json's error as gate_status shows it: one that keeps what the file
   * holds out of force says what's in force instead, so it reads on its own.
   */
  private configErrorShown(): string | null {
    if (this.configError === null || !this.configUnused) return this.configError;
    return `${sentence(this.configError)} So what gate.json holds isn't in force, and the gate runs ${this.rulesRun()}.`
      + (this.configFix ? ` ${this.configFix}` : '');
  }

  /** What the gate runs, by where its rules came from, for a text that says so: "the host's starting rules". */
  private rulesRun(): string {
    if (this.config.policies.length === 0) return `no rules: every event gets the default, "${this.config.default ?? 'always'}"`;
    // Rules from a gate.json text, with the start's unsaved: only a start
    // whose reconcile write left gate.json unable to load runs those, since a
    // write of gate.json that lands, a reload that finds it holding a text
    // that loads, or, while gate.json's rules are in force, one that finds it
    // holding the text in force, clears startUnsaved.
    return this.configSource === 'file'
      ? this.startUnsaved !== null
        ? this.startUnsavedMerged
          ? 'the rules its start was writing to gate.json'
          : 'the rules it read from gate.json at start and the ones it was adding'
        : 'the rules of the last gate.json it used'
      : "the host's starting rules";
  }

  /**
   * What a policy change edits: gate.json's own fields and rule list as
   * written, each rule as written, so a write keeps every rule it doesn't
   * change, problems and unknown fields included, whether gate.json loads or
   * is JSON the gate doesn't use. Over one it doesn't use, writeConfig writes
   * only what loads, so a change is refused, naming what keeps the file out
   * and what would bring it into force (`remedy`), unless it mends that, and
   * the file stays as its operator wrote it. When
   * gate.json is absent, the same of the text whose rules are in force, so a
   * rule it leaves out keeps its name; or the rules in force, where no text
   * is, it has no rule list, or what's in force is what a start ran beside or
   * in place of it. A change is refused (`refused`) for a gate.json that can't
   * be read or isn't JSON (unusableRefusal), whose rules can't be edited
   * without writing over what it holds, and for one with no rule list a write
   * could edit without that (a list, a "policies" that isn't one and holds
   * something, or JSON that isn't an object): so a removal or an anchor is
   * refused too, rather than looked for in rules that may not be what the
   * file holds. It's refused as well for a gate.json that holds the text a
   * start didn't use (start-without), since what the change wrote would put
   * its rules in force in place of what the start runs.
   */
  private rulesForChange():
    | { top: Record<string, unknown>; rules: unknown[]; remedy?: string }
    | { refused: string } {
    const read = this.readConfigFile();
    if (read.state === 'unreadable') return { refused: unusableRefusal(read, this.rulesRun(), this.configPath) };
    if (read.state === 'loaded' || read.state === 'refused') {
      if ('noList' in read.listed) return { refused: noListRefusal(read.listed.noList, this.rulesRun(), this.configPath) };
      // Rules not gate.json's in force while it holds the text in force: what a
      // start ran in place of one with no rules of its own, until it changes.
      if (read.state === 'loaded' && read.text === this.configText && this.configSource !== 'file') {
        return { refused: notUsedRefusal(this.rulesRun(), this.configPath) };
      }
      const edit = { top: read.listed.top, rules: [...read.listed.rules] };
      if (read.state === 'loaded') return edit;
      // What would bring it into force, for a change that doesn't. A change
      // finds its rule by name: a replacement takes the first rule with it,
      // and a removal every one.
      const names = [...new Set(read.silenced ?? [])];
      const only = names.length === 1 ? names[0] : undefined;
      const sharing = only === undefined ? 0 : edit.rules.filter((rule) => nameOf(rule) === only).length;
      // A removal that would leave no rules in force is refused (writeConfig),
      // so it isn't offered.
      const rest = readConfig({ ...edit.top, policies: edit.rules.filter((rule) => nameOf(rule) !== only) }, 'gate.json');
      const removes = !('refused' in rest) && rest.config.policies.length > 0;
      return {
        ...edit,
        remedy: sharing === 1
          ? `${removes ? 'Replacing or removing' : 'Replacing'} ${quotedValue(only)} by name would bring gate.json into force.`
          : sharing > 1
            ? `gate.json has ${sharing} rules named ${quotedValue(only)}, and a change by that name replaces the first of them`
              + `${removes ? ' or removes them all' : ''}.`
            : 'No change through the gate can bring it into force, so gate.json has to be fixed by an edit of its own; '
              + 'until then, a change is refused the same way.',
      };
    }
    // While the rules in force aren't gate.json's, configText is the text a
    // start ran them beside or in place of, so its rules aren't the ones in force.
    const text = this.configText !== undefined && this.configSource === 'file'
      ? readConfig(parseGateJson(this.configText), 'gate.json')
      : undefined;
    return text && !('refused' in text) && !('noList' in text.listed)
      ? { top: text.listed.top, rules: [...text.listed.rules] }
      : { top: { policies: [], default: this.config.default ?? 'always' }, rules: [...this.config.policies] as unknown[] };
  }

  private compilePolicies(config: GateConfig): CompiledPolicy[] {
    return config.policies.map(policy => {
      const compiled: CompiledPolicy = { policy };
      if (policy.match.filter?.type === 'regex') {
        try { compiled.filterRegex = new RegExp(policy.match.filter.pattern, 'i'); } catch { /* skip */ }
      }
      if (policy.match.source) {
        compiled.sourceRegex = compileGlob(policy.match.source);
      }
      if (policy.match.channel) {
        compiled.channelRegex = compileGlob(policy.match.channel);
      }
      if (policy.match.mount) {
        compiled.mountRegex = compileGlob(policy.match.mount);
      }
      if (policy.match.pathGlob) {
        compiled.pathRegex = compileGlob(policy.match.pathGlob);
      }
      if (policy.match.tagsAny) compiled.tagsAnyRe = policy.match.tagsAny.map(compileGlob);
      if (policy.match.tagsAll) compiled.tagsAllRe = policy.match.tagsAll.map(compileGlob);
      if (policy.match.tagsNone) compiled.tagsNoneRe = policy.match.tagsNone.map(compileGlob);
      return compiled;
    });
  }

  /**
   * Clear the state of each rule `was` held in force that `next` leaves out or
   * gives another behavior: a reload calls it before it puts `next` in force,
   * a write after. Without this, a rule that came back, or whose tokens 100
   * became 5 (or keyBy switched, or every 10 became 3), would run on the
   * buckets and counters of the rule it was. A rule left out loses its stats
   * (matchCount, lastMatchTimestamp) too; a rule kept keeps them, which are
   * history, not live state, and one kept with the same behavior keeps all its
   * state, its denial and fire counts included. Rules that share a name share
   * its state, so a name keeps it only where its rules, in order, keep their
   * behaviors. Each pending debounce batch is sent last, as its timer would
   * have sent it, once every rule's state is cleared; one whose delivery throws
   * is named in the log and dropped (fireDebounce), and the rest are still
   * sent, so the write or reload that cleared it has done what it was for, its
   * caller hears that it did, and no state is left behind.
   */
  private clearStateFor(was: GateConfig, next: GateConfig): { removed: string[]; cleared: string[] } {
    const behaviorsByName = (config: GateConfig): Map<string, string> => {
      const byName = new Map<string, string[]>();
      for (const p of config.policies) {
        // A suppress rule's script is part of what it is: a changed script starts from a fresh state.
        const fingerprint = behaviorFingerprint(p.behavior) + (p.suppress ? ` suppress:${p.suppress.script ?? ''}` : '');
        byName.set(p.name, [...(byName.get(p.name) ?? []), fingerprint]);
      }
      return new Map([...byName].map(([name, behaviors]) => [name, JSON.stringify(behaviors)]));
    };
    const before = behaviorsByName(was);
    const after = behaviorsByName(next);
    const removed = [...before.keys()].filter((name) => !after.has(name));
    for (const name of removed) {
      this.clearPolicyState(name);
      this.stats.delete(name);
      this.judgeRecords.delete(name);
    }
    const cleared = [...after.keys()].filter((name) => before.has(name) && before.get(name) !== after.get(name));
    for (const name of cleared) this.clearPolicyState(name);
    for (const name of [...removed, ...cleared]) this.fireDebounce(name);
    return { removed, cleared };
  }

  private reloadIfChanged(): void {
    const now = Date.now();
    if (checkedRecently(now, this.lastReloadCheck)) return;
    this.lastReloadCheck = now;

    try {
      // Missing, unchanged or unreadable: the rules in force stay.
      const read = this.readConfigFile({ unlessUnchanged: true });
      // gate.json holds the text in force, so none the start ran is unsaved,
      // unless what's in force is what the start ran beside it or in its place.
      if (read.state === 'unchanged' && this.configSource === 'file') this.startUnsaved = null;
      if (read.state !== 'loaded') return;
      const newConfig = read.config;

      const { removed: removedPolicies, cleared: stateClearedPolicies } = this.clearStateFor(this.config, newConfig);

      this.config = newConfig;
      this.compiledPolicies = this.compilePolicies(newConfig);
      // Recorded only now that its rules are in force, so a reload that
      // throws before here is tried again at the next check.
      this.configText = read.text;
      this.configNote = read.note;
      this.configSource = 'file';
      if (read.note) console.error(`[gate] ${read.note}`);
      // The rules in force are now gate.json's, so none the start ran is unsaved.
      this.startUnsaved = null;
      this.lastReloadTimestamp = now;
      this.refreshShadowWarnings('reload');

      this.emitTrace({
        type: 'gate:config-reloaded',
        configPath: this.configPath,
        policyCount: newConfig.policies.length,
        removedPolicies: removedPolicies.length > 0 ? removedPolicies : undefined,
        stateClearedPolicies:
          stateClearedPolicies.length > 0 ? stateClearedPolicies : undefined,
      });
    } catch {
      // The rules in force stay, and the next check tries again.
    }
  }

  // =========================================================================
  // Runtime policy mutation (backs wake_add_rule / wake_remove_rule)
  // =========================================================================

  /**
   * Add or replace (upsert) a single policy in gate.json and apply it live.
   *
   * The raw policy is read with the SAME `readRule` used when loading gate.json,
   * and since its caller is there to fix it, any problem it has throws, naming
   * every one (nothing is written), and the caller surfaces it as a tool error,
   * where a load reads past it (readConfig). On success the policy is persisted
   * to gate.json (so it survives restart and is visible to `workspace--edit _config/gate.json`)
   * and the in-memory config is swapped in immediately, so the rule takes effect
   * without waiting for the throttled reload.
   *
   * The freshest on-disk config is re-read first, so a concurrent operator edit
   * isn't clobbered, and the change edits gate.json's own rule list by name:
   * every rule it doesn't change is written back as it was written, problems and
   * fields the gate doesn't read included, and so is everything else gate.json
   * holds, such as a list of rules parked under another name, beside which a
   * change adds a "policies" list where there's none (rulesForChange). Over a
   * gate.json the gate doesn't use, only a change after which it loads is
   * written, such as one replacing or removing the rule that keeps it out, and
   * that leaves it rules in force, since it holds events back by default; any
   * other is refused, naming what does, and the file stays as written. When
   * gate.json is absent, the change edits the text whose rules are in force the
   * same way, or the rules in force where there's none. A gate.json that can't
   * be read or isn't JSON is refused (unusableRefusal), and stays as it is. A policy with the
   * same `name` is replaced IN PLACE when no `position` is given (order
   * preserved); WITH a `position` it is moved there — so re-issuing a rule is
   * also how you reposition it. New policies append by default; `'prepend'` puts
   * one at the very front (ahead of EVERYTHING, including addressed-message wake
   * rules — see the shadow lint), and the anchored forms `{before: name}` /
   * `{after: name}` insert relative to an existing rule, which is almost always
   * the safer way to order a sampler or debounce against a specific catch-all.
   * Fields of the policy the gate reads nowhere, and that aren't a slip of one
   * it does, are left out of what's written, and named to `onIgnoredFields` once
   * the change is written and traced. A throw from the callback is logged,
   * and the change stands (afterChange). A field it reads at another level is a
   * problem, like a slip.
   *
   * Throws, writing nothing, for an invalid policy, a placement it can't make,
   * a gate.json that can't be read or isn't JSON, one with no rule list it
   * could edit without writing over what it holds, one a start didn't use,
   * which runs as one without it does, while it's unchanged, or one the gate
   * doesn't use that the change doesn't mend or would leave with no rules in
   * force; and throws when the write fails, which may leave gate.json
   * part-written.
   */
  addPolicy(
    rawPolicy: unknown,
    options?: {
      position?: 'append' | 'prepend' | { before: string } | { after: string };
      onIgnoredFields?: (notes: string[]) => void;
      /** The caller's own name for a field a refusal names, keyed by gate.json's name for it: one of
       *  `behavior.debounce`, `behavior.rate_limit`, `behavior.passive_sample` and `behavior.judge`, or
       *  `position.before` and `position.after` for a placement. A key names the fields under it too:
       *  `behavior.rate_limit` gives `behavior.rate_limit.tokens` its name, and a longer key wins.
       *  Other fields keep gate.json's names.
       *
       *  @internal For `wake_add_rule`'s refusals; not a host API. */
      fieldNames?: Readonly<Record<string, string>>;
    },
  ): GatePolicy {
    const named = namedBy(options?.fieldNames);
    const reading = readRule(rawPolicy, 'A rule', 'gate.json', named);
    if (reading.problems.length > 0 || !reading.policy) throw new Error(refusalOf(reading));
    const policy = reading.policy;
    const ignored = notesOf(reading);
    const edit = this.rulesForChange();
    if ('refused' in edit) throw new Error(edit.refused);
    const { top, rules, remedy } = edit;
    const idx = rules.findIndex((rule) => nameOf(rule) === policy.name);
    const position = options?.position;

    if (idx >= 0 && position === undefined) {
      rules[idx] = policy; // replace in place, order preserved
    } else {
      if (idx >= 0) rules.splice(idx, 1); // repositioning a known rule
      if (position === 'prepend') {
        rules.unshift(policy);
      } else if (position !== undefined && typeof position === 'object') {
        const anchorName = 'before' in position ? position.before : position.after;
        const anchorIdx = rules.findIndex((rule) => nameOf(rule) === anchorName);
        if (anchorIdx < 0) {
          const field = named('before' in position ? 'position.before' : 'position.after');
          const others = [...new Set(rules.map(nameOf).filter((name): name is string => name !== undefined))];
          if (idx >= 0 && anchorName === policy.name) {
            throw new Error(
              `${reading.where} wasn't saved: ${field} is ${quotedValue(anchorName)}, the rule being saved, and a rule can't be `
              + 'placed beside itself. '
              + (others.length > 0
                ? `The other rules are ${quotedList(others)}. Give ${field} one of those to place the rule beside it, or leave it out`
                : `There are no other rules, so leave ${field} out`)
              + ' to replace the rule where it is.'
              + savedOnlyInForce(this.configPath, remedy),
            );
          }
          throw new Error(
            `${reading.where} wasn't saved: ${field} is ${quotedValue(anchorName)}, and no rule has that name. `
            + (others.length > 0
              ? `The other rules are ${quotedList(others)}. Give ${field} one of those to place the rule beside it, or leave it out`
              : `There are no other rules, so leave ${field} out`)
            + ' to add the rule at the end, or, where a rule already has its name, to replace that rule where it is.'
            + savedOnlyInForce(this.configPath, remedy),
          );
        }
        rules.splice('before' in position ? anchorIdx : anchorIdx + 1, 0, policy);
      } else {
        rules.push(policy);
      }
    }

    this.writeConfig(top, rules, remedy);
    this.emitTrace({
      type: 'gate:policy-added',
      configPath: this.configPath,
      policyName: policy.name,
      replaced: idx >= 0,
    });
    if (ignored.length > 0) {
      // A caller that doesn't take the notes still gets them said, in the log.
      const onIgnoredFields = options?.onIgnoredFields;
      if (onIgnoredFields) afterChange('onIgnoredFields', () => onIgnoredFields(ignored));
      else console.error(`[gate] ${ignored.join(' ')}`);
    }
    return policy;
  }

  /**
   * Remove a policy by name from gate.json and clear its live state. Any pending
   * debounce batch is sent once the removal is written and in force, as its
   * timer would have sent it, so buffered events aren't silently dropped
   * (clearStateFor). Freshest on-disk config is re-read first, and every other
   * rule is written back as it was written (see addPolicy). A name that isn't
   * a non-empty string names no rule, so it returns false, writing nothing,
   * whatever gate.json holds. Otherwise it throws, writing nothing, for a
   * gate.json that can't be read or isn't JSON, one with no rule list it could
   * edit, or one a start didn't use, as addPolicy does, and returns false,
   * writing nothing, if no policy of that name exists, gate.json's own rules
   * included, so one the gate leaves out can be removed by name too. For a name
   * it holds, it throws, writing nothing, for a gate.json the gate doesn't use
   * that the removal doesn't mend or would leave with no rules in force, and
   * throws when the write fails, which may
   * leave gate.json part-written; the rules in force then stay as they were,
   * with their state.
   */
  removePolicy(name: string): boolean {
    // nameOf gives undefined for a rule with no name, so a call from JavaScript
    // with no name would otherwise remove every such rule.
    if (typeof name !== 'string' || name === '') return false;
    const edit = this.rulesForChange();
    if ('refused' in edit) throw new Error(edit.refused);
    if (!edit.rules.some((rule) => nameOf(rule) === name)) return false;
    // The write clears the rule's state once it has succeeded (writeConfig),
    // so a refusal or a failed write leaves the rule in force with its state.
    this.writeConfig(edit.top, edit.rules.filter((rule) => nameOf(rule) !== name), edit.remedy);
    this.emitTrace({
      type: 'gate:policy-removed',
      configPath: this.configPath,
      policyName: name,
    });
    return true;
  }

  /**
   * List the current policy names: those of a newer gate.json that loads (the
   * freshest on-disk view), and otherwise the rules in force, which beside a
   * gate.json with no rule list are the host's starting rules. Cheap helper for
   * tools/UX that want to show what's active without the full status payload.
   */
  listPolicyNames(): string[] {
    const read = this.readConfigFile({ unlessUnchanged: true });
    const current = read.state === 'loaded' ? read.config : this.config;
    return current.policies.map((p) => p.name);
  }

  /** The rules in force, in order (copies): what the last decision was made by. */
  policiesInForce(): GatePolicy[] {
    return this.config.policies.map((p) => structuredClone(p));
  }

  /** The rule in force by this name (a copy), or undefined. */
  policyInForce(name: string): GatePolicy | undefined {
    const p = this.config.policies.find((x) => x.name === name);
    return p ? structuredClone(p) : undefined;
  }

  /** @internal For `wake_add_rule`'s and `wake_remove_rule`'s refusals; not a host API. */
  ruleNamesForChange(): { names: string[]; note: string } | { refused: string } {
    const edit = this.rulesForChange();
    if ('refused' in edit) return { refused: edit.refused };
    return {
      names: [...new Set(edit.rules.map(nameOf).filter((name): name is string => name !== undefined))],
      note: savedOnlyInForce(this.configPath, edit.remedy),
    };
  }

  /**
   * Persist gate.json and apply it in memory together: `top`, its own fields,
   * with `rules` as its rule list. Only what loads is written: a change to a
   * gate.json the gate doesn't use, for which `remedy` is given, what would
   * bring it into force, throws, naming that and `remedy`, and writes nothing,
   * where the change doesn't mend what keeps it out, or where it would leave
   * gate.json with no rules in force: such a gate.json holds events back by
   * default, so putting it in force would hold back every event, those the
   * rules in force wake on included. The rules in force are then what the text
   * written reads as, as at a load, so what it still holds that the gate reads
   * past or leaves out stays named; the text is kept as `configText`, so
   * `reloadIfChanged` doesn't parse it again. Once the text is written and its
   * rules are in force, a rule that was in force that it leaves out or gives
   * another behavior loses its state (clearStateFor), last, since a pending
   * batch it sends can't be taken back, and a write that fails leaves the
   * rules in force with their state; a batch that can't be delivered is
   * logged, not thrown. A write that fails throws, saying whether gate.json was
   * changed: one that fails before writing leaves it as it was, and one that
   * fails after its open may leave it part-written (beforeWriting). Callers
   * surface it as a tool error.
   */
  private writeConfig(top: Record<string, unknown>, rules: unknown[], remedy?: string): void {
    const text = JSON.stringify({ ...top, policies: rules }, null, 2) + '\n';
    const read = readConfig(JSON.parse(text), 'gate.json');
    if ('refused' in read) {
      throw new Error(
        `Nothing was saved: with this change, gate.json, at ${this.configPath}, wouldn't be used. ${sentence(read.refused)}`
          + (remedy ? ` ${remedy}` : ''),
      );
    }
    // One the gate doesn't use, and that a change can mend, holds back what a
    // rule it leaves out would wake on, so its default holds events back.
    if (remedy !== undefined && read.config.policies.length === 0) {
      throw new Error(
        `Nothing was saved: with this change, gate.json, at ${this.configPath}, would have no rules the gate reads, and its default `
        + `would hold back every event. Meanwhile the gate runs ${this.rulesRun()}. ${remedy}`,
      );
    }
    try {
      mkdirSync(dirname(this.configPath), { recursive: true });
      writeFileSync(this.configPath, text);
    } catch (err) {
      throw new Error(beforeWriting(err)
        ? `gate.json couldn't be written (${errorText(err)}), so nothing was saved: the rules in force and gate.json stay `
          + 'as they were. Whoever runs this host can fix what keeps it from being written.'
        : `Writing gate.json failed partway (${errorText(err)}), so the change isn't in force: the rules in force stay as `
          + 'they were. gate.json may hold the whole change, which the gate reads at its next reload; or it may hold part of it '
          + 'or nothing, which the gate can\'t read, and then they stay until gate.json is fixed. '
          + 'Whoever runs this host can fix what kept it from being written, and check what gate.json holds.', { cause: err });
    }
    const was = this.config;
    this.configText = text;
    this.configNote = loadNote(read.sentences);
    this.config = read.config;
    this.compiledPolicies = this.compilePolicies(read.config);
    this.refreshShadowWarnings('policy-mutation');
    this.configSource = 'file';
    this.configError = this.configNote;
    this.configUnused = false;
    this.startUnsaved = null;
    this.lastReloadTimestamp = Date.now();
    this.clearStateFor(was, read.config);
  }

  // =========================================================================
  // Policy matching — first match wins (passthrough observers excepted; the
  // match/decide loop lives inline in evaluate() and probe())
  // =========================================================================

  private compiledMatches(compiled: CompiledPolicy, info: GateEventInfo): boolean {
    const match = compiled.policy.match;

    // Scope check
    if (match.scope && match.scope.length > 0 && !match.scope.includes(info.eventType)) {
      return false;
    }

    // Source check (serverId)
    if (compiled.sourceRegex && !compiled.sourceRegex.test(info.serverId)) {
      return false;
    }

    // Channel check: the event's own channel id, or the registered id the
    // gate resolves for its route. A push event carries the adapter's raw id
    // (`origin.channelId`, or none), and a channels/incoming message the
    // registered one, so a pattern in the registered form matches every
    // event in its channel whose push names the channel (by `mcplChannelId`,
    // or a Discord origin's guild and channel): its messages on both paths,
    // and its reactions, edits, voice reports and other pushes.
    if (compiled.channelRegex && !compiled.channelRegex.test(info.channelId)) {
      const registered = this.routeChannelFor(info);
      if (registered === undefined || !compiled.channelRegex.test(registered)) return false;
    }

    // Mount check (workspace fs events)
    if (compiled.mountRegex) {
      if (!info.mount || !compiled.mountRegex.test(info.mount)) {
        return false;
      }
    }

    // Path glob check — matches if ANY path matches
    if (compiled.pathRegex) {
      const paths = info.paths;
      if (!paths || paths.length === 0) return false;
      const anyMatch = paths.some(p => compiled.pathRegex!.test(p));
      if (!anyMatch) return false;
    }

    // Content filter check
    if (match.filter) {
      if (match.filter.type === 'text') {
        if (!info.content.toLowerCase().includes(match.filter.pattern.toLowerCase())) {
          return false;
        }
      } else if (compiled.filterRegex) {
        if (!compiled.filterRegex.test(info.content)) {
          return false;
        }
      } else {
        return false; // Regex failed to compile
      }
    }

    // Metadata-truthy check — match if ANY listed field is truthy.
    // Uses isMetadataTruthy so empty arrays / strings / objects are treated
    // as falsy (matches user expectation, not raw JS Boolean coercion).
    if (match.metadataTrue && match.metadataTrue.length > 0) {
      const md = info.metadata ?? {};
      const anyTrue = match.metadataTrue.some(field => isMetadataTruthy(md[field]));
      if (!anyTrue) return false;
    }

    // Tag matching (MCPL RFC-001). Patterns are globs; `tags` is the event's
    // (implication-expanded) tag set. A pattern "matches" if it matches ANY tag.
    if (compiled.tagsAnyRe || compiled.tagsAllRe || compiled.tagsNoneRe) {
      const tags = info.tags ?? [];
      const patternHits = (re: RegExp): boolean => tags.some(t => re.test(t));
      if (compiled.tagsAnyRe && !compiled.tagsAnyRe.some(patternHits)) return false;
      if (compiled.tagsAllRe && !compiled.tagsAllRe.every(patternHits)) return false;
      if (compiled.tagsNoneRe && compiled.tagsNoneRe.some(patternHits)) return false;
    }

    return true;
  }

  // =========================================================================
  // Evaluate — main entry point
  // =========================================================================

  evaluate(info: GateEventInfo): GateDecision {
    this.reloadIfChanged();

    // Sleep suppression: while asleep, drop EXTERNAL wakes. Two things still
    // rouse the agent — its own heartbeat (an internal clock, not an outside
    // interruption: each tick lets the agent reconsider and optionally `wake`)
    // and a privileged user's ping. The event always enters context regardless
    // (the gate only governs inference triggering). The heartbeat is the
    // server the host knows as `heartbeat`, the server id the silent-heartbeat
    // marker requires too: a `source` in an event's metadata is the server's
    // own word, which any server can give.
    if (this.sleepUntil > this.now()) {
      const isHeartbeat = info.serverId === 'heartbeat';
      const authorId = this.extractAuthorId(info.metadata);
      const privileged = this.isPrivilegedUser(authorId);
      if (!isHeartbeat && !privileged) {
        this.sleepSuppressed++;
        this.totalEvaluations++;
        this.emitTrace({
          type: 'gate:decision',
          eventType: info.eventType,
          serverId: info.serverId || undefined,
          channelId: info.channelId || undefined,
          matchedPolicy: 'asleep',
          trigger: false,
          behavior: 'skip',
        });
        return { trigger: false, policyName: 'asleep', behavior: 'skip' };
      }
      // Privileged author — fall through to normal policy evaluation.
    }

    // Programmable gate (gate.js) takes precedence when present and returns a
    // behavior; null/undefined (inactive, error, or a deliberate pass) falls
    // through to the declarative gate.json policies below.
    //
    // Declarative policies: first match wins — EXCEPT `passthrough` observers,
    // which consume the event only when their counting behavior actually
    // fires. A passthrough policy that matched-but-didn't-fire records its
    // count and evaluation continues, so a density sampler placed early can
    // no longer swallow the addressed-message rules behind it.
    const scripted = this.gateScript.evaluate(info);
    let decision: GateDecision | null = null;
    const observed: string[] = [];
    if (scripted != null) {
      decision = this.computeDecision({ name: 'gate.js', match: {}, behavior: scripted }, info);
    } else {
      for (const compiled of this.compiledPolicies) {
        // A suppress rule doesn't decide a wake for an event suppression was
        // asked about: one it takes was suppressed before the gate was asked,
        // and one that reaches here is one it let by. Where suppression wasn't
        // asked (no view to hide it from), it defers, as its behavior says.
        if (compiled.policy.suppress && this.passesOverSuppress(info)) continue;
        if (!this.compiledMatches(compiled, info)) continue;
        const candidate = this.computeDecision(compiled.policy, info);
        if (candidate.trigger || !compiled.policy.passthrough) {
          decision = candidate;
          break;
        }
        observed.push(compiled.policy.name); // counted, didn't fire, fell through
      }
    }

    this.totalEvaluations++;
    if (!decision) {
      decision = this.computeDecision(null, info);
      const bucket = this.defaultByEventType.get(info.eventType)
        ?? { triggered: 0, skipped: 0 };
      if (decision.trigger) {
        this.defaultTriggered++;
        bucket.triggered++;
      } else {
        this.defaultSkipped++;
        bucket.skipped++;
      }
      this.defaultByEventType.set(info.eventType, bucket);
    }
    if (observed.length > 0) decision.observed = observed;

    this.emitTrace({
      type: 'gate:decision',
      eventType: info.eventType,
      serverId: info.serverId || undefined,
      channelId: info.channelId || undefined,
      matchedPolicy: decision.policyName,
      trigger: decision.trigger,
      behavior: formatBehavior(decision.behavior),
      ...(observed.length > 0 ? { observed } : {}),
    });

    return decision;
  }

  private computeDecision(policy: GatePolicy | null, info: GateEventInfo): GateDecision {
    if (!policy) {
      const trigger = (this.config.default ?? 'always') === 'always';
      return { trigger, policyName: null, behavior: this.config.default ?? 'always' };
    }

    // Record stats
    const policyStats = this.stats.get(policy.name) ?? { matchCount: 0, lastMatchTimestamp: null };
    policyStats.matchCount++;
    policyStats.lastMatchTimestamp = this.now();
    this.stats.set(policy.name, policyStats);

    // Legacy trace kept for backward compatibility with existing consumers.
    this.emitTrace({
      type: 'gate:policy-matched',
      policyName: policy.name,
      behavior: formatBehavior(policy.behavior),
      eventType: info.eventType,
      source: info.serverId || undefined,
    });

    if (policy.behavior === 'defer' || policy.behavior === 'skip') {
      // Report the configured name faithfully ('defer' or legacy 'skip').
      return { trigger: false, policyName: policy.name, behavior: policy.behavior };
    }

    if (policy.behavior === 'always') {
      this.applyResets(policy);
      return { trigger: true, policyName: policy.name, behavior: 'always' };
    }

    if (typeof policy.behavior === 'object') {
      if ('debounce' in policy.behavior || 'judge' in policy.behavior) {
        this.handleDebounce(policy, info);
        return { trigger: false, policyName: policy.name, behavior: policy.behavior };
      }
      if ('rate_limit' in policy.behavior) {
        return this.applyRateLimit(policy, info, policy.behavior.rate_limit);
      }
      if ('passive_sample' in policy.behavior) {
        return this.applyPassiveSample(policy, info, policy.behavior.passive_sample);
      }
    }

    // Unknown behavior shape — should be unreachable thanks to validation,
    // but be defensive: treat as skip rather than crash on a bad config.
    return { trigger: false, policyName: policy.name, behavior: 'skip' };
  }

  // =========================================================================
  // rate_limit + passive_sample + resets
  // =========================================================================

  /** Resolve the partition key for keyBy-style behaviors. `keyBy:
   *  "channelId"` takes the registered id the gate resolves for the event when
   *  it has one, as channel matching does, so a channel's push events count
   *  with its channels/incoming messages rather than under their raw id. */
  private resolveKey(info: GateEventInfo, keyBy: string | undefined): string {
    if (!keyBy) return SHARED_BUCKET_KEY;
    if (keyBy === 'channelId') {
      const registered = this.routeChannelFor(info);
      if (registered !== undefined) return registered;
    }
    const value = info.metadata?.[keyBy];
    if (value === undefined || value === null || value === '') return SHARED_BUCKET_KEY;
    return String(value);
  }

  private applyRateLimit(
    policy: GatePolicy,
    info: GateEventInfo,
    config: { tokens: number; refillIntervalMs: number; keyBy?: string },
  ): GateDecision {
    const key = this.resolveKey(info, config.keyBy);
    let buckets = this.rateLimitBuckets.get(policy.name);
    if (!buckets) {
      buckets = new Map();
      this.rateLimitBuckets.set(policy.name, buckets);
    }

    const now = this.now();
    let bucket = buckets.get(key);
    if (!bucket) {
      bucket = { tokens: config.tokens, lastRefill: now };
      buckets.set(key, bucket);
    } else if (bucket.tokens < config.tokens) {
      const elapsed = now - bucket.lastRefill;
      // A refill interval of 0, read from gate.json or the starting rules
      // (readRateLimit), refills at once; divided by, it refilled the bucket
      // once and left its clock at NaN. Under 0, no number of whole intervals
      // has passed, so it never refills.
      if (config.refillIntervalMs === 0) {
        bucket.tokens = config.tokens;
        bucket.lastRefill = now;
      } else if (elapsed > 0) {
        const tokensToAdd = Math.floor(elapsed / config.refillIntervalMs);
        if (tokensToAdd > 0) {
          bucket.tokens = Math.min(config.tokens, bucket.tokens + tokensToAdd);
          bucket.lastRefill += tokensToAdd * config.refillIntervalMs;
        }
      }
    } else {
      // Bucket already full — keep the refill clock fresh so the next
      // drain starts from "now" rather than ancient history.
      bucket.lastRefill = now;
    }

    if (bucket.tokens > 0) {
      bucket.tokens -= 1;
      this.applyResets(policy);
      return { trigger: true, policyName: policy.name, behavior: policy.behavior };
    }

    this.rateLimitDenied.set(policy.name, (this.rateLimitDenied.get(policy.name) ?? 0) + 1);
    return { trigger: false, policyName: policy.name, behavior: policy.behavior };
  }

  private applyPassiveSample(
    policy: GatePolicy,
    info: GateEventInfo,
    config: { every: number; keyBy?: string },
  ): GateDecision {
    const key = this.resolveKey(info, config.keyBy);
    let counters = this.passiveSampleCounters.get(policy.name);
    if (!counters) {
      counters = new Map();
      this.passiveSampleCounters.set(policy.name, counters);
    }

    const next = (counters.get(key) ?? 0) + 1;
    if (next >= config.every) {
      counters.set(key, 0);
      this.passiveSampleFires.set(policy.name, (this.passiveSampleFires.get(policy.name) ?? 0) + 1);
      this.applyResets(policy);
      return { trigger: true, policyName: policy.name, behavior: policy.behavior };
    }
    counters.set(key, next);
    return { trigger: false, policyName: policy.name, behavior: policy.behavior };
  }

  /**
   * Clear bucket / counter state for the policies named in `policy.resets`.
   * Called when a policy fires (decision.trigger === true). Unknown names
   * are silently ignored — gate.json reload could remove them.
   */
  private applyResets(policy: GatePolicy): void {
    if (!policy.resets || policy.resets.length === 0) return;
    for (const target of policy.resets) {
      this.rateLimitBuckets.delete(target);
      this.passiveSampleCounters.delete(target);
    }
  }

  /**
   * Clear one policy's live state (rate-limit buckets, passive-sample
   * counters, denial / fire counters) and stop its debounce timer, leaving
   * its pending batch for fireDebounce to send, as clearStateFor does once
   * every policy's state is cleared. It leaves stats (matchCount,
   * lastMatchTimestamp), which are history; clearStateFor deletes a removed
   * policy's.
   */
  private clearPolicyState(name: string): void {
    const debounce = this.debounceTimers.get(name);
    if (debounce) clearTimeout(debounce.timer);
    this.suppressScripts.forget(name);
    this.rateLimitBuckets.delete(name);
    this.passiveSampleCounters.delete(name);
    this.rateLimitDenied.delete(name);
    this.passiveSampleFires.delete(name);
  }

  // =========================================================================
  // Dry-run probes — side-effect-free "what would this event do right now"
  // =========================================================================

  /**
   * Non-mutating twin of the behavior decision: would this policy trigger for
   * this event, given CURRENT counter/bucket state? Reads state, never writes
   * it — no stats, no traces, no counter increments, no debounce batching.
   */
  private wouldTrigger(policy: GatePolicy, info: GateEventInfo): boolean {
    const b = policy.behavior;
    if (b === 'always') return true;
    if (b === 'defer' || b === 'skip') return false;
    if (typeof b === 'object') {
      if ('debounce' in b || 'judge' in b) return false; // batches; never triggers inline
      if ('rate_limit' in b) {
        const cfg = b.rate_limit;
        const key = this.resolveKey(info, cfg.keyBy);
        const bucket = this.rateLimitBuckets.get(policy.name)?.get(key);
        if (!bucket) return true; // fresh bucket starts full
        // As applyRateLimit refills: at once, for an interval of 0, and never
        // for one under 0.
        if (cfg.refillIntervalMs === 0) return true;
        let tokens = bucket.tokens;
        if (tokens < cfg.tokens && cfg.refillIntervalMs > 0) {
          const elapsed = Math.max(0, this.now() - bucket.lastRefill);
          tokens = Math.min(cfg.tokens, tokens + Math.floor(elapsed / cfg.refillIntervalMs));
        }
        return tokens > 0;
      }
      if ('passive_sample' in b) {
        const cfg = b.passive_sample;
        const key = this.resolveKey(info, cfg.keyBy);
        const count = this.passiveSampleCounters.get(policy.name)?.get(key) ?? 0;
        return count + 1 >= cfg.every;
      }
    }
    return false;
  }

  /**
   * Evaluate an event against the declarative policy table WITHOUT side
   * effects: no counters advance, no debounce batches form, no stats or
   * traces are recorded, and sleep suppression is ignored (a probe asks
   * about the table, not the moment). gate.js is not consulted — a script
   * may be stateful, and a probe must never perturb state.
   */
  probe(info: GateEventInfo): GateDecision {
    for (const compiled of this.compiledPolicies) {
      if (compiled.policy.suppress && this.passesOverSuppress(info)) continue; // as evaluate does
      if (!this.compiledMatches(compiled, info)) continue;
      const trigger = this.wouldTrigger(compiled.policy, info);
      if (trigger || !compiled.policy.passthrough) {
        return { trigger, policyName: compiled.policy.name, behavior: compiled.policy.behavior };
      }
    }
    const trigger = (this.config.default ?? 'always') === 'always';
    return { trigger, policyName: null, behavior: this.config.default ?? 'always' };
  }

  /**
   * The suppress rule that takes this event, or null when none does.
   * Side-effect-free, like probe: no counter moves, no batch forms, nothing
   * is traced, and a rule's script runs on a copy of its state, which is
   * then dropped. (A closure a script builds for itself is its own, and a
   * dry run's timeout counts toward setting a script aside, as it costs the same.) The probe table and other dry runs ask this; the
   * framework asks decideSuppression instead, once per event.
   *
   * It reads the rules as evaluate does, first match deciding: a rule ahead
   * of the suppress rule that matches the event decides it instead (it isn't
   * suppressed), unless it's a passthrough rule that wouldn't fire. A rule
   * with a script (`suppress.script`) takes an event its match takes only
   * when the script says to hide it; otherwise the event goes on to the rules
   * after it, as one the rule doesn't match does. Sleep and gate.js aren't
   * consulted: they decide wakes, and suppression decides what's rendered.
   *
   * Never suppressed, whatever the rules say: an event addressed to the
   * agent (tagged `chat:addressed`: a mention, a reply, a DM) and the
   * heartbeat's (the agent's own clock). A suppress rule lets them by to the
   * rules after it, and its script isn't asked. The framework itself never
   * asks about console or API input.
   */
  suppressionFor(info: GateEventInfo): string | null {
    return this.walkSuppression(info, false);
  }

  /**
   * suppressionFor, for an event that is arriving now: each script asked
   * keeps the state it leaves, whatever later rules do with the event, and a
   * suppressed event counts in the passthrough rules ahead of its rule. Ask
   * once per event.
   */
  decideSuppression(info: GateEventInfo): string | null {
    return this.walkSuppression(info, true);
  }

  private walkSuppression(info: GateEventInfo, commit: boolean): string | null {
    this.reloadIfChanged();
    this.syncSuppressScripts();
    if (info.serverId === 'heartbeat') return null;
    const addressed = Array.isArray(info.tags) && info.tags.includes('chat:addressed');
    let event: SuppressScriptEvent | undefined;
    const observers: GatePolicy[] = [];
    for (const compiled of this.compiledPolicies) {
      if (!this.compiledMatches(compiled, info)) continue;
      const suppress = compiled.policy.suppress;
      if (suppress) {
        if (addressed) continue;
        if (suppress.script !== undefined) {
          event ??= this.suppressScriptEvent(info);
          const ran = this.suppressScripts.run(compiled.policy.name, event, commit);
          // A script that failed shows the event: it goes on to the rules after.
          if (!ran || !('hide' in ran) || !ran.hide) continue;
        }
        // A suppressed event never reaches evaluate, so the passthrough rules
        // ahead of this one count it here, as evaluate would have: none of
        // them fires for it, and each fires on its schedule. A dry run counts
        // nothing.
        if (commit) for (const observer of observers) this.computeDecision(observer, info);
        return compiled.policy.name;
      }
      if (compiled.policy.passthrough && !this.wouldTrigger(compiled.policy, info)) { observers.push(compiled.policy); continue; }
      return null;
    }
    return null;
  }

  /** Whether evaluate and probe pass over a suppress rule for this event: suppression was asked about it, or it's one suppression always lets by. */
  private passesOverSuppress(info: GateEventInfo): boolean {
    return info.suppressionAsked === true || info.serverId === 'heartbeat'
      || (Array.isArray(info.tags) && info.tags.includes('chat:addressed'));
  }

  /** The scripts in step with the rules in force (SuppressScripts.sync: only changed ones are compiled). */
  private syncSuppressScripts(): void {
    this.suppressScripts.sync(this.config.policies.map((p) => ({ name: p.name, ...(p.suppress?.script !== undefined ? { script: p.suppress.script } : {}) })));
  }

  /** What a suppress script is given for an event: plain JSON, its metadata included where it can be. */
  private suppressScriptEvent(info: GateEventInfo): SuppressScriptEvent {
    let metadata: Record<string, unknown> = {};
    try { metadata = JSON.parse(JSON.stringify(info.metadata ?? {})) as Record<string, unknown>; } catch { metadata = {}; }
    const channel = this.routeChannelFor(info) ?? (info.channelId || undefined);
    const author = this.extractAuthorId(info.metadata);
    return {
      eventType: info.eventType,
      source: info.serverId,
      ...(channel ? { channel } : {}),
      ...(author ? { author } : {}),
      tags: [...(info.tags ?? [])],
      text: info.content,
      at: this.now(),
      metadata,
    };
  }

  /**
   * Whether a suppress script compiles to a function, on the scripts' worker:
   * an error's text, or null. wake_add_rule asks before it saves a rule.
   */
  checkSuppressScript(script: string): string | null {
    return this.suppressScripts.check(script);
  }

  /** A suppress rule's script state as it stands (a copy), for a host or a test. */
  suppressScriptState(name: string): Record<string, unknown> | undefined {
    this.syncSuppressScripts();
    return this.suppressScripts.stateOf(name);
  }

  /**
   * Count a row the framework suppressed by `name` (suppressionFor's
   * answer) once it's written. The rule's stats count it as a match, so
   * gate_status shows how many events each suppress rule took since start.
   */
  noteSuppressed(name: string, info: Pick<GateEventInfo, 'eventType' | 'serverId' | 'channelId'>): void {
    const policyStats = this.stats.get(name) ?? { matchCount: 0, lastMatchTimestamp: null };
    policyStats.matchCount++;
    policyStats.lastMatchTimestamp = this.now();
    this.stats.set(name, policyStats);
    this.emitTrace({
      type: 'gate:suppressed',
      policyName: name,
      eventType: info.eventType,
      ...(info.serverId ? { serverId: info.serverId } : {}),
      ...(info.channelId ? { channelId: info.channelId } : {}),
    });
  }

  /** The canonical synthetic events the probe table runs: chat shapes as MCPL delivers them, and a heartbeat. */
  private probeEvents(): Array<{ label: string; info: GateEventInfo }> {
    const chat = (
      label: string,
      eventType: string,
      metadata: Record<string, unknown>,
      tags: string[],
    ): { label: string; info: GateEventInfo } => ({
      label,
      info: {
        content: `[probe] ${label}`,
        eventType,
        serverId: 'discord',
        channelId: '',
        metadata: { ...metadata, eventType },
        tags,
      },
    });

    const probes = [
      chat('dm (open channel)', 'mcpl:channel-incoming', { isDM: true, isMention: true },
        ['chat:dm', 'chat:private', 'chat:addressed', 'chat:from-human']),
      chat('dm (closed channel)', 'mcpl:push-event', { isDM: true, isMention: true },
        ['chat:dm', 'chat:private', 'chat:addressed', 'chat:from-human']),
      chat('explicit mention (open channel)', 'mcpl:channel-incoming',
        { isMention: true, isExplicitMention: true },
        ['chat:mention', 'chat:addressed', 'chat:from-human']),
      chat('explicit mention (closed channel)', 'mcpl:push-event',
        { isMention: true, isExplicitMention: true },
        ['chat:mention', 'chat:addressed', 'chat:from-human']),
      chat('reply to you', 'mcpl:channel-incoming', { isMention: true, isReplyToBot: true },
        ['chat:reply', 'chat:addressed', 'chat:from-human']),
      chat('ambient (human)', 'mcpl:channel-incoming', {},
        ['chat:ambient', 'chat:from-human']),
      chat('ambient (bot)', 'mcpl:channel-incoming', { isBot: true },
        ['chat:ambient', 'chat:from-bot']),
      {
        label: 'heartbeat',
        info: {
          content: '[probe] heartbeat',
          eventType: 'mcpl:push-event',
          serverId: 'heartbeat',
          channelId: '',
          metadata: { source: 'heartbeat', eventType: 'mcpl:push-event' },
        } as GateEventInfo,
      },
    ];
    return probes;
  }

  /**
   * The rules no probe event matches, such as one scoped to an event type
   * the probes don't model (`external-message`, how a module's messages are
   * gated): the probe table can't show what they do, so a result that shows
   * the table names them rather than let its rows read as their effect.
   */
  probeUnreached(): string[] {
    const events = this.probeEvents().map(({ info }) => info);
    return this.compiledPolicies
      .filter((compiled) => !events.some((info) => this.compiledMatches(compiled, info)))
      .map((compiled) => compiled.policy.name);
  }

  /**
   * Probe a canonical set of synthetic chat/heartbeat events and report which
   * rule wins each and whether it would wake. Backs the before/after table in
   * the wake_add_rule result — the point where a rule change's real semantics
   * must become legible (af#105; the Mythos stand-back-density incident would
   * have been visible as `dm: discord-direct-address → stand-back-density`).
   * Probes are representative shapes, not an exhaustive event space — rules
   * keyed on specific channels/mounts, or on other event types, may not match
   * any probe; `probeUnreached` names those.
   */
  probeTable(): GateProbeRow[] {
    return this.probeEvents().map(({ label, info }) => {
      const suppressedBy = this.suppressionFor(info);
      if (suppressedBy !== null) {
        return { probe: label, eventType: info.eventType, policy: suppressedBy, behavior: 'suppress', wouldWake: false };
      }
      // As admission asks: suppression first, so a script that says show lets the probe on.
      const d = this.probe({ ...info, suppressionAsked: true });
      return {
        probe: label,
        eventType: info.eventType,
        policy: d.policyName,
        behavior: d.policyName === null
          ? `default:${formatBehavior(d.behavior)}`
          : formatBehavior(d.behavior),
        wouldWake: d.trigger,
      };
    });
  }

  // =========================================================================
  // Shadow lint surface
  // =========================================================================

  /** Current shadow-lint findings for the live policy order. Fresh compute —
   *  cheap (policy lists are tens of entries at most). */
  lintShadows(): ShadowWarning[] {
    return findShadowedPolicies(this.config.policies, this.eventTypesFromFn);
  }

  /**
   * The sources the host knows changed (eventTypesFrom answers differently),
   * as when an MCPL server connects or is removed: the rule-order notes are
   * made again, and traced if they changed, as a change to the rules would.
   */
  sourcesChanged(): void {
    this.refreshShadowWarnings('sources-changed');
  }

  /**
   * Recompute shadow warnings and, when the set changed, emit a
   * `gate:shadow-warnings` trace so the hazard lands in ops observability at
   * the moment the order changed — not at the next missed DM — and, with an
   * empty list, the moment the last of them went. Called from writeConfig,
   * reloadIfChanged and sourcesChanged.
   */
  private refreshShadowWarnings(reason: string): void {
    const warnings = this.lintShadows();
    const fingerprint = JSON.stringify(warnings);
    if (fingerprint === this.shadowWarningsFingerprint) return;
    const hadSome = this.shadowWarningsFingerprint !== '[]';
    this.shadowWarningsFingerprint = fingerprint;
    if (warnings.length > 0 || hadSome) {
      this.emitTrace({
        type: 'gate:shadow-warnings',
        reason,
        warnings: warnings.map(formatShadowWarning),
      });
    }
  }

  // =========================================================================
  // shouldTriggerInference callback adapter
  // =========================================================================

  /**
   * Returns a callback compatible with McplServerConfig.shouldTriggerInference.
   * Used by the framework to wire the gate into PushHandler and ChannelRegistry.
   */
  asShouldTriggerCallback(): (content: string, metadata: Record<string, unknown>) => boolean {
    return (content: string, metadata: Record<string, unknown>): boolean => {
      const decision = this.evaluate({
        content,
        eventType: (metadata.eventType as string) ?? 'unknown',
        serverId: (metadata.serverId as string) ?? '',
        channelId: (metadata.channelId as string) ?? '',
        metadata,
        tags: Array.isArray(metadata.tags) ? (metadata.tags as string[]) : undefined,
      });
      return decision.trigger;
    };
  }

  // =========================================================================
  // Debounce
  // =========================================================================

  /** Registered channel for an event; a resolver fault never breaks gating. */
  private routeChannelFor(info: GateEventInfo): string | undefined {
    try {
      return this.resolveRouteChannelFn(info) || undefined;
    } catch {
      return undefined;
    }
  }

  private handleDebounce(policy: GatePolicy, info: GateEventInfo): void {
    const debounceMs = batchQuietMs(policy.behavior) ?? MIN_DEBOUNCE_MS;
    const judge = typeof policy.behavior === 'object' && 'judge' in policy.behavior ? policy.behavior.judge : undefined;

    const event: PendingEvent = {
      policyName: policy.name,
      content: info.content.length > MAX_CONTENT_SNIPPET
        ? safeSlice(info.content, 0, MAX_CONTENT_SNIPPET) + '...'
        : info.content,
      eventType: info.eventType,
      timestamp: Date.now(),
      inContext: info.eventType === 'mcpl:channel-incoming' || info.eventType === 'mcpl:push-event',
      channelId: info.channelId || undefined,
      channelLabel:
        typeof info.metadata?.channelName === 'string' && info.metadata.channelName
          ? (info.metadata.channelName as string)
          : undefined,
      authorId: this.extractAuthorId(info.metadata) ?? undefined,
      serverId: info.serverId || undefined,
      addressed: Array.isArray(info.tags) && info.tags.includes('chat:addressed'),
      routeChannelId: this.routeChannelFor(info),
      ...(typeof info.metadata?.messageId === 'string' ? { messageId: info.metadata.messageId } : {}),
      ...(typeof info.metadata?.eventId === 'string' ? { eventId: info.metadata.eventId } : {}),
      ...(info.recipients !== undefined ? { recipients: [...info.recipients] } : {}),
    };

    const existing = this.debounceTimers.get(policy.name);
    // A judge's maxWaitMs caps how far new events push the batch back: it's
    // judged by then, from its first event, quiet or not.
    const delay = (firstAt: number, batchJudge: JudgeConfig | undefined): number => {
      const cap = batchJudge?.maxWaitMs;
      return cap === undefined ? debounceMs : Math.max(0, Math.min(debounceMs, firstAt + cap - this.now()));
    };
    if (existing) {
      clearTimeout(existing.timer);
      existing.events.push(event);
      const ms = delay(existing.firstAt, existing.judge);
      existing.timer = setTimeout(() => this.fireDebounce(policy.name), ms);
      existing.dueAt = this.now() + ms;
    } else {
      const firstAt = this.now();
      const ms = delay(firstAt, judge);
      const timer = setTimeout(() => this.fireDebounce(policy.name), ms);
      this.debounceTimers.set(policy.name, { timer, events: [event], firstAt, dueAt: firstAt + ms, ...(judge ? { judge } : {}) });
    }
  }

  private fireDebounce(policyName: string): void {
    const state = this.debounceTimers.get(policyName);
    if (!state || state.events.length === 0) {
      this.debounceTimers.delete(policyName);
      return;
    }

    const events = state.events;
    this.debounceTimers.delete(policyName);

    // A judge rule's batch goes to the reply judge, which delivers it, or
    // doesn't, once it has decided (judgeBatch). Without a judge wired it's
    // delivered below, as a debounce's batch is.
    if (state.judge && this.judgeFn) {
      this.judgeBatch(policyName, events, state.judge);
      return;
    }

    // If any agent is currently inferring — or the host is quiesced — buffer
    // for later (with cap). While quiesced, delivering would write a
    // "[Gate: N events]" message into the very context being operated on
    // mid-surgery; buffering composes them and they land at resume.
    if (this.inferring.size > 0 || this.quiesced) {
      this.bufferForInference(events);
      return;
    }

    // A delivery that throws drops the batch, named in the log: thrown from
    // its timer, it would be uncaught, and stop the process, and thrown to a
    // write or reload that sends it (clearStateFor), it would report a change
    // that was made as failed.
    try {
      this.deliverEvents(events);
    } catch (err) {
      const one = events.length === 1;
      console.error(
        `[gate] Rule ${quotedValue(policyName)}: its pending batch of ${events.length} ${one ? 'event' : 'events'} `
        + (deliveredInPart(err) ?? `couldn't be delivered (${errorText(err)}), so the batch is dropped`),
      );
      return;
    }

    this.emitTrace({
      type: 'gate:debounce-delivered',
      policyName,
      eventCount: events.length,
    });
  }

  // =========================================================================
  // Event delivery
  // =========================================================================

  private deliverEvents(batched: PendingEvent[]): void {
    // Delivery-time re-check: a channel tuned out after its events were
    // batched is held now, and "already shown above at arrival" would be
    // untrue of them. They are dropped; the hold's own reader has them.
    const heldAt = (e: PendingEvent): string | undefined => e.routeChannelId ?? e.channelId;
    const events = batched.filter((e) => {
      const channel = heldAt(e);
      return !(channel && this.isHeldFn(e.serverId, channel));
    });
    if (events.length < batched.length) {
      this.emitTrace({
        type: 'gate:held-dropped',
        dropped: batched.length - events.length,
        channels: [...new Set(batched.filter((e) => !events.includes(e)).map(heldAt))],
      });
    }
    if (events.length === 0) return;
    // Who each delivery woke, so that a throw after a wake is told as a
    // delivery in part (PartialDelivery), the batch dropped only for those
    // it didn't wake.
    const woke: string[] = [];
    if (events.every((e) => e.recipients === undefined)) {
      const names = this.getAgentNamesFn();
      deliveredTracking(woke, names, () => this.deliverBatch(events, names, undefined, woke));
      return;
    }
    const woken = new Set(events.flatMap((e) => e.recipients ?? []));
    if (events.some((e) => e.recipients === undefined)) for (const name of this.getAgentNamesFn()) woken.add(name);
    const groups = new Map<string, { agents: string[]; events: PendingEvent[] }>();
    for (const agentName of woken) {
      const seen = events.filter((e) => e.recipients === undefined || e.recipients.includes(agentName));
      const key = seen.map((e) => events.indexOf(e)).join(',');
      const group = groups.get(key) ?? { agents: [], events: seen };
      group.agents.push(agentName);
      groups.set(key, group);
    }
    deliveredTracking(woke, [...woken], () => {
      for (const group of groups.values()) this.deliverBatch(group.events, group.agents, group.agents, woke);
    });
  }

  private deliverBatch(events: PendingEvent[], woken: readonly string[], audience?: readonly string[], woke?: string[]): void {
    const policyNames = [...new Set(events.map(e => e.policyName))];

    // Events whose content the framework already stored at arrival (MCPL
    // channel-incoming / push-event) get a compact REFERENCE — re-quoting
    // them here would inject a duplicate copy of the message minutes after
    // the fact, reading as fresh input the agent may have already handled.
    // Only events with no context entry of their own carry their content.
    const quoted = events.filter(e => !e.inContext);
    const referenced = events.filter(e => e.inContext);

    const lines: string[] = quoted.map(e => `- [${e.policyName}] (${e.eventType}): ${suppliedValue(e.content)}`);
    // How each referenced channel is named in the line, in order.
    const shown: string[] = [];
    if (referenced.length > 0) {
      // By channel, its server and its id: two servers' channels can share
      // an id.
      const byChannel = new Map<string, { name: string; count: number; oldest: number; label?: string }>();
      for (const e of referenced) {
        // The registered id when known, so this line names the channel the
        // same way routing notices and send tools do (a push event's own
        // channelId is the adapter's raw id), shown as the agent names it
        // back where the event names its server.
        // Only a registered id is a channel name; an adapter's raw id is
        // shown as it is.
        const id = e.routeChannelId ?? e.channelId;
        const name = id === undefined
          ? '(unknown channel)'
          : e.routeChannelId !== undefined && e.serverId !== undefined && this.channelShownFn
            ? this.channelShownFn({ serverId: e.serverId, channelId: e.routeChannelId })
            : suppliedValue(id);
        const key = JSON.stringify([e.serverId ?? null, id ?? null]);
        const entry = byChannel.get(key) ?? { name, count: 0, oldest: e.timestamp, label: e.channelLabel };
        entry.count += 1;
        entry.oldest = Math.min(entry.oldest, e.timestamp);
        entry.label = entry.label ?? e.channelLabel;
        byChannel.set(key, entry);
      }
      for (const { name, count, oldest, label } of byChannel.values()) {
        // Prefer the human-readable name; keep the id parenthesized so the
        // agent can still address tools that want the composite id. A name
        // may carry its own `#`, so one is added only where the name lacks
        // it, as at the other places that add a `#`.
        const channel = label ? `${label.startsWith('#') ? '' : '#'}${suppliedValue(label)} (${name})` : name;
        shown.push(channel);
        lines.push(referenceLine(count, channel, oldest, Date.now()));
      }
    }

    // The line says which messages a wake is for. For one message that is
    // still the newest thing in the window it would be written to, it says
    // nothing the message right above doesn't. But the turn compiles later,
    // and what lands in between puts the message above other entries, so the
    // gate hands the line to the wake (WakeProvenance.line) and a fresh start
    // of the wake's turn decides it (WakeLine). Several messages, one with
    // anything after it, or content the line quotes, keep the line now.
    const text = `[${NOTICE_TAG.gate}: ${events.length} event${events.length > 1 ? 's' : ''} matched]\n\n${lines.join('\n')}`;
    const only = events.length === 1 && events[0].inContext ? events[0] : undefined;
    let line: WakeLine | undefined;
    // Where a line stored now landed, for the delivery agent's wake, as the
    // self-wake's notice places its own (readsRowFor): a live turn that
    // carried and answered the line drops the wake. Other agents' wakes stay
    // plain by readsRowFor's rule.
    const placement: WritePlacement = {};
    if (only && this.newestEntry(only, audience)) {
      const shownChannel = only.routeChannelId ?? only.channelId;
      line = {
        entry: entryRef(only),
        policyNames,
        shown: shown[0],
        at: only.timestamp,
        ...(shownChannel !== undefined ? { channelId: shownChannel } : {}),
      };
    } else {
      this.addMessageFn('user', [{ type: 'text', text }], {
        source: 'gate:debounce',
        policies: policyNames,
      }, undefined, placement, audience);
    }

    // Provenance of the batched wake (who/where woke the agent): the newest
    // ADDRESSED event first, else the newest event naming a channel or an
    // author; channel + author + addressed from that ONE event. When that
    // event addressed the agent and its registered channel is known,
    // `routeChannelId` names the turn's speech locus too — the reply goes
    // back to whoever addressed the agent, not to whichever channel last saw
    // any traffic. Ambient-only batches set no locus. A batch whose line the
    // gate left to the turn's start carries it too (`line`), one object
    // shared by every agent woken with these messages, so it is written once.
    const chosen = wakeProvenance(events);
    const provenance = line ? { ...chosen, line } : chosen;
    for (const agentName of woken) {
      this.requestInferenceFn(agentName, 'gate:debounce', 'gate', provenance, line ? undefined : placement);
      woke?.push(agentName);
    }
  }

  /** isNewestEntry for one event; a callback fault keeps the line. */
  private newestEntry(event: PendingEvent, recipients?: readonly string[]): boolean {
    if (!this.isNewestEntryFn) return false;
    try {
      return this.isNewestEntryFn(entryRef(event), recipients) === true;
    } catch {
      return false;
    }
  }

  // =========================================================================
  // Reply judge (`judge` rules)
  // =========================================================================

  /**
   * Send one of a judge rule's batches to the reply judge. While a resident's
   * turn runs or the host is quiesced the batch is held instead, merged with
   * any the rule already holds, and judged once both are clear
   * (flushJudgeHeldIfClear): the judge then reads the context the turn left,
   * which may already have answered it. While the judge decides one of the
   * rule's batches, a later one waits for that verdict (finishJudging), so the
   * judge never decides two of a rule's batches at once.
   */
  private judgeBatch(policyName: string, events: PendingEvent[], judge: JudgeConfig): void {
    if (this.disposed) return;
    const deciding = this.judging.get(policyName);
    if (deciding) {
      deciding.queued.push(...events);
      this.capJudgeEvents(deciding.queued);
      return;
    }
    if (this.judgedTurnRunning() || this.quiesced) {
      this.holdForJudge(policyName, events, judge);
      return;
    }
    const fn = this.judgeFn;
    if (!fn) {
      this.deliverOrBuffer(events);
      return;
    }
    const abort = new AbortController();
    const agentNames = this.getAgentNamesFn();
    const state: JudgingState = { events, judge, started: Date.now(), abort, queued: [] };
    this.judging.set(policyName, state);
    const timedOut = new Promise<never>((_, reject) => {
      state.timer = setTimeout(() => {
        abort.abort();
        reject(new Error(`the judge took more than ${this.judgeTimeoutMs} ms`));
      }, this.judgeTimeoutMs);
      // Never keep the process alive on the judge's account.
      state.timer.unref?.();
    });
    let asked: Promise<JudgeVerdict>;
    try {
      asked = fn({
        policyName,
        ...(judge.instructions !== undefined ? { instructions: judge.instructions } : {}),
        events: events.map((e) => this.judgeEventSummary(e)),
        agentNames,
        upcomingWakes: this.upcomingWakes(agentNames, policyName),
        signal: abort.signal,
      });
    } catch (err) {
      asked = Promise.reject(err);
    }
    Promise.race([asked, timedOut]).then(
      (verdict) => this.finishJudging(policyName, state, verdict),
      (err: unknown) => this.finishJudging(policyName, state, undefined, err),
    ).finally(() => {
      if (state.timer) clearTimeout(state.timer);
    }).catch((err: unknown) => {
      console.error(`[gate] Rule ${quotedValue(policyName)}: the judge's verdict couldn't be applied (${errorText(err)})`);
    });
  }

  /** Hold a batch for the judge until no turn changing the context it reads
   *  runs and the host isn't quiesced, merged with what the rule already holds. */
  private holdForJudge(policyName: string, events: PendingEvent[], judge: JudgeConfig): void {
    const held = this.judgeHeld.get(policyName);
    if (held) {
      held.events.push(...events);
      held.judge = judge;
      this.capJudgeEvents(held.events);
    } else {
      const fresh = [...events];
      this.capJudgeEvents(fresh);
      this.judgeHeld.set(policyName, { events: fresh, judge });
    }
  }

  /**
   * Keep a rule's events waiting on the judge to the inference buffer's cap,
   * dropping the oldest, counted and logged as bufferForInference counts its
   * drops: a turn that never ends (the wake-wedge) or a long quiesce on a busy
   * channel would otherwise grow them without bound. A queue beside a batch
   * the judge is deciding is capped on its own, so its newest events are never
   * the ones dropped for the batch ahead of it.
   */
  private capJudgeEvents(events: PendingEvent[]): void {
    const drop = events.length - MAX_INFERENCE_BUFFER;
    if (drop <= 0) return;
    events.splice(0, drop);
    const before = this.droppedJudgeEvents;
    this.droppedJudgeEvents += drop;
    if (Math.floor(before / 50) !== Math.floor(this.droppedJudgeEvents / 50) || before === 0) {
      console.error(
        `[gate] events waiting on the reply judge reached the cap (${MAX_INFERENCE_BUFFER} per rule): dropped `
        + `${this.droppedJudgeEvents} oldest so far${this.quiesced ? ' during quiesce' : ''}`,
      );
    }
  }

  /** The rule's judge as it is now, when the rule is still a judge rule; else the one the batch was asked with. */
  private currentJudge(policyName: string, asked: JudgeConfig): JudgeConfig {
    const now = this.config.policies.find((p) => p.name === policyName)?.behavior;
    return typeof now === 'object' && 'judge' in now ? now.judge : asked;
  }

  /**
   * The gate's own timers that will wake `agentNames` with no new event, for
   * the judge to weigh what waiting costs: each agent's pending self-wake
   * (skip_reply's wake_in_seconds), the end of a sleep, and the pending
   * batches of rules other than `exceptPolicy` (a debounce's wakes the agent
   * when it fires; a judge rule's goes to the judge, so it only may). A batch,
   * and a sleep with no agent named, reach the gate's recipients alone.
   */
  upcomingWakes(agentNames: string[], exceptPolicy?: string): UpcomingWake[] {
    const wakes: UpcomingWake[] = [];
    const now = this.now();
    for (const name of agentNames) {
      const due = this.selfWakeDue.get(name);
      if (due && this.selfWakeTimers.has(name)) {
        wakes.push({ at: due.at, certain: true, kind: 'self-wake', what: `${agentNames.length > 1 ? `${name}'s` : 'its'} own ${due.source} timer` });
      }
    }
    const recipients = this.getAgentNamesFn();
    const recipient = agentNames.some((name) => recipients.includes(name));
    if (this.sleepUntil > now && (this.sleepAgent === undefined ? recipient : agentNames.includes(this.sleepAgent))) {
      wakes.push({ at: this.sleepUntil, certain: true, kind: 'sleep-end', what: 'the end of its sleep' });
    }
    for (const [name, state] of this.debounceTimers) {
      if (!recipient || name === exceptPolicy || state.events.length === 0) continue;
      const n = state.events.length;
      const batch = `${n} ${n === 1 ? 'event' : 'events'}`;
      wakes.push(state.judge
        ? { at: state.dueAt, certain: false, kind: 'judge-batch', what: `rule ${quotedValue(name)}'s batch of ${batch} goes to the judge` }
        : { at: state.dueAt, certain: true, kind: 'debounce', what: `rule ${quotedValue(name)}'s debounced batch of ${batch}` });
    }
    return wakes.sort((a, b) => (a.at ?? 0) - (b.at ?? 0));
  }

  /** A batch's event as the judge is shown it. */
  private judgeEventSummary(e: PendingEvent): JudgeEventSummary {
    const id = e.routeChannelId ?? e.channelId;
    let channel: string | undefined;
    if (id !== undefined) {
      let name = id;
      if (e.routeChannelId !== undefined && e.serverId !== undefined && this.channelShownFn) {
        try {
          name = this.channelShownFn({ serverId: e.serverId, channelId: e.routeChannelId });
        } catch {
          name = id;
        }
      }
      channel = e.channelLabel ? `${e.channelLabel.startsWith('#') ? e.channelLabel : `#${e.channelLabel}`} (${name})` : name;
    }
    return {
      eventType: e.eventType,
      ...(channel !== undefined ? { channel } : {}),
      ...(e.authorId !== undefined ? { authorId: e.authorId } : {}),
      addressed: e.addressed,
      content: e.content,
      at: e.timestamp,
    };
  }

  /**
   * Apply the judge's verdict on a batch. Reply: the batch, with any of the
   * rule's batches that fired meanwhile, is delivered as a debounce's is
   * (held for a turn that started meanwhile, as fireDebounce holds one). Wait:
   * nothing is delivered, and batches that fired meanwhile go to the judge
   * afresh. A judge that failed, timed out or answered nothing usable decides
   * by onError: "wake" delivers, "skip" doesn't. Each verdict is traced and
   * counted for gate_status, and a failure is logged.
   */
  private finishJudging(policyName: string, state: JudgingState, verdict: JudgeVerdict | undefined, err?: unknown): void {
    // A verdict for a batch the gate let go of (dispose() clears what the
    // judge was deciding) applies to nothing, even after a start() since.
    if (this.judging.get(policyName) !== state) return;
    this.judging.delete(policyName);
    if (state.timer) clearTimeout(state.timer);
    const durationMs = Date.now() - state.started;
    const failed = verdict == null || typeof verdict !== 'object' || typeof verdict.reply !== 'boolean';
    if (failed && (err as { providerAdmission?: unknown } | undefined)?.providerAdmission === 'deferred') {
      const wakes = this.judgeOnError === 'wake';
      console.error(
        `[gate] Rule ${quotedValue(policyName)}: the reply judge made no call (${errorText(err)}), so its batch of ${state.events.length} `
        + `${state.events.length === 1 ? 'event' : 'events'} ${wakes ? 'wakes the agent' : "doesn't wake the agent"} (judge onError "${this.judgeOnError}")`,
      );
      if (this.disposed) return;
      if (wakes) this.deliverOrBuffer([...state.events, ...state.queued]);
      else if (state.queued.length > 0) this.judgeBatch(policyName, state.queued, this.currentJudge(policyName, state.judge));
      return;
    }
    const outcome: 'reply' | 'wait' | 'error' = failed ? 'error' : verdict.reply ? 'reply' : 'wait';
    const reason = failed
      ? (err !== undefined ? errorText(err) : 'the judge gave no verdict')
      : typeof verdict.reason === 'string' ? verdict.reason : '';
    const record = this.judgeRecords.get(policyName) ?? { verdicts: { reply: 0, wait: 0, error: 0 } };
    record.verdicts[outcome]++;
    record.last = {
      at: Date.now(),
      verdict: outcome,
      reason: cutToFit(suppliedValue(reason), 300),
      eventCount: state.events.length,
      durationMs,
      ...(!failed && typeof verdict.inputTokens === 'number' ? { inputTokens: verdict.inputTokens } : {}),
    };
    if (this.config.policies.some((p) => p.name === policyName)) this.judgeRecords.set(policyName, record);
    if (failed) {
      this.judgeFailStreak++;
      this.judgeLastFailure = cutToFit(suppliedValue(reason), 200);
    } else {
      this.judgeFailStreak = 0;
    }
    const wake = outcome === 'reply' || (outcome === 'error' && this.judgeOnError === 'wake');
    if (failed) {
      console.error(
        `[gate] Rule ${quotedValue(policyName)}: the reply judge failed (${reason}), so its batch of ${state.events.length} `
        + `${state.events.length === 1 ? 'event' : 'events'} ${wake ? 'wakes the agent' : "doesn't wake the agent"} (judge onError "${this.judgeOnError}")`,
      );
    }
    this.emitTrace({
      type: 'gate:judge-verdict',
      policyName,
      verdict: outcome,
      woke: wake,
      eventCount: state.events.length,
      durationMs,
      ...(!failed && verdict.model ? { model: verdict.model } : {}),
      ...(!failed && typeof verdict.inputTokens === 'number' ? { inputTokens: verdict.inputTokens } : {}),
      ...(!failed && typeof verdict.cacheReadTokens === 'number' ? { cacheReadTokens: verdict.cacheReadTokens } : {}),
      ...(!failed && typeof verdict.outputTokens === 'number' ? { outputTokens: verdict.outputTokens } : {}),
    });
    if (this.disposed) return;
    const judge = this.currentJudge(policyName, state.judge);
    if (wake) {
      this.deliverOrBuffer([...state.events, ...state.queued]);
      return;
    }
    if (state.queued.length > 0) this.judgeBatch(policyName, state.queued, judge);
  }

  /** Deliver a batch now, or hold it for the agents' turns and the host's
   *  quiesce to end, as fireDebounce does; a delivery that throws drops it,
   *  named in the log. */
  private deliverOrBuffer(events: PendingEvent[]): void {
    if (events.length === 0) return;
    if (this.inferring.size > 0 || this.quiesced) {
      this.bufferForInference(events);
      return;
    }
    try {
      this.deliverEvents(events);
    } catch (err) {
      const one = events.length === 1;
      console.error(
        `[gate] a judged batch of ${events.length} ${one ? 'event' : 'events'} `
        + (deliveredInPart(err) ?? `couldn't be delivered (${errorText(err)}), so the batch is dropped`),
      );
    }
  }

  private changesJudgedContext(agentName: string): boolean {
    return this.changesJudgedContextFn?.(agentName) ?? true;
  }

  private judgedTurnRunning(): boolean {
    return [...this.inferring].some((name) => this.changesJudgedContext(name));
  }

  private stopJudging(): void {
    for (const [policyName, state] of [...this.judging]) {
      this.judging.delete(policyName);
      if (state.timer) clearTimeout(state.timer);
      state.abort.abort();
      this.holdForJudge(policyName, [...state.events, ...state.queued], state.judge);
    }
  }

  /** Send the batches held for the judge once no turn changing the context it reads runs and the host isn't quiesced. */
  private flushJudgeHeldIfClear(): void {
    if (this.quiesced || this.judgedTurnRunning() || this.judgeHeld.size === 0) return;
    const held = [...this.judgeHeld];
    this.judgeHeld.clear();
    // Deferred, as the inference buffer's flush is, to stay out of the
    // turn-end callback that called this.
    queueMicrotask(() => {
      for (const [policyName, { events, judge }] of held) this.judgeBatch(policyName, events, this.currentJudge(policyName, judge));
    });
  }

  // =========================================================================
  // Inference lifecycle
  // =========================================================================

  onInferenceStarted(agentName: string): void {
    this.inferring.add(agentName);
    if (this.changesJudgedContext(agentName)) this.stopJudging();
    // A turn is starting — whatever caused it supersedes any pending
    // self-wake. (Arming happens MID-turn via skip_reply, i.e. after this
    // ran for the arming turn, so a fresh arm always survives its own turn.)
    const selfWake = this.selfWakeTimers.get(agentName);
    if (selfWake) {
      clearTimeout(selfWake);
      this.selfWakeTimers.delete(agentName);
    }
  }

  /** A turn that continues another (a budget restart, a tool-result-guard
   *  retry) holds the entry its predecessor kept for it, and takes it again
   *  where that entry ended in between, as at a provider hold that kept the
   *  turn from starting, whose end queues it again. Unlike
   *  onInferenceStarted it leaves a pending self-wake alone: the logical
   *  turn that armed it is the one still running. */
  onInferenceResumed(agentName: string): void {
    this.inferring.add(agentName);
    if (this.changesJudgedContext(agentName)) this.stopJudging();
  }

  onInferenceEnded(agentName: string): void {
    this.inferring.delete(agentName);
    this.flushInferenceBufferIfClear();
    this.flushJudgeHeldIfClear();
  }

  /**
   * Host quiesce suppression (issue #122). While set, debounce firings buffer
   * instead of writing gate messages into context; clearing it flushes the
   * buffer through the same path a turn's end uses. Self-wake and sleep-expiry
   * timers deliberately do NOT route through this — their inference requests
   * are per-agent targeted pushes that the framework's quiesce wake gate parks
   * and releases at resume, whereas the buffer's deliverEvents wakes every
   * agent a batch is for.
   */
  setQuiesced(quiesced: boolean): void {
    if (this.quiesced === quiesced) return;
    this.quiesced = quiesced;
    if (quiesced) {
      // A judge reading the context now would read it mid-surgery, and call
      // its provider while the host holds still: it's stopped, and its batch
      // held to be judged at resume.
      this.stopJudging();
    } else {
      this.flushInferenceBufferIfClear();
      this.flushJudgeHeldIfClear();
    }
  }

  private flushInferenceBufferIfClear(): void {
    if (this.quiesced) return;
    if (this.inferring.size === 0 && this.inferenceBuffer.length > 0) {
      const events = this.inferenceBuffer.splice(0);
      // Defer to avoid re-entrancy inside trace callbacks. A delivery that
      // throws drops what was held, named in the log, as fireDebounce drops a
      // batch: thrown in the microtask, it would be uncaught.
      queueMicrotask(() => {
        try {
          this.deliverEvents(events);
        } catch (err) {
          const one = events.length === 1;
          const held = `${events.length} ${one ? 'event' : 'events'}`;
          const partly = deliveredInPart(err);
          console.error(partly
            ? `[gate] a batch of ${held}, held for an agent's turn or the host's quiesce, ${partly}`
            : `[gate] ${held} held for an agent's turn or the host's quiesce couldn't be delivered (${errorText(err)}), `
              + `so ${one ? "it's" : "they're"} dropped`);
        }
      });
    }
  }

  /** Live inference-gating snapshot for diagnostics (e.g. a SIGUSR2 dump).
   *  A non-empty `inferring` with a stale timestamp + growing `bufferedEvents`
   *  is the signature of the wake-wedge: an agent stuck mid-"inference" so all
   *  incoming events buffer and never trigger. */
  inferenceDiagnostics(): {
    inferring: string[];
    bufferedEvents: number;
    droppedBufferedEvents: number;
    sleepUntil: number;
    /** Events held for the reply judge until the turn or quiesce ends, and the judge's own drops at the cap. */
    judgeHeldEvents: number;
    droppedJudgeEvents: number;
  } {
    let judgeHeldEvents = 0;
    for (const held of this.judgeHeld.values()) judgeHeldEvents += held.events.length;
    return {
      inferring: [...this.inferring],
      bufferedEvents: this.inferenceBuffer.length,
      droppedBufferedEvents: this.droppedBufferedEvents,
      sleepUntil: this.sleepUntil,
      judgeHeldEvents,
      droppedJudgeEvents: this.droppedJudgeEvents,
    };
  }

  // =========================================================================
  // Inference buffer cap
  // =========================================================================

  /** Called internally when debounce fires during inference. */
  private bufferForInference(events: PendingEvent[]): void {
    for (const event of events) {
      if (this.inferenceBuffer.length >= MAX_INFERENCE_BUFFER) {
        this.inferenceBuffer.shift(); // Drop oldest
        // Telemetry (issue #122): quiesce stretches buffering from
        // single-inference minutes to operator-length windows, so silent
        // eviction is no longer a corner case — count and log it, or the
        // resume flush reads as complete when it isn't.
        this.droppedBufferedEvents++;
        if (this.droppedBufferedEvents % 50 === 1) {
          console.error(
            `[gate] inference buffer cap (${MAX_INFERENCE_BUFFER}) — dropped ` +
            `${this.droppedBufferedEvents} oldest buffered event(s)` +
            `${this.quiesced ? ' during quiesce' : ''}; the flush on release will be incomplete`,
          );
        }
      }
      this.inferenceBuffer.push(event);
    }
  }

  // =========================================================================
  // Tool: gate:status
  // =========================================================================

  // =========================================================================
  // Sleep
  // =========================================================================

  /** Begin (or extend) a sleep window of `seconds`. Returns the wake time. */
  setSleep(seconds: number, note?: string, agentName?: string): { until: number } {
    const ms = Math.max(0, Math.floor(seconds * 1000));
    this.sleepUntil = this.now() + ms;
    this.sleepNote = note;
    this.sleepAgent = agentName;
    this.sleepSuppressed = 0;
    // Arm the self-wake: when the window elapses, clear sleep and request an
    // inference so the agent resumes on its own (not dependent on a heartbeat
    // tick or an incoming message). Cancelled by clearSleep()/`wake`, and by
    // dispose(), after which nothing arms it.
    this.armSleepWake();
    this.reloadPrivilegedIfChanged();
    this.emitTrace({
      type: 'gate:decision',
      eventType: 'sleep:set',
      matchedPolicy: 'asleep',
      trigger: false,
      behavior: 'skip',
    });
    return { until: this.sleepUntil };
  }

  /**
   * Arm the sleep's wake for its end by the gate's own clock. One timer holds
   * at most MAX_TIMER_MS, about 24.8 days, so a longer sleep waits in steps,
   * and wakeFromSleep reads the clock as each one fires. Nothing is armed
   * once the gate is disposed.
   */
  private armSleepWake(): void {
    if (this.sleepTimer) { clearTimeout(this.sleepTimer); this.sleepTimer = null; }
    if (this.disposed) return;
    const remaining = Math.max(0, this.sleepUntil - this.now());
    this.sleepTimer = setTimeout(() => this.wakeFromSleep('sleep-expired'), Math.min(remaining, MAX_TIMER_MS));
  }

  /**
   * `agentName` is gone, as an agent's end removes one: its pending
   * self-wake is cancelled, and a sleep it set ends, rather than go on
   * quieting every agent and then wake a name that no longer exists.
   */
  agentGone(agentName: string): void {
    const selfWake = this.selfWakeTimers.get(agentName);
    if (selfWake) {
      clearTimeout(selfWake);
      this.selfWakeTimers.delete(agentName);
    }
    if (this.sleepAgent === agentName) this.clearSleep();
  }

  // =========================================================================
  // Self-wake (skip_reply wake_in_seconds)
  // =========================================================================

  /**
   * Arm a one-shot self-wake for `agentName` in `seconds` (clamped to
   * [1, 3600]). Fires a normal inference request when it elapses — no
   * suppression window, unlike sleep. Re-arming replaces the pending timer.
   * Cancelled by the agent's next turn start (see onInferenceStarted):
   * the semantics are "if nothing else wakes me by then, wake me".
   */
  armSelfWake(agentName: string, seconds: number, source = 'skip_reply'): { inMs: number; armed: boolean } {
    const ms = Math.max(1_000, Math.min(3_600_000, Math.floor(seconds * 1000)));
    // A stopped framework's late turn arms no timer (disposed). A self-wake
    // doesn't outlive a stop, as dispose() clearing the pending ones says.
    if (this.disposed) return { inMs: ms, armed: false };
    const prev = this.selfWakeTimers.get(agentName);
    if (prev) clearTimeout(prev);
    const timer = setTimeout(() => {
      this.selfWakeTimers.delete(agentName);
      this.emitTrace({
        type: 'gate:decision',
        eventType: 'selfwake:fired',
        matchedPolicy: 'self-wake',
        trigger: true,
        behavior: 'always',
      });
      // Compact in-window notice: without it the wake turn contains nothing
      // new, so the agent can't tell WHAT woke it (its own timer vs. a
      // heartbeat) or WHEN. One line, timestamped to the second. Added
      // before the inference request so it rides the wake turn: it is stored
      // at once, and while a turn of the agent's is alive it is kept out of
      // the window until the agent's next presentation point.
      const nowIso = new Date(this.now()).toISOString().slice(0, 19) + 'Z';
      // Deliver the notice into the WAKING agent's window — a self-wake
      // armed by a non-primary agent (e.g. a subconscious cadence) must not
      // narrate itself into the primary's context. Its wake goes with it: an
      // agent that heard the notice during a turn was awake when its timer
      // fired, and the host drops the wake once a request that carried the
      // notice is answered.
      const placement: WritePlacement = {};
      this.addMessageFn('user', [{
        type: 'text',
        text: `[${NOTICE_TAG.selfWake}] your ${source} timer (${Math.round(ms / 1000)}s) elapsed — now ${nowIso}`,
      }], { source: 'gate:self-wake' }, agentName, placement);
      this.requestInferenceFn(
        agentName,
        `self-scheduled wake (${source}, ${Math.round(ms / 1000)}s)`,
        'self-wake',
        undefined,
        placement,
      );
    }, ms);
    this.selfWakeTimers.set(agentName, timer);
    this.selfWakeDue.set(agentName, { at: this.now() + ms, source });
    this.emitTrace({
      type: 'gate:decision',
      eventType: 'selfwake:set',
      matchedPolicy: 'self-wake',
      trigger: false,
      behavior: 'skip',
    });
    return { inMs: ms, armed: true };
  }

  /** End sleep immediately. Returns true if the agent was asleep. */
  clearSleep(): boolean {
    const wasAsleep = this.sleepUntil > this.now();
    this.sleepUntil = 0;
    this.sleepNote = undefined;
    this.sleepAgent = undefined;
    if (this.sleepTimer) { clearTimeout(this.sleepTimer); this.sleepTimer = null; }
    return wasAsleep;
  }

  /**
   * Self-wake handler: fired by the sleepTimer when a sleep window elapses.
   * Clears the sleep state and requests an inference so the agent wakes on its
   * own — this is what makes `sleep(N)` a real "wake me in N seconds" rather
   * than just a suppression window. No-op if sleep was already cleared (via
   * `wake`). A timer that fires before the sleep's end by the gate's clock
   * arms the rest: a step of a sleep longer than one timer holds, a timer that
   * fires early (Node's can, by a millisecond), or a clock set back.
   */
  private wakeFromSleep(reason: string): void {
    // The timer that called it has fired.
    if (this.sleepTimer) { clearTimeout(this.sleepTimer); this.sleepTimer = null; }
    if (this.sleepUntil === 0) return;
    if (this.sleepUntil > this.now()) {
      this.armSleepWake();
      return;
    }
    const note = this.sleepNote;
    const agent = this.sleepAgent;
    this.sleepUntil = 0;
    this.sleepNote = undefined;
    this.sleepAgent = undefined;
    this.emitTrace({
      type: 'gate:decision',
      eventType: 'sleep:expired',
      matchedPolicy: 'asleep',
      trigger: true,
      behavior: 'always',
    });
    const detail = note ? `${reason}: ${note}` : reason;
    const targets = agent ? [agent] : this.getAgentNamesFn();
    for (const a of targets) this.requestInferenceFn(a, detail, 'sleep');
  }

  /** Current sleep state, or null if awake. */
  getSleepState(): { until: number; remainingMs: number; note?: string; suppressed: number } | null {
    const remainingMs = this.sleepUntil - this.now();
    if (remainingMs <= 0) return null;
    return { until: this.sleepUntil, remainingMs, note: this.sleepNote, suppressed: this.sleepSuppressed };
  }

  /** Author id from an event's metadata, across the discord ingest shapes. */
  private extractAuthorId(metadata?: Record<string, unknown>): string | null {
    if (!metadata) return null;
    const author = metadata.author as { id?: unknown } | undefined;
    if (author && author.id != null) return String(author.id);
    if (metadata.authorId != null) return String(metadata.authorId);
    return null;
  }

  /**
   * Whether an author id is on the privileged-users list (hot-reloaded).
   * Shared by sleep bypass and tune-out wake classification (#77: wakes are
   * "mentions, gate-privileged authors, etc.").
   */
  isPrivilegedUser(authorId: string | null | undefined): boolean {
    if (!authorId) return false;
    this.reloadPrivilegedIfChanged();
    return this.privilegedUserIds.has(authorId);
  }

  /**
   * Read the privileged-users file: a list of user ids, or `{"userIds": [...]}`,
   * each a non-empty string or a safe integer (a whole number within 2^53 - 1 of zero). An absent file
   * means no one is privileged. A file that can't be read, isn't JSON, or
   * holds no list leaves the list that last loaded in this process in effect
   * (none, at startup), with its error in gate_status until a later read
   * loads it, finds it gone, or fails another way. In a list, an entry that isn't a user id is skipped, and named
   * in the file's error, and the rest load. With `unlessUnchanged`, a file whose
   * text is the text last read isn't parsed again.
   */
  private loadPrivileged(opts?: { unlessUnchanged?: boolean }): void {
    if (!this.privilegedUsersPath) return;
    const file = `The privileged-users file, at ${this.privilegedUsersPath},`;
    const held = this.privilegedUserIds.size;
    const meanwhile = held === 0
      ? 'no one is privileged'
      : `${held === 1 ? 'the one id of the list that last loaded stays' : `the ${held} ids of the list that last loaded stay`} privileged`;
    const revoke = 'Replacing it with a file holding [], or removing it, makes no one privileged at the gate\'s next check for changes.';
    const failed = (problem: string, fix: string): string => `${file} ${problem}, so ${meanwhile}. ${fix} ${revoke}`;
    let raw: string;
    try {
      raw = readFileSync(this.privilegedUsersPath, 'utf8');
    } catch (err) {
      // Read again next time: a file can become readable with its text
      // unchanged, as a chmod makes it.
      this.privilegedText = undefined;
      if (isMissing(err)) {
        this.privilegedUserIds = new Set();
        this.privilegedError = null;
      } else {
        this.privilegedError = failed(
          `can't be read: ${quotedValue(errorText(err))}`,
          'Whoever runs this host can make it a file the gate can read, and the gate reads it again at its next check for changes.',
        );
      }
      return;
    }
    if (opts?.unlessUnchanged && raw === this.privilegedText) return;
    this.privilegedText = raw;
    const fixed = 'Once it holds a list of user ids, the gate loads it at its next check for changes.';
    let ids: unknown;
    try {
      const parsed: unknown = parseGateJson(raw);
      ids = Array.isArray(parsed) ? parsed : (parsed as { userIds?: unknown } | null)?.userIds;
    } catch (err) {
      this.privilegedError = failed(`isn't JSON: ${quotedValue(errorText(err))}`, fixed);
      return;
    }
    // A file that parses but holds no list hasn't loaded either: it used to
    // mean no one is privileged, without a word.
    if (!Array.isArray(ids)) {
      this.privilegedError = failed('holds no list of user ids, where one is needed, such as ["123"] or {"userIds": ["123"]}', fixed);
      return;
    }
    const loaded = new Set<string>();
    const skipped: unknown[] = [];
    for (const id of ids) {
      if (typeof id === 'string' && id !== '') loaded.add(id);
      // JSON.parse has already rounded an integer past 2^53, and the rounded
      // value can be another user's id, so it's skipped rather than loaded.
      else if (typeof id === 'number' && Number.isSafeInteger(id)) loaded.add(String(id));
      else skipped.push(id);
    }
    this.privilegedUserIds = loaded;
    this.privilegedError = skipped.length > 0 ? skippedPrivilegedIds(skipped, loaded.size, this.privilegedUsersPath) : null;
  }

  /** At most once a second, the privileged-users file read again, and loaded when its text has changed. */
  private reloadPrivilegedIfChanged(): void {
    if (!this.privilegedUsersPath) return;
    const now = this.now();
    if (checkedRecently(now, this.lastPrivilegedCheck)) return;
    this.lastPrivilegedCheck = now;
    this.loadPrivileged({ unlessUnchanged: true });
  }

  getToolDefinition(): ToolDefinition {
    return {
      name: 'gate_status',
      description: 'Show the current EventGate configuration, per-policy match counts, debounce state, and any config errors.',
      inputSchema: {
        type: 'object',
      },
    };
  }

  async handleToolCall(): Promise<{ success: boolean; data?: GateStatus; error?: string }> {
    // What's in force now: each file read again if a check is due, as the
    // next event would.
    this.reloadIfChanged();
    this.reloadPrivilegedIfChanged();
    const status = this.getStatus();
    return { success: true, data: status };
  }

  getStatus(): GateStatus {
    this.syncSuppressScripts();
    const policies: GatePolicyStats[] = this.config.policies.map(p => {
      const stats = this.stats.get(p.name);
      const debounce = this.debounceTimers.get(p.name);
      const result: GatePolicyStats = {
        name: p.name,
        behavior: p.behavior,
        matchCount: stats?.matchCount ?? 0,
        lastMatchTimestamp: stats?.lastMatchTimestamp ?? null,
        ...(p.suppress
          ? { suppress: { ...p.suppress, ...(p.suppress.script !== undefined && this.suppressScripts.status(p.name) ? { scriptStatus: this.suppressScripts.status(p.name)! } : {}) } }
          : {}),
      };
      if (typeof p.behavior === 'object' && 'debounce' in p.behavior) {
        result.debounceState = {
          pendingCount: debounce?.events.length ?? 0,
          nextDeliveryMs: null, // Timer internals not easily inspectable
        };
      }
      if (typeof p.behavior === 'object' && 'rate_limit' in p.behavior) {
        result.rateLimitState = {
          bucketCount: this.rateLimitBuckets.get(p.name)?.size ?? 0,
          deniedCount: this.rateLimitDenied.get(p.name) ?? 0,
        };
      }
      if (typeof p.behavior === 'object' && 'passive_sample' in p.behavior) {
        result.passiveSampleState = {
          counterCount: this.passiveSampleCounters.get(p.name)?.size ?? 0,
          fireCount: this.passiveSampleFires.get(p.name) ?? 0,
        };
      }
      if (typeof p.behavior === 'object' && 'judge' in p.behavior) {
        const record = this.judgeRecords.get(p.name);
        result.judgeState = {
          pendingCount: debounce?.events.length ?? 0,
          judging: this.judging.has(p.name),
          heldCount: this.judgeHeld.get(p.name)?.events.length ?? 0,
          verdicts: { ...(record?.verdicts ?? { reply: 0, wait: 0, error: 0 }) },
          ...(record?.last ? { last: { ...record.last } } : {}),
        };
      }
      return result;
    });

    const byEventType: Record<string, { triggered: number; skipped: number }> = {};
    for (const [k, v] of this.defaultByEventType) byEventType[k] = { ...v };

    const sleepState = this.getSleepState();

    return {
      ...(sleepState
        ? {
            sleep: {
              until: sleepState.until,
              remainingMs: sleepState.remainingMs,
              note: sleepState.note,
              suppressed: sleepState.suppressed,
              privilegedCount: this.privilegedUserIds.size,
            },
          }
        : {}),
      configPath: this.configPath,
      configSource: this.configSource,
      lastReloadTimestamp: this.lastReloadTimestamp,
      default: this.config.default ?? 'always',
      script: this.gateScript.status(),
      policies,
      errors: [
        this.configErrorShown(), this.startNotice, this.startUnsaved, this.privilegedError,
        this.judgeUnwiredNotice(), this.judgeFailingNotice(),
      ]
        .filter((e): e is string => e !== null),
      // Fresh, not the cache: the sources the host knows (eventTypesFrom)
      // change as servers connect, with no change to the rules.
      shadowWarnings: this.lintShadows().map(formatShadowWarning),
      ...((): Pick<GateStatus, 'catchAll'> => {
        const rule = firstCatchAll(this.config.policies, { lettingBy: true });
        return rule ? { catchAll: {
          rule,
          note: `${JSON.stringify(rule)} lets MCPL events by without waking you and without naming a server, a channel or a tag, so a server connected later is handled by it until a rule for that server goes ahead of it.`,
        } } : {};
      })(),
      totalEvaluations: this.totalEvaluations,
      defaultDecisions: {
        triggered: this.defaultTriggered,
        skipped: this.defaultSkipped,
        byEventType,
      },
    };
  }

  /** gate_status's word on judge rules in force with no judge wired. */
  private judgeUnwiredNotice(): string | null {
    if (this.judgeFn) return null;
    const names = this.config.policies
      .filter((p) => typeof p.behavior === 'object' && 'judge' in p.behavior)
      .map((p) => p.name);
    if (names.length === 0) return null;
    return `${quotedList(names)} ${names.length === 1 ? 'is a judge rule' : 'are judge rules'}, and this host wires no reply `
      + `judge, so ${names.length === 1 ? 'its batches wake' : 'their batches wake'} the agent as a debounce of the same quiet period would`;
  }

  /** gate_status's word on a judge that keeps failing (JUDGE_FAILING_STREAK in a row). */
  private judgeFailingNotice(): string | null {
    if (this.judgeFailStreak < JUDGE_FAILING_STREAK) return null;
    return `the reply judge has failed its last ${this.judgeFailStreak} requests (the newest: ${this.judgeLastFailure}), `
      + (this.judgeOnError === 'wake'
        ? 'so judge rules wake the agent as debounces of the same quiet period would'
        : "so judge rules' batches don't wake the agent")
      + "; the host's judge model or provider may not serve it (GateOptions.judge)";
  }

  // =========================================================================
  // Cleanup
  // =========================================================================

  dispose(): void {
    this.gateScript.dispose();
    this.suppressScripts.dispose();
    for (const state of this.debounceTimers.values()) {
      clearTimeout(state.timer);
    }
    this.debounceTimers.clear();
    // A judge deciding now is told to stop, and its verdict, when it comes,
    // delivers nothing (finishJudging); held batches go with the buffer.
    for (const state of this.judging.values()) {
      if (state.timer) clearTimeout(state.timer);
      state.abort.abort();
    }
    this.judging.clear();
    this.judgeHeld.clear();
    for (const timer of this.selfWakeTimers.values()) {
      clearTimeout(timer);
    }
    this.selfWakeTimers.clear();
    this.selfWakeDue.clear();
    // The sleep stays, with its note and agent, and its timer goes: fired
    // after a stop(), its wake reached a framework that had stopped, and the
    // timer held the process until the sleep's end. Nothing arms one after
    // this, nor a self-wake: a turn a failed stop() left running can still
    // call sleep or skip_reply.
    if (this.sleepTimer) { clearTimeout(this.sleepTimer); this.sleepTimer = null; }
    this.disposed = true;
    this.rateLimitBuckets.clear();
    this.passiveSampleCounters.clear();
    this.rateLimitDenied.clear();
    this.passiveSampleFires.clear();
    this.inferenceBuffer = [];
    // stop() disposes the gate once its streams and event loop have ended (a
    // turn still compiling then is dropped at its next check, before it sends
    // anything). An agent left here by a turn whose exit didn't end it (a
    // retry stop() cancelled, a successor stop() refused) would make every
    // debounced batch buffer until that agent's next turn ended.
    this.inferring.clear();
  }
}
