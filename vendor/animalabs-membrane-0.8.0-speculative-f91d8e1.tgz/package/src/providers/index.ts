export {
  AnthropicAdapter,
  toAnthropicContent,
  fromAnthropicContent,
  type AnthropicAdapterConfig,
  type DynamicHeadersContext,
} from './anthropic.js';

export { flattenRootSchemaUnion } from './anthropic-tool-schema.js';

export {
  OpenRouterAdapter,
  toOpenRouterMessages,
  fromOpenRouterMessage,
  type OpenRouterAdapterConfig,
} from './openrouter.js';

export {
  OpenAIAdapter,
  toOpenAIContent,
  fromOpenAIContent,
  type OpenAIAdapterConfig,
} from './openai.js';

export {
  OpenAICompatibleAdapter,
  toOpenAIMessages,
  fromOpenAIMessage,
  type OpenAICompatibleAdapterConfig,
} from './openai-compatible.js';

export {
  OpenAICompletionsAdapter,
  type OpenAICompletionsAdapterConfig,
} from './openai-completions.js';

export {
  MockAdapter,
  createEchoAdapter,
  createCannedAdapter,
  type MockAdapterConfig,
} from './mock.js';

export {
  BedrockAdapter,
  type BedrockAdapterConfig,
} from './bedrock.js';

export {
  GeminiAdapter,
  toGeminiParts,
  fromGeminiParts,
  type GeminiAdapterConfig,
} from './gemini.js';

export {
  OpenAIResponsesAdapter,
  type OpenAIResponsesAdapterConfig,
} from './openai-responses.js';

export {
  OpenAIResponsesAPIAdapter,
  type OpenAIResponsesAPIAdapterConfig,
  type OpenAIResponsesAPIContentBlock,
  type OpenAIResponsesAPIProviderResponse,
  type OpenAIResponsesAPIRequest,
  type OpenAIResponsesAPIResponse,
  type OpenAIResponsesInputItem,
  type OpenAIResponsesOutputItem,
} from './openai-responses-api.js';

export type { CredentialContext, CredentialResolver, ResolvedCredential } from './credentials.js';
