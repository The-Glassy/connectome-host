import { unreportedUsage } from '../utils/usage.js';
import { assertMessagePrefillSupported } from './request-capabilities.js';

import type {
  ProviderAdapter,
  ProviderRequest,
  ProviderRequestOptions,
  ProviderResponse,
  StreamCallbacks,
  ContentBlock,
} from '../types/index.js';
import {
  MembraneError,
  invalidRequestError,
  abortError,
  errorFromHttpResponse,
  errorFromProviderStatus,
  isTypedAbortError,
  networkError,
  withRawRequest,
} from '../types/index.js';
import { errorFromThrown } from '../types/errors.js';
import { stripEmptyTextAfterPassthrough } from '../utils/empty-text.js';
import { createCombinedSignal, isDeadlineAbort, deadlineTimeoutError, assertTerminalEventObserved, toolUseInputFromText, toolUseInputFromValue, streamIndex, isEventObject, isToolCallBlock, isToolCallArgumentsDelta, progressOfAnthropicEvent } from './utils.js';
import {
  INTERLEAVED_THINKING_BETA,
  THINKING_BINDING_BETA,
  THINKING_DISPLAY_UPDATES_BETA,
  needsInterleavedThinkingBeta,
  readInputTransformations,
  readRefusalCategory,
  sendsBlockBinding,
  sendsDisplayUpdates,
  thinkingEnabled,
} from './anthropic.js';
import { anthropicWireMessages, blockBuiltFrom } from '../utils/anthropic-wire-blocks.js';

export interface BedrockAdapterConfig {
  /** AWS access key ID */
  accessKeyId?: string;

  /** AWS secret access key */
  secretAccessKey?: string;

  /** AWS region (defaults to AWS_REGION, then us-west-2) */
  region?: string;

  /** AWS session token (for temporary credentials) */
  sessionToken?: string;

  /** Default max tokens */
  defaultMaxTokens?: number;

  /** Anthropic API version, sent as the `anthropic_version` body field (defaults to bedrock-2023-05-31) */
  anthropicVersion?: string;

  /**
   * Endpoint override (no trailing slash), e.g. an inference gateway's leg.
   * Defaults to `https://bedrock-runtime.{region}.amazonaws.com`. When
   * pointing at a gateway, set accessKeyId to the gate token; the constructor
   * still requires a non-empty secretAccessKey.
   */
  baseURL?: string;
}

interface BedrockMessageRequest {
  anthropic_version: string;
  max_tokens: number;
  messages: Array<{
    role: 'user' | 'assistant';
    content: unknown;
  }>;
  system?: string | Array<{ type: 'text'; text: string; cache_control?: { type: 'ephemeral' } }>;
  temperature?: number;
  top_p?: number;
  top_k?: number;
  stop_sequences?: string[];
  tools?: unknown[];
  thinking?:
    | { type: 'enabled'; budget_tokens: number; display?: 'summarized' | 'omitted' | 'updates'; block_binding?: { prefix_mismatch_behavior: 'error' | 'drop_block' } }
    | { type: 'adaptive'; display?: 'summarized' | 'omitted' | 'updates'; block_binding?: { prefix_mismatch_behavior: 'error' | 'drop_block' } };
  /** Beta flags. On bedrock-runtime these ride in the body, not a header. */
  anthropic_beta?: string[];
}

interface BedrockMessageResponse {
  id: string;
  type: 'message';
  role: 'assistant';
  content: Array<{
    type: 'text' | 'tool_use' | 'thinking';
    text?: string;
    thinking?: string;
    signature?: string;
    id?: string;
    name?: string;
    input?: unknown;
    unparseableInput?: string;
  }>;
  model: string;
  stop_reason: 'end_turn' | 'max_tokens' | 'stop_sequence' | 'tool_use' | null;
  stop_sequence?: string | null;
  /**
   * With a refusal, its details, as AWS documents for a non-streamed body
   * (Claude Messages API on Bedrock): `category`, such as 'cyber', and an
   * explanation. AWS's page doesn't show it in a stream's events; the stream's
   * final message carries it when a message_delta did.
   */
  stop_details?: unknown;
  usage: {
    input_tokens: number;
    output_tokens: number;
    cache_creation_input_tokens?: number;
    cache_read_input_tokens?: number;
  };
  input_transformations?: unknown;
}

interface BedrockStreamEvent {
  type: string;
  index?: number;
  content_block?: {
    type: string;
    text?: string;
    thinking?: string;
    id?: string;
    name?: string;
    input?: unknown;
  };
  delta?: {
    type: string;
    text?: string;
    thinking?: string;
    partial_json?: string;
    stop_reason?: string;
    stop_sequence?: string;
    /** On a refusal's message_delta, if Bedrock passes it on. */
    stop_details?: unknown;
  };
  message?: BedrockMessageResponse;
  usage?: {
    input_tokens: number;
    output_tokens: number;
    cache_creation_input_tokens?: number | null;
    cache_read_input_tokens?: number | null;
  };
  /** On message_delta, after a server-side model fallback: the serving model's report. */
  input_transformations?: unknown;
}

/**
 * Bedrock accepts `cache_control: { type: 'ephemeral' }` but rejects the
 * direct-API `ttl` extension ("cache_control.ttl: Extra inputs are not
 * permitted"). Drop the ttl, keep the marker — the cache still works, at
 * Bedrock's fixed default TTL.
 */
function stripCacheTtl<T extends Record<string, any>>(block: T): T {
  if (block?.cache_control && typeof block.cache_control === 'object' && 'ttl' in block.cache_control) {
    const { ttl, ...cacheControl } = block.cache_control;
    return { ...block, cache_control: cacheControl };
  }
  return block;
}

async function hmacSha256(key: ArrayBuffer | Uint8Array, data: string): Promise<ArrayBuffer> {
  const cryptoKey = await crypto.subtle.importKey(
    'raw',
    key,
    { name: 'HMAC', hash: 'SHA-256' },
    false,
    ['sign']
  );
  return crypto.subtle.sign('HMAC', cryptoKey, new TextEncoder().encode(data));
}

async function sha256(data: string): Promise<string> {
  const hash = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(data));
  return Array.from(new Uint8Array(hash))
    .map(b => b.toString(16).padStart(2, '0'))
    .join('');
}

async function getSignatureKey(
  secretKey: string,
  dateStamp: string,
  region: string,
  service: string
): Promise<ArrayBuffer> {
  const kDate = await hmacSha256(new TextEncoder().encode('AWS4' + secretKey), dateStamp);
  const kRegion = await hmacSha256(kDate, region);
  const kService = await hmacSha256(kRegion, service);
  return hmacSha256(kService, 'aws4_request');
}

function getAmzDate(): { amzDate: string; dateStamp: string } {
  const now = new Date();
  const amzDate = now.toISOString().replace(/[:-]|\.\d{3}/g, '');
  const dateStamp = amzDate.slice(0, 8);
  return { amzDate, dateStamp };
}

async function signRequest(
  method: string,
  url: URL,
  headers: Record<string, string>,
  body: string,
  accessKeyId: string,
  secretAccessKey: string,
  sessionToken: string | undefined,
  region: string,
  service: string
): Promise<Record<string, string>> {
  const { amzDate, dateStamp } = getAmzDate();

  const signedHeaders: Record<string, string> = {
    ...headers,
    host: url.host,
    'x-amz-date': amzDate,
  };

  if (sessionToken) {
    signedHeaders['x-amz-security-token'] = sessionToken;
  }

  const sortedHeaderKeys = Object.keys(signedHeaders).sort();
  const canonicalHeaders = sortedHeaderKeys
    .map(k => `${k.toLowerCase()}:${signedHeaders[k]?.trim()}`)
    .join('\n') + '\n';
  const signedHeadersList = sortedHeaderKeys.map(k => k.toLowerCase()).join(';');
  const payloadHash = await sha256(body);

  // URI-encode path components for canonical request (AWS SigV4 requirement)
  // AWS requires double-encoding: %3A in the URL becomes %253A in the canonical request
  // We encode each segment without decoding first to achieve double-encoding
  const canonicalUri = url.pathname
    .split('/')
    .map(segment => encodeURIComponent(segment))
    .join('/');

  const canonicalRequest = [
    method,
    canonicalUri,
    url.search.slice(1),
    canonicalHeaders,
    signedHeadersList,
    payloadHash,
  ].join('\n');

  const algorithm = 'AWS4-HMAC-SHA256';
  const credentialScope = `${dateStamp}/${region}/${service}/aws4_request`;
  const stringToSign = [
    algorithm,
    amzDate,
    credentialScope,
    await sha256(canonicalRequest),
  ].join('\n');

  const signingKey = await getSignatureKey(secretAccessKey, dateStamp, region, service);
  const signatureBuffer = await hmacSha256(signingKey, stringToSign);
  const signature = Array.from(new Uint8Array(signatureBuffer))
    .map(b => b.toString(16).padStart(2, '0'))
    .join('');

  const authorization = `${algorithm} Credential=${accessKeyId}/${credentialScope}, SignedHeaders=${signedHeadersList}, Signature=${signature}`;

  return {
    ...signedHeaders,
    authorization,
  };
}

const AWS_EVENTSTREAM_STRING_HEADER_TYPE = 7;

export class BedrockAdapter implements ProviderAdapter {
  readonly name = 'bedrock';
  /**
   * Reports what it leaves out or replaces: media with no source object, a
   * thinking block with no signature, an image whose data the API doesn't
   * accept, which goes as the placeholder, a block in a tool_result's content
   * other than text and a base64 or URL image, whitespace-only text, an
   * error tool_result's image, which goes as a note, an error tool_result
   * that would go with no content, which carries a note, and a passthrough
   * `messages` that replaces the built ones. Otherwise it carries message
   * content as built, each block at the top of a message built from the
   * API's fields for its type, in the wire's spellings and without a cache
   * ttl.
   */
  readonly reportsContentAlterations = true;
  readonly cacheReceiptBasis = 'wire-request' as const;

  /**
   * Bedrock serves Anthropic models over the Anthropic Messages payload shape
   * and this adapter reads Anthropic's own field names
   * (`cache_read_input_tokens` / `cache_creation_input_tokens`), so it inherits
   * the Anthropic API's convention; not measured against Bedrock directly.
   */
  readonly usageCacheConvention = 'cache-excluded' as const;

  private accessKeyId: string;
  private secretAccessKey: string;
  private sessionToken?: string;
  private region: string;
  private defaultMaxTokens: number;
  private anthropicVersion: string;
  private baseURL?: string;

  constructor(config: BedrockAdapterConfig = {}) {
    this.accessKeyId = config.accessKeyId ?? process.env.AWS_ACCESS_KEY_ID ?? '';
    this.secretAccessKey = config.secretAccessKey ?? process.env.AWS_SECRET_ACCESS_KEY ?? '';
    this.sessionToken = config.sessionToken ?? process.env.AWS_SESSION_TOKEN;
    this.region = config.region ?? process.env.AWS_REGION ?? 'us-west-2';
    this.defaultMaxTokens = config.defaultMaxTokens ?? 4096;
    this.anthropicVersion = config.anthropicVersion ?? 'bedrock-2023-05-31';
    this.baseURL = config.baseURL?.replace(/\/$/, '');

    if (!this.accessKeyId || !this.secretAccessKey) {
      throw new Error('AWS credentials required: accessKeyId and secretAccessKey');
    }
  }

  supportsModel(modelId: string): boolean {
    return modelId.includes('claude') || modelId.startsWith('anthropic.');
  }

  /**
   * Claude 4-era models on Bedrock reject on-demand invocation of the
   * direct id ("Invocation ... with on-demand throughput isn't supported")
   * and require the cross-region inference-profile form.
   */
  private inferenceProfilePrefix(): string {
    if (this.region.startsWith('eu-')) return 'eu.';
    if (this.region.startsWith('ap-')) return 'apac.';
    return 'us.';
  }

  private toBedrockModelId(modelId: string): string {
    if (modelId.startsWith('bedrock:')) {
      modelId = modelId.slice('bedrock:'.length);
    }

    if (modelId.startsWith('anthropic.') || /^[a-z]{2,6}\.anthropic\./.test(modelId)) {
      return modelId;
    }

    const profile = this.inferenceProfilePrefix();

    // 3.x models predate inference profiles and keep the direct id; 4-era
    // models take the profile form, since the direct id no longer invokes.
    const modelMap: Record<string, string> = {
      'claude-3-5-sonnet-20241022': 'anthropic.claude-3-5-sonnet-20241022-v2:0',
      'claude-3-5-sonnet-latest': 'anthropic.claude-3-5-sonnet-20241022-v2:0',
      'claude-3-5-haiku-20241022': 'anthropic.claude-3-5-haiku-20241022-v1:0',
      'claude-3-5-haiku-latest': 'anthropic.claude-3-5-haiku-20241022-v1:0',
      'claude-3-opus-20240229': 'anthropic.claude-3-opus-20240229-v1:0',
      'claude-3-sonnet-20240229': 'anthropic.claude-3-sonnet-20240229-v1:0',
      'claude-3-haiku-20240307': 'anthropic.claude-3-haiku-20240307-v1:0',
      'claude-sonnet-4-20250514': `${profile}anthropic.claude-sonnet-4-20250514-v1:0`,
      'claude-opus-4-20250514': `${profile}anthropic.claude-opus-4-20250514-v1:0`,
      'claude-haiku-4-5-20251001': `${profile}anthropic.claude-haiku-4-5-20251001-v1:0`,
    };

    return modelMap[modelId] ?? `${profile}anthropic.${modelId}-v1:0`;
  }

  async complete(
    request: ProviderRequest,
    options?: ProviderRequestOptions
  ): Promise<ProviderResponse> {
    const bedrockModelId = this.toBedrockModelId(request.model);
    const bedrockRequest = this.buildRequest(request, bedrockModelId, options?.onContentAltered);
    const fullRequest = { modelId: bedrockModelId, ...bedrockRequest };
    assertMessagePrefillSupported(bedrockModelId, fullRequest.messages, options, this.name, fullRequest);
    options?.onRequest?.(fullRequest);
    options?.onSend?.({ maxTokens: fullRequest.max_tokens });

    const { signal: combinedSignal, cleanup } = createCombinedSignal(options?.signal, options?.timeoutMs);
    try {
      const response = await this.invokeModel(bedrockModelId, bedrockRequest, combinedSignal, fullRequest);
      return this.parseResponse(response, fullRequest);
    } catch (error) {
      throw this.handleError(error, fullRequest);
    } finally {
      cleanup?.();
    }
  }

  async stream(
    request: ProviderRequest,
    callbacks: StreamCallbacks,
    options?: ProviderRequestOptions
  ): Promise<ProviderResponse> {
    const bedrockModelId = this.toBedrockModelId(request.model);
    const bedrockRequest = this.buildRequest(request, bedrockModelId, options?.onContentAltered);
    const fullRequest = { modelId: bedrockModelId, ...bedrockRequest, stream: true };
    assertMessagePrefillSupported(bedrockModelId, fullRequest.messages, options, this.name, fullRequest);
    options?.onRequest?.(fullRequest);
    options?.onSend?.({ maxTokens: fullRequest.max_tokens, reportsContent: true });

    const { signal: combinedSignal, cleanup } = createCombinedSignal(options?.signal, options?.timeoutMs);
    try {
      return await this.invokeModelWithStream(bedrockModelId, bedrockRequest, callbacks, combinedSignal, fullRequest, options?.onProgress);
    } catch (error) {
      throw this.handleError(error, fullRequest);
    } finally {
      cleanup?.();
    }
  }

  private buildRequest(request: ProviderRequest, bedrockModelId?: string, onContentAltered?: (block?: unknown) => void): BedrockMessageRequest {
    const sanitizedMessages = anthropicWireMessages(request.messages, { onContentAltered, finish: stripCacheTtl, imageMediaTypeLast: true });

    const params: BedrockMessageRequest = {
      anthropic_version: this.anthropicVersion,
      max_tokens: request.maxTokens || this.defaultMaxTokens,
      messages: sanitizedMessages as BedrockMessageRequest['messages'],
    };

    // Claude 3 Sonnet (20240229) on Bedrock intermittently rejects the array
    // content-block form for system prompts via APAC cross-region inference
    // ("system: Input should be a valid string").
    if (request.system) {
      const needsFlatten = bedrockModelId?.includes('claude-3-sonnet-20240229') ?? false;
      if (needsFlatten && Array.isArray(request.system)) {
        const blocks = request.system as Array<{ type: string; text: string }>;
        params.system = blocks.map(b => b.text).join('\n\n');
      } else if (Array.isArray(request.system)) {
        params.system = (request.system as Array<Record<string, any>>).map(
          b => stripCacheTtl(b)
        ) as BedrockMessageRequest['system'];
      } else {
        params.system = request.system as BedrockMessageRequest['system'];
      }
    }

    if (request.temperature !== undefined) {
      params.temperature = request.temperature;
    }

    // Anthropic API (via Bedrock) rejects requests with both temperature and top_p set.
    if (request.topP !== undefined && request.temperature === undefined) {
      params.top_p = request.topP;
    }

    if (request.topK !== undefined) {
      params.top_k = request.topK;
    }

    if (request.stopSequences && request.stopSequences.length > 0) {
      params.stop_sequences = request.stopSequences;
    }

    if (request.tools && request.tools.length > 0) {
      params.tools = (request.tools as Array<Record<string, any>>).map(t => stripCacheTtl(t));
    }

    if ((request as any).thinking) {
      params.thinking = (request as any).thinking;
    }

    if (request.extra) {
      const { normalizedMessages, prompt, ...rest } = request.extra as Record<string, unknown>;
      if (rest.messages !== undefined) onContentAltered?.();
      Object.assign(params, rest);
    }

    const consumerBetas: unknown = params.anthropic_beta;
    if (consumerBetas !== undefined && (
      !Array.isArray(consumerBetas) ||
      [...consumerBetas].some(beta => typeof beta !== 'string')
    )) {
      throw invalidRequestError('Bedrock anthropic_beta must be an array of strings.');
    }

    // bedrock-runtime takes betas in the `anthropic_beta` body field, not an
    // HTTP header, and legacy 3.x models refuse unknown beta flags.
    if (thinkingEnabled(request) && needsInterleavedThinkingBeta(request.model)) {
      const existing = params.anthropic_beta ?? [];
      params.anthropic_beta = [...new Set([...existing, INTERLEAVED_THINKING_BETA])];
    }
    // Thinking-binding controls need their beta, the same way.
    if (sendsBlockBinding(params)) {
      const existing = params.anthropic_beta ?? [];
      params.anthropic_beta = [...new Set([...existing, THINKING_BINDING_BETA])];
    }
    // So does `display: 'updates'` (progress notes between tool calls).
    if (sendsDisplayUpdates(params)) {
      const existing = params.anthropic_beta ?? [];
      params.anthropic_beta = [...new Set([...existing, THINKING_DISPLAY_UPDATES_BETA])];
    }

    stripEmptyTextAfterPassthrough(params, onContentAltered ? (dropped) => onContentAltered(blockBuiltFrom(dropped)) : undefined);
    return params;
  }

  private async invokeModel(
    modelId: string,
    request: BedrockMessageRequest,
    signal: AbortSignal | undefined,
    rawRequest: unknown
  ): Promise<BedrockMessageResponse> {
    const url = new URL(
      `${this.baseURL ?? `https://bedrock-runtime.${this.region}.amazonaws.com`}/model/${encodeURIComponent(modelId)}/invoke`
    );

    const body = JSON.stringify(request);
    const headers: Record<string, string> = {
      'content-type': 'application/json',
      accept: 'application/json',
    };

    const signedHeaders = await signRequest(
      'POST',
      url,
      headers,
      body,
      this.accessKeyId,
      this.secretAccessKey,
      this.sessionToken,
      this.region,
      'bedrock'
    );

    const response = await fetch(url.toString(), {
      method: 'POST',
      headers: signedHeaders,
      body,
      signal,
    });

    if (!response.ok) {
      throw errorFromHttpResponse(this.name, response, await response.text(), rawRequest);
    }

    return response.json() as Promise<BedrockMessageResponse>;
  }

  private async invokeModelWithStream(
    modelId: string,
    request: BedrockMessageRequest,
    callbacks: StreamCallbacks,
    signal: AbortSignal | undefined,
    rawRequest: unknown,
    onProgress?: ProviderRequestOptions['onProgress'],
  ): Promise<ProviderResponse> {
    const url = new URL(
      `${this.baseURL ?? `https://bedrock-runtime.${this.region}.amazonaws.com`}/model/${encodeURIComponent(modelId)}/invoke-with-response-stream`
    );

    const body = JSON.stringify(request);
    const summarized = request.thinking?.display === 'summarized';
    const headers: Record<string, string> = {
      'content-type': 'application/json',
      accept: 'application/vnd.amazon.eventstream',
    };

    const signedHeaders = await signRequest(
      'POST',
      url,
      headers,
      body,
      this.accessKeyId,
      this.secretAccessKey,
      this.sessionToken,
      this.region,
      'bedrock'
    );

    const response = await fetch(url.toString(), {
      method: 'POST',
      headers: signedHeaders,
      body,
      signal,
    });

    if (!response.ok) {
      throw errorFromHttpResponse(this.name, response, await response.text(), rawRequest);
    }

    const contentBlocks: Array<{ type: string; text?: string; thinking?: string; signature?: string }> = [];
    // A tool call truncated by max_tokens never gets a content_block_stop.
    const stoppedBlocks = new Set<number>();
    let currentBlockIndex = -1;
    // Block events come in the API's order: a start while no block is open,
    // at the next index, then that block's deltas (a tool call's carry only
    // its arguments) and its stop.
    let blockOrderBroken = false;
    let skippedStart = false;
    const blockOpen = (): boolean =>
      currentBlockIndex >= 0 && contentBlocks[currentBlockIndex] !== undefined && !stoppedBlocks.has(currentBlockIndex);
    const breakBlockOrder = (what: string): void => {
      if (blockOrderBroken) return;
      blockOrderBroken = true;
      console.warn('[membrane:bedrock] Skipping malformed stream event:', `${what}; no later block event is applied, and every tool_use block in the response is marked`);
    };
    let finalMessage: BedrockMessageResponse | undefined;
    let inputTokens = 0;
    let outputTokens = 0;
    let inputReported = false;
    let outputReported = false;
    let cacheCreationTokens: number | undefined;
    let cacheReadTokens: number | undefined;
    let stopReason: string | undefined;
    // AWS's page doesn't show a refusal's details in the stream, so they may never come.
    let stopDetails: unknown;
    let sawTerminalEvent = false;
    let stopSequence: string | undefined;
    let fullText = '';
    // Final in message_start, replaced by a message_delta's after a fallback.
    let inputTransformations: unknown;

    const reader = response.body?.getReader();
    if (!reader) {
      throw new Error('No response body');
    }

    let buffer = new Uint8Array(0);

    try {
      read: while (true) {
        const { done, value } = await reader.read();
        if (done) break;

        const newBuffer = new Uint8Array(buffer.length + value.length);
        newBuffer.set(buffer);
        newBuffer.set(value, buffer.length);
        buffer = newBuffer;

        while (buffer.length >= 16) {
          // AWS event stream format:
          // 4 bytes: total byte length (big-endian)
          // 4 bytes: headers length (big-endian)
          // 4 bytes: prelude CRC
          // headers
          // payload
          // 4 bytes: message CRC
          const view = new DataView(buffer.buffer, buffer.byteOffset, buffer.byteLength);
          const totalLength = view.getUint32(0, false);
          const headersLength = view.getUint32(4, false);

          if (buffer.length < totalLength) {
            break;
          }

          const payloadStart = 12 + headersLength;
          const payloadEnd = totalLength - 4;
          const payloadBytes = buffer.slice(payloadStart, payloadEnd);

          let eventType = '';
          let exceptionType = '';
          let headerOffset = 12;
          const headerEnd = 12 + headersLength;
          while (headerOffset < headerEnd) {
            const nameLength = buffer[headerOffset]!;
            headerOffset += 1;
            const name = new TextDecoder().decode(buffer.slice(headerOffset, headerOffset + nameLength));
            headerOffset += nameLength;
            const valueType = buffer[headerOffset]!;
            headerOffset += 1;

            if (valueType === AWS_EVENTSTREAM_STRING_HEADER_TYPE) {
              const valueLength = new DataView(buffer.buffer, buffer.byteOffset + headerOffset, 2).getUint16(0, false);
              headerOffset += 2;
              const value = new TextDecoder().decode(buffer.slice(headerOffset, headerOffset + valueLength));
              headerOffset += valueLength;

              if (name === ':event-type') {
                eventType = value;
              } else if (name === ':exception-type') {
                exceptionType = value;
              }
            } else {
              break;
            }
          }

          if (exceptionType) {
            let errorMessage = exceptionType;
            try {
              const exPayload = JSON.parse(new TextDecoder().decode(payloadBytes));
              errorMessage = exPayload.message || exPayload.Message || exceptionType;
            } catch {
            }
            throw new BedrockError(
              BEDROCK_STREAM_EXCEPTION_STATUS.get(exceptionType.toLowerCase()) ?? 500,
              `Bedrock stream error (${exceptionType}): ${errorMessage}`,
              exceptionType,
              errorMessage === exceptionType ? undefined : { message: errorMessage },
            );
          }

          if (eventType === 'chunk' && payloadBytes.length > 0) {
            let decoded: unknown;
            let skipped: unknown = 'no event in its bytes';
            try {
              const payloadJson = JSON.parse(new TextDecoder().decode(payloadBytes));
              if (payloadJson.bytes) {
                // Decode base64 → bytes → UTF-8 string (atob returns Latin-1, mangling multi-byte emoji)
                const binaryStr = atob(payloadJson.bytes);
                const bytes = new Uint8Array(binaryStr.length);
                for (let i = 0; i < binaryStr.length; i++) {
                  bytes[i] = binaryStr.charCodeAt(i);
                }
                decoded = JSON.parse(new TextDecoder().decode(bytes));
                skipped = 'bytes that decode to no object';
              }
            } catch (e) {
              skipped = e;
            }
            const eventData = isEventObject(decoded) ? decoded as BedrockStreamEvent : undefined;
            if (eventData === undefined) console.warn('[membrane:bedrock] Skipping malformed stream event:', skipped);

            if (eventData !== undefined) {
              if ((eventData as { type?: string }).type !== 'ping') onProgress?.(progressOfAnthropicEvent(eventData, summarized));

              if (eventData.type === 'error') {
                const streamError = (eventData as any).error;
                throw new BedrockError(
                  undefined,
                  `Bedrock stream error: ${streamError?.message || JSON.stringify(eventData)}`,
                  typeof streamError?.type === 'string' ? streamError.type : undefined,
                  eventData,
                );
              }

              if (eventData.type === 'message_start' && eventData.message) {
                inputTransformations = eventData.message.input_transformations;
                const startUsage = eventData.message.usage;
                inputTokens = startUsage?.input_tokens ?? 0;
                inputReported = typeof startUsage?.input_tokens === 'number';
                if (startUsage?.cache_creation_input_tokens != null) {
                  cacheCreationTokens = startUsage.cache_creation_input_tokens;
                }
                if (startUsage?.cache_read_input_tokens != null) {
                  cacheReadTokens = startUsage.cache_read_input_tokens;
                }
              } else if (eventData.type === 'content_block_start') {
                const startIndex = streamIndex(eventData.index);
                const startBlock: unknown = eventData.content_block;
                if (blockOrderBroken || blockOpen() || (startIndex !== undefined && startIndex < contentBlocks.length)) {
                  breakBlockOrder('a content_block_start while a block is open or at an index below the next');
                } else if (startIndex === undefined || startBlock === null || typeof startBlock !== 'object' || Array.isArray(startBlock)) {
                  console.warn('[membrane:bedrock] Skipping malformed stream event:', 'a content_block_start that names no block');
                  currentBlockIndex = -1;
                  skippedStart = true;
                } else {
                  skippedStart = false;
                  currentBlockIndex = startIndex;
                  contentBlocks[currentBlockIndex] = startBlock as { type: string };
                  callbacks.onContentBlock?.(currentBlockIndex, startBlock);
                }
              } else if (eventData.type === 'content_block_delta') {
                const deltaIndex = streamIndex((eventData as { index?: unknown }).index, currentBlockIndex);
                if (blockOrderBroken || (!skippedStart && (!blockOpen() || deltaIndex !== currentBlockIndex))) {
                  breakBlockOrder('a content_block_delta for a block other than the open one');
                } else if (isToolCallBlock(contentBlocks[currentBlockIndex]) && !isToolCallArgumentsDelta(eventData.delta)) {
                  breakBlockOrder('a content_block_delta that a tool call can\'t take');
                } else if (eventData.delta?.type === 'text_delta' && eventData.delta.text) {
                  fullText += eventData.delta.text;
                  callbacks.onChunk(eventData.delta.text);
                  if (contentBlocks[currentBlockIndex]) {
                    contentBlocks[currentBlockIndex]!.text = (contentBlocks[currentBlockIndex]!.text ?? '') + eventData.delta.text;
                  }
                } else if (eventData.delta?.type === 'thinking_delta' && eventData.delta.thinking) {
                  callbacks.onChunk(eventData.delta.thinking);
                  if (contentBlocks[currentBlockIndex]) {
                    contentBlocks[currentBlockIndex]!.thinking = (contentBlocks[currentBlockIndex]!.thinking ?? '') + eventData.delta.thinking;
                  }
                } else if (eventData.delta?.type === 'signature_delta' && (eventData.delta as any).signature) {
                  if (contentBlocks[currentBlockIndex]) {
                    contentBlocks[currentBlockIndex]!.signature = (contentBlocks[currentBlockIndex]!.signature ?? '') + (eventData.delta as any).signature;
                    callbacks.onThinkingSignature?.(currentBlockIndex, contentBlocks[currentBlockIndex]!.signature!);
                  }
                } else if (eventData.delta?.type === 'input_json_delta' && (eventData.delta as any).partial_json !== undefined) {
                  const blk = contentBlocks[currentBlockIndex] as (typeof contentBlocks)[number] & { partialJson?: string };
                  if (blk) {
                    blk.partialJson = (blk.partialJson ?? '') + (eventData.delta as any).partial_json;
                  }
                }
              } else if (eventData.type === 'content_block_stop') {
                const blockIdx = streamIndex((eventData as { index?: unknown }).index, currentBlockIndex);
                if (skippedStart) {
                } else if (blockOrderBroken || !blockOpen() || blockIdx !== currentBlockIndex) {
                  breakBlockOrder('a content_block_stop for a block other than the open one');
                } else {
                  stoppedBlocks.add(blockIdx);
                  const stoppedBlk = contentBlocks[blockIdx] as ((typeof contentBlocks)[number] & { partialJson?: string; input?: unknown; unparseableInput?: string }) | undefined;
                  if (stoppedBlk?.type === 'tool_use' && stoppedBlk.partialJson !== undefined) {
                    const parsed = toolUseInputFromText(stoppedBlk.partialJson);
                    if (parsed.unparseableInput === undefined) stoppedBlk.input = parsed.input;
                    else stoppedBlk.unparseableInput = parsed.unparseableInput;
                  }
                  callbacks.onContentBlock?.(blockIdx, contentBlocks[blockIdx]);
                }
              } else if (eventData.type === 'message_delta') {
                sawTerminalEvent = true;
                if (Array.isArray(eventData.input_transformations)) inputTransformations = eventData.input_transformations;
                if (eventData.usage) {
                  outputTokens = eventData.usage.output_tokens;
                  if (typeof eventData.usage.output_tokens === 'number') outputReported = true;
                  // message_delta carries cumulative cache metrics.
                  if (eventData.usage.cache_creation_input_tokens != null) {
                    cacheCreationTokens = eventData.usage.cache_creation_input_tokens;
                  }
                  if (eventData.usage.cache_read_input_tokens != null) {
                    cacheReadTokens = eventData.usage.cache_read_input_tokens;
                  }
                }
                if (eventData.delta?.stop_reason) {
                  stopReason = eventData.delta.stop_reason;
                }
                if (eventData.delta?.stop_details !== undefined) stopDetails = eventData.delta.stop_details;
                if (eventData.delta?.stop_sequence) {
                  stopSequence = eventData.delta.stop_sequence;
                }
              }
            }
          }

          buffer = buffer.slice(totalLength);
          if (sawTerminalEvent) break read;
        }
      }
    } finally {
      // An unread body holds the connection: cancel it, so the provider stops
      // sending. After a full read it does nothing.
      void reader.cancel().catch(() => {});
      reader.releaseLock();
    }

    if (contentBlocks.length === 0 && inputTokens === 0 && outputTokens === 0) {
      throw new BedrockError(
        500,
        'Bedrock returned empty response: no content blocks, 0 input/output tokens. This may indicate a transient service issue.'
      );
    }

    assertTerminalEventObserved(sawTerminalEvent, 'Bedrock', { modelId, ...request });

    let slot = 0;
    while (slot < contentBlocks.length && slot in contentBlocks) slot++;
    if (slot < contentBlocks.length) {
      throw networkError(
        `Bedrock stream lost content block ${slot}: no block start placed it`,
        undefined,
        { modelId, ...request }
      );
    }

    finalMessage = {
      id: 'msg_stream',
      type: 'message',
      role: 'assistant',
      content: contentBlocks.map((b, blockIdx) => {
        if (b.type === 'thinking') {
          return { type: 'thinking' as const, thinking: b.thinking ?? '', signature: b.signature };
        }
        if (b.type === 'redacted_thinking') {
          // Pass through verbatim — carries the encrypted `data` payload
          return { ...b } as unknown as { type: 'text'; text?: string };
        }
        if (b.type === 'tool_use') {
          const tb = b as { type: string; id?: string; name?: string; input?: unknown; partialJson?: string; unparseableInput?: string };
          let unparseableInput = stoppedBlocks.has(blockIdx) ? tb.unparseableInput : (tb.partialJson ?? '');
          let input = tb.input ?? {};
          if (blockOrderBroken && unparseableInput === undefined) {
            unparseableInput = JSON.stringify(input);
            input = {};
          }
          return {
            type: 'tool_use', id: tb.id, name: tb.name, input,
            ...(unparseableInput !== undefined ? { unparseableInput } : {}),
          } as unknown as { type: 'text'; text?: string };
        }
        return { type: b.type as 'text', text: b.text };
      }),
      model: modelId,
      stop_reason: (stopReason ?? 'end_turn') as BedrockMessageResponse['stop_reason'],
      stop_sequence: stopSequence ?? null,
      ...(stopDetails !== undefined ? { stop_details: stopDetails } : {}),
      usage: {
        input_tokens: inputTokens,
        output_tokens: outputTokens,
        ...(cacheCreationTokens != null ? { cache_creation_input_tokens: cacheCreationTokens } : {}),
        ...(cacheReadTokens != null ? { cache_read_input_tokens: cacheReadTokens } : {}),
      },
      ...(Array.isArray(inputTransformations) ? { input_transformations: inputTransformations } : {}),
    };

    const parsed = this.parseResponse(finalMessage, rawRequest);
    const { unreportedUsage: _fromSynthetic, ...rest } = parsed;
    return {
      ...rest,
      ...unreportedUsage(inputReported ? inputTokens : undefined, outputReported ? outputTokens : undefined),
      providerStopReason: stopReason,
    };
  }

  private parseResponse(response: BedrockMessageResponse, rawRequest: unknown): ProviderResponse {
    const content: ContentBlock[] = [];

    for (const block of response.content) {
      if (block.type === 'text' && block.text) {
        content.push({ type: 'text', text: block.text });
      } else if (block.type === 'tool_use' && block.id && block.name) {
        content.push({
          type: 'tool_use',
          id: block.id,
          name: block.name,
          ...toolUseInputFromValue(block.input),
          ...(block.unparseableInput !== undefined ? { unparseableInput: block.unparseableInput } : {}),
        });
      } else if (block.type === 'thinking') {
        // Signature-only thinking blocks (display:'omitted') have an empty
        // thinking field but must still be preserved for round-tripping.
        content.push({
          type: 'thinking',
          thinking: block.thinking ?? '',
          ...(block.signature ? { signature: block.signature } : {}),
        });
      } else if ((block as any).type === 'redacted_thinking') {
        // Pass through verbatim — carries the encrypted `data` payload
        content.push({ ...(block as any) } as ContentBlock);
      }
    }

    return {
      content,
      stopReason: response.stop_reason ?? 'end_turn',
      providerStopReason: response.stop_reason ?? undefined,
      // A non-streamed body carries stop_details, as AWS documents. The
      // stream's final message carries them when a message_delta did, which
      // AWS's page doesn't show.
      ...readRefusalCategory(response.stop_reason, response.stop_details),
      stopSequence: response.stop_sequence ?? undefined,
      usage: {
        inputTokens: response.usage.input_tokens,
        outputTokens: response.usage.output_tokens,
        cacheCreationTokens: response.usage.cache_creation_input_tokens,
        cacheReadTokens: response.usage.cache_read_input_tokens,
      },
      ...unreportedUsage(response.usage?.input_tokens, response.usage?.output_tokens),
      ...readInputTransformations(response.input_transformations, (rawRequest as { messages?: unknown } | undefined)?.messages),
      model: response.model,
      rawRequest,
      raw: response,
    };
  }

  private handleError(error: unknown, rawRequest?: unknown): MembraneError {
    if (isDeadlineAbort(error)) return deadlineTimeoutError(error, rawRequest);
    if (error instanceof MembraneError) return withRawRequest(error, rawRequest);
    if (isTypedAbortError(error)) return abortError(undefined, rawRequest);

    if (error instanceof BedrockError) {
      return errorFromProviderStatus({
        provider: this.name,
        status: error.status,
        fallbackStatus: 500,
        code: error.code,
        body: error.message,
        message: error.message,
        rawError: error,
        rawRequest,
      });
    }

    return errorFromThrown(error, rawRequest);
  }
}

class BedrockError extends Error {
  constructor(
    public status: number | undefined,
    message: string,
    public code?: string,
    public error?: unknown,
  ) {
    super(message);
    this.name = 'BedrockError';
  }
}

/**
 * The status each exception Bedrock sends inside a response stream implies:
 * the HTTP status AWS documents for the same exception. AWS documents
 * modelStreamErrorException as a 424 and asks for a retry, and a 424 would
 * read here as a bad request, so it stays a retryable 500. A type not listed
 * is a 500 too, as every non-throttling exception was.
 */
const BEDROCK_STREAM_EXCEPTION_STATUS = new Map<string, number>([
  ['validationexception', 400],
  ['modeltimeoutexception', 408],
  ['throttlingexception', 429],
  ['internalserverexception', 500],
  ['modelstreamerrorexception', 500],
  ['serviceunavailableexception', 503],
]);
