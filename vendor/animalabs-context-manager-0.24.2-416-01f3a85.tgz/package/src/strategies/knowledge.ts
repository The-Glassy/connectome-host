import type {
  StoredMessage,
  MessageStoreView,
  KnowledgeConfig,
  KnowledgeOptions,
  SummaryEntry,
  SummaryLevel,
  PhaseType,
} from '../types/index.js';
import { AutobiographicalStrategy, type Chunk } from './autobiographical.js';
import type { ConfigLayer } from '../config-provenance.js';
import { systemChangePositions } from '../system-changes.js';

const DEFAULT_RESEARCH_PREFIXES = ['mcpl:', 'zulip:'];
const DEFAULT_SUBAGENT_PREFIXES = ['subagent:'];
const DEFAULT_LESSON_NAMES = ['lessons:create', 'lessons:update'];

/**
 * Domain-aware compression strategy for knowledge extraction workflows.
 *
 * Builds on AutobiographicalStrategy's hierarchical pyramid (L1/L2/L3)
 * but changes three things:
 * 1. Semantic chunking — chunks at phase transitions instead of fixed token counts
 * 2. Phase-aware compression — different prompts per phase type
 * 3. Asymmetric budget — caps research, prioritizes synthesis in L1 selection
 *
 * Also adds [LEAD] tracking: unresolved questions/leads are flagged in summaries
 * and preserved across compression levels.
 */
export class KnowledgeStrategy extends AutobiographicalStrategy {
  readonly name = 'knowledge' as const;

  private knowledgeConfig: KnowledgeConfig;

  constructor(config: KnowledgeOptions = {}) {
    super(config);
    // Merge knowledge-specific fields onto the base config so all KnowledgeConfig
    // fields are actually present (super() only stores AutobiographicalConfig fields).
    this.knowledgeConfig = { ...this.config, ...config } as KnowledgeConfig;
  }

  /**
   * Hierarchical mode is forced: the phase-aware pyramid is what this strategy
   * IS, and a caller cannot switch it off. It is enforced as its own layer
   * rather than folded into the caller's — the effective value is the same
   * `true` either way, but the provenance map now says who really chose it.
   */
  protected enforcedConfigLayer(): ConfigLayer | null {
    return { source: 'knowledge-enforced', values: { hierarchical: true } };
  }

  // ============================================================================
  // Override: Semantic chunking
  // ============================================================================

  /**
   * KnowledgeStrategy keeps the legacy recompute-every-rebuild chunker:
   * its chunk boundaries are semantic (phase transitions), recomputed from
   * message content, and its stores are offline mining artifacts — the
   * restart-duplication failure mode that chunk persistence fixes does not
   * apply, and persisted token-sum records would fight the phase chunker.
   */
  protected get chunkPersistenceEnabled(): boolean {
    return false;
  }

  protected heldBackChunks(): Set<number> {
    return new Set();
  }

  protected rebuildChunks(store: MessageStoreView): void {
    const messagesToChunk = this.getCompressibleMessages(store);
    const all = store.getAll();
    const position = this.positionIndex(all);
    const changes = systemChangePositions(all);
    // The walk below is in store order, so one cursor finds the changes
    // stored between each message and the one before it.
    let nextChange = 0;

    // Preserve existing compressed chunks
    const existingCompressed = new Map<string, Chunk>();
    for (const chunk of this.chunks) {
      if (chunk.compressed) {
        existingCompressed.set(this.chunkKey(chunk), chunk);
      }
    }
    // A chunk holds the messages of one summary, or of none, but for a call's
    // result: it closes where the summary covering the walk's messages
    // changes, except between a call and its result (below). The walk otherwise
    // decides boundaries afresh, so once a message that closed a chunk is
    // removed (a consolidation removes its system changes), a chunk could run
    // into or across a summary's span; the overlap guard refuses to compress
    // such a chunk for good, and its messages go out raw beside the summary
    // that already covers some of them. Where the chunks already match the
    // summaries, the walk closes there anyway. An L2's sources are summaries,
    // not messages.
    const coveredBy = new Map<string, string>();
    for (const s of this.summaries) {
      if (s.level === 1) for (const id of s.sourceIds) coveredBy.set(id, s.id);
    }

    this.resetChunks();

    let currentChunk: StoredMessage[] = [];
    let currentTokens = 0;
    let currentPhase: PhaseType | null = null;
    let lastToolPhase: PhaseType = 'synthesis';
    let chunkFilteredStart = 0;
    const closeAt = (end: number): void => {
      const chunk = this.createChunk(
        this.chunks.length,
        chunkFilteredStart,
        end,
        currentChunk,
        currentTokens,
        existingCompressed
      );
      chunk.phaseType = currentPhase!;
      this.chunks.push(chunk);
      if (!chunk.compressed) this.compressionQueue.push(chunk.index);

      currentChunk = [];
      currentTokens = 0;
      chunkFilteredStart = end;
    };

    for (let i = 0; i < messagesToChunk.length; i++) {
      const msg = messagesToChunk[i];
      const previous = currentChunk[currentChunk.length - 1];
      let changeBefore = false;
      const at = position.get(msg.id)!;
      while (nextChange < changes.length && changes[nextChange]! < at) {
        changeBefore = true;
        nextChange++;
      }
      // Not between a call and its result: closing there would leave the
      // result with its call folded into the summary, and pairing repair
      // drops a result whose call isn't before it. So when a summary ends at
      // a call answered only later, the result joins the summary's chunk,
      // which the overlap guard then refuses, as on main.
      const summaryChanges = previous !== undefined
        && coveredBy.get(previous.id) !== coveredBy.get(msg.id)
        && !(this.hasToolUse(previous) && this.hasToolResult(msg));
      if (previous && (changeBefore || summaryChanges)) {
        // The compressible stream skips a system change, which stays raw. A
        // chunk across it would summarize both sides as one, rendered at its
        // first message, ahead of the change, so what came after the change
        // would be read before it. Close even a thin run there. A store
        // without changes whose chunks match its summaries chunks as before.
        // The store refuses a change between a call and its result where a
        // write can see it (MessageStore.refuseToolPairSplit), so this close
        // parts a pair only in a shape that refusal leaves alone.
        closeAt(i);
      }
      const phase = this.classifyMessage(msg, lastToolPhase);

      // Track tool phase for tool_result inheritance
      if (this.getToolNames(msg).length > 0) {
        lastToolPhase = phase;
      }

      let msgTokens = store.estimateTokens(msg);
      if (this.config.attachmentsIgnoreSize) {
        msgTokens = this.estimateTextOnlyTokens(msg);
      }

      // Semantic chunking uses a minimum of 2 messages (vs parent's 4) because
      // phase transitions are the primary chunk boundary signal. A tool_use + tool_result
      // pair is already a meaningful unit of work worth compressing independently.
      const phaseChanged = currentPhase !== null && phase !== currentPhase;
      const maxTokens = this.getMaxChunkTokens(currentPhase ?? phase);
      const sizeExceeded = currentTokens >= maxTokens;
      // Same tool-pair boundary guard as the base chunker (rebuildChunks in
      // AutobiographicalStrategy): never close a chunk whose LAST message
      // contains a tool_use block — its matching tool_result lives in the
      // immediately-following message (the one about to be pushed). Closing
      // here would split the pair across chunks; when the earlier chunk
      // compresses first, the raw orphan tool_result renders unpaired and
      // the Anthropic API rejects the request. Deferring the close by one
      // iteration pulls the tool_result into the same chunk. (Phase never
      // changes between a tool_use and its tool_result — the result inherits
      // lastToolPhase — so this defers sizeExceeded closes in practice.)
      const shouldClose =
        currentChunk.length >= 2 &&
        (phaseChanged || sizeExceeded) &&
        !this.lastMessageContainsToolUse(currentChunk);

      if (shouldClose) closeAt(i);

      currentChunk.push(msg);
      currentTokens += msgTokens;
      currentPhase = phase;
    }

    // Final remaining chunk (minimum 1 message to avoid silent drops)
    if (currentChunk.length >= 1 && currentPhase) {
      const chunk = this.createChunk(
        this.chunks.length,
        chunkFilteredStart,
        messagesToChunk.length,
        currentChunk,
        currentTokens,
        existingCompressed
      );
      chunk.phaseType = currentPhase;
      this.chunks.push(chunk);
      if (!chunk.compressed) this.compressionQueue.push(chunk.index);
    }
  }

  // ============================================================================
  // Override: Phase-aware compression prompts
  // ============================================================================

  protected getCompressionInstruction(chunk: Chunk, targetTokens: number): string {
    const leadSuffix = 'If any leads or open questions were identified but not yet pursued, mark them with [LEAD].';

    switch (chunk.phaseType) {
      case 'research':
        return (
          `Summarize the research performed. What was searched for, what sources were consulted, ` +
          `and what was found? Note any leads discovered. Be terse — the raw data is not needed, ` +
          `only what was learned. ${leadSuffix} Aim for about ${targetTokens} tokens.`
        );

      case 'synthesis':
        return (
          `Capture the reasoning and conclusions from this discussion. What connections were drawn? ` +
          `What hypotheses were formed or rejected? What decisions were made about what to ` +
          `investigate next? Preserve the logic chain. ${leadSuffix} Aim for about ${targetTokens} tokens.`
        );

      case 'lesson':
        return (
          `Record what knowledge was captured. What lessons were created or updated? ` +
          `What was the evidence basis? Note any confidence gaps or unresolved questions. ` +
          `${leadSuffix} Aim for about ${targetTokens} tokens.`
        );

      case 'subagent':
        return (
          `Summarize the subagent work. What tasks were dispatched, what did each return, ` +
          `and what was the coordinator's synthesis of the results? Collapse dispatch/wait mechanics. ` +
          `${leadSuffix} Aim for about ${targetTokens} tokens.`
        );

      default:
        return super.getCompressionInstruction(chunk, targetTokens);
    }
  }

  protected getMergeInstruction(
    targetLevel: SummaryLevel,
    sources: SummaryEntry[],
    targetTokens: number
  ): string {
    // Describe the phase composition of the sources
    const phaseCounts = new Map<string, number>();
    for (const s of sources) {
      const phase = s.phaseType ?? 'unknown';
      phaseCounts.set(phase, (phaseCounts.get(phase) ?? 0) + 1);
    }
    const phaseDesc = [...phaseCounts.entries()]
      .map(([phase, count]) => `${count} ${phase}`)
      .join(', ');

    const levelLabel = targetLevel === 2 ? 'L1 summaries' : 'L2 summaries';

    return (
      `Please consolidate these ${sources.length} ${levelLabel} (${phaseDesc}) ` +
      `into a single cohesive memory. ` +
      `Aim for about ${targetTokens} tokens. Write as you would to yourself — this is your ` +
      `autobiography, capturing the arc of what happened. ` +
      `IMPORTANT: Preserve any items marked with [LEAD] — these are unresolved questions ` +
      `that must survive consolidation until explicitly resolved or dropped.`
    );
  }

  // ============================================================================
  // Override: Asymmetric L1 budget allocation
  // ============================================================================

  protected selectL1Summaries(
    shownL1: SummaryEntry[],
    budget: number,
    maxTokens: number
  ): { selected: SummaryEntry[]; tokensUsed: number } {
    const effectiveBudget = Math.min(budget, maxTokens);

    const researchCap = effectiveBudget * (this.knowledgeConfig.researchL1BudgetCap ?? 0.3);
    const synthesisFloor = effectiveBudget * (this.knowledgeConfig.synthesisL1BudgetFloor ?? 0.4);

    // Partition by phase
    const synthesis: SummaryEntry[] = [];
    const lessons: SummaryEntry[] = [];
    const subagent: SummaryEntry[] = [];
    const research: SummaryEntry[] = [];
    const other: SummaryEntry[] = [];

    for (const s of shownL1) {
      switch (s.phaseType) {
        case 'synthesis': synthesis.push(s); break;
        case 'lesson': lessons.push(s); break;
        case 'subagent': subagent.push(s); break;
        case 'research': research.push(s); break;
        default: other.push(s); break;
      }
    }

    const selected: SummaryEntry[] = [];
    let used = 0;

    // Priority 1: Synthesis — guaranteed floor, can go higher if budget allows
    for (const s of synthesis) {
      if (used + s.tokens > effectiveBudget) break;
      // Keep going past the floor, but cap synthesis to avoid starving other phases
      const synthesisCap = effectiveBudget * (this.knowledgeConfig.synthesisL1BudgetCap ?? 0.7);
      if (used >= synthesisFloor && used + s.tokens > synthesisCap) break;
      selected.push(s);
      used += s.tokens;
    }

    // Priority 2: Lessons — high value, no cap
    for (const s of lessons) {
      if (used + s.tokens > effectiveBudget) break;
      selected.push(s);
      used += s.tokens;
    }

    // Priority 3: Subagent — moderate value, no cap
    for (const s of [...subagent, ...other]) {
      if (used + s.tokens > effectiveBudget) break;
      selected.push(s);
      used += s.tokens;
    }

    // Priority 4: Research — capped
    let researchUsed = 0;
    for (const s of research) {
      if (researchUsed + s.tokens > researchCap) break;
      if (used + s.tokens > effectiveBudget) break;
      selected.push(s);
      researchUsed += s.tokens;
      used += s.tokens;
    }

    return { selected, tokensUsed: used };
  }

  // ============================================================================
  // Phase detection
  // ============================================================================

  /**
   * Classify a single message by the phase it belongs to.
   * Uses tool_use block names for classification.
   * Messages with only tool_result (no tool_use) inherit from the last tool phase.
   */
  private classifyMessage(msg: StoredMessage, lastToolPhase: PhaseType): PhaseType {
    const toolNames = this.getToolNames(msg);

    if (toolNames.length > 0) {
      return this.classifyByToolNames(toolNames);
    }

    // tool_result without tool_use → inherit from preceding tool phase
    if (this.hasToolResult(msg)) {
      return lastToolPhase;
    }

    // Pure dialogue
    return 'synthesis';
  }

  /**
   * Classify by tool names with priority: lesson > subagent > research > synthesis.
   */
  private classifyByToolNames(toolNames: string[]): PhaseType {
    const lessonNames = this.knowledgeConfig.lessonToolNames ?? DEFAULT_LESSON_NAMES;
    const subagentPrefixes = this.knowledgeConfig.subagentToolPrefixes ?? DEFAULT_SUBAGENT_PREFIXES;
    const researchPrefixes = this.knowledgeConfig.researchToolPrefixes ?? DEFAULT_RESEARCH_PREFIXES;

    if (toolNames.some(n => lessonNames.includes(n))) return 'lesson';
    if (toolNames.some(n => subagentPrefixes.some(p => n.startsWith(p)))) return 'subagent';
    if (toolNames.some(n => researchPrefixes.some(p => n.startsWith(p)))) return 'research';

    return 'synthesis';
  }

  /**
   * Extract tool names from tool_use blocks in a message.
   */
  private getToolNames(msg: StoredMessage): string[] {
    const names: string[] = [];
    for (const block of msg.content) {
      if (block.type === 'tool_use') {
        names.push((block as { type: 'tool_use'; name: string }).name);
      }
    }
    return names;
  }

  /**
   * Get the maximum chunk token size for a given phase.
   * Research and subagent chunks can grow larger since they compress aggressively.
   */
  private getMaxChunkTokens(phase: PhaseType): number {
    const base = this.config.targetChunkTokens;
    switch (phase) {
      case 'research':
        return this.knowledgeConfig.maxResearchChunkTokens ?? base * 2;
      case 'subagent':
        return this.knowledgeConfig.maxSubagentChunkTokens ?? base * 2;
      case 'synthesis':
        return this.knowledgeConfig.maxSynthesisChunkTokens ?? Math.round(base * 1.5);
      case 'lesson':
        return this.knowledgeConfig.maxLessonChunkTokens ?? base;
      default:
        return base;
    }
  }
}
