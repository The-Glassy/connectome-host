import { type Diagnostics, namespaceDiagnostics } from './diagnostics.js';
import type { JsStore } from '@animalabs/chronicle';
import type { ContentBlock } from '@animalabs/membrane';
import type {
  MessageId,
  ContextEntry,
  ContextEntryInternal,
  SourceRelation,
  ContextLogView,
} from './types/index.js';
import { BlobManager } from './blob-manager.js';
import { MessageStore } from './message-store.js';
import { MalformedContentError, contentForWrite, malformedContentPlaces, wellFormedContent } from './well-formed-content.js';
import { storedJson } from './stored-json.js';

const DEFAULT_CONTEXT_STATE_ID = 'context';

/**
 * Wrapper around Chronicle append_log state for context log storage.
 * The context log is a materialized, editable working set derived from the message store.
 *
 * Supports namespacing for multi-agent scenarios where each agent has its own context log
 * but shares the same message store.
 */
export class ContextLog {
  private blobManager: BlobManager;
  /** Entries whose malformed content a read has already logged (wellFormedContent). */
  private malformedLogged = new Set<string>();
  private sourceToIndices: Map<MessageId, Set<number>> = new Map();
  private tokenEstimator: (text: string) => number;
  private stateId: string;

  /**
   * Where its stderr lines go: a log of one namespace names it; the log with
   * no namespace names none (#239).
   */
  private readonly log: Diagnostics;

  constructor(
    private store: JsStore,
    options: {
      estimator?: (text: string) => number;
      /** Namespace for multi-agent support. Creates state ID: `{namespace}/context` */
      namespace?: string;
    } = {}
  ) {
    const namespace = options.namespace;
    this.log = namespace ? namespaceDiagnostics(() => namespace) : console;
    this.stateId = ContextLog.stateIdFor(options.namespace);
    this.blobManager = new BlobManager(store);
    this.tokenEstimator = options.estimator ?? defaultTokenEstimator;
    this.rebuildSourceIndex();
  }

  /**
   * Register the context log state in Chronicle.
   * Should be called once when setting up the store.
   *
   * @param store The Chronicle store
   * @param namespace Optional namespace for multi-agent support
   */
  static register(store: JsStore, namespace?: string): void {
    const stateId = ContextLog.stateIdFor(namespace);
    store.registerState({
      id: stateId,
      strategy: 'append_log',
      deltaSnapshotEvery: 50,
      fullSnapshotEvery: 10,
    });
  }

  /** The context log's slot id for a namespace. */
  static stateIdFor(namespace?: string): string {
    return namespace ? `${namespace}/context` : DEFAULT_CONTEXT_STATE_ID;
  }

  private rebuildSourceIndex(): void {
    this.sourceToIndices.clear();
    const entries = this.getAllInternal();
    for (let i = 0; i < entries.length; i++) {
      const entry = entries[i];
      if (entry.sourceMessageId) {
        const set = this.sourceToIndices.get(entry.sourceMessageId) ?? new Set();
        set.add(i);
        this.sourceToIndices.set(entry.sourceMessageId, set);
      }
    }
  }

  /**
   * Append a new entry to the context log.
   */
  append(
    participant: string,
    content: ContentBlock[],
    sourceMessageId?: MessageId,
    sourceRelation?: SourceRelation,
    cacheMarker?: boolean
  ): ContextEntry {
    content = contentForWrite(content, 'Context entry refused');
    const storedContent = this.blobManager.extractBlobs(content);
    const index = this.length();

    const internal: ContextEntryInternal = {
      index,
      sourceMessageId,
      sourceRelation,
      participant,
      content: storedContent,
      cacheMarker,
    };

    this.store.appendToStateJson(this.stateId, internal);

    // Update source index
    if (sourceMessageId) {
      const set = this.sourceToIndices.get(sourceMessageId) ?? new Set();
      set.add(index);
      this.sourceToIndices.set(sourceMessageId, set);
    }

    return {
      index,
      sourceMessageId,
      sourceRelation,
      participant,
      content,
      cacheMarker,
    };
  }

  /**
   * Edit an entry's content at a specific index.
   */
  edit(index: number, content: ContentBlock[]): void {
    content = contentForWrite(content, `Edit of context entry ${index} refused`);
    const internal = this.getInternal(index);
    if (!internal) {
      throw new Error(`Context entry not found at index: ${index}`);
    }

    const storedContent = this.blobManager.extractBlobs(content);
    const updated: ContextEntryInternal = {
      ...internal,
      content: storedContent,
    };

    this.store.editStateItem(this.stateId, index, storedJson(updated));
  }

  /**
   * Remove an entry at a specific index.
   */
  remove(index: number): void {
    const internal = this.getInternal(index);
    if (!internal) {
      throw new Error(`Context entry not found at index: ${index}`);
    }

    this.store.redactStateItems(this.stateId, index, index + 1);
    this.rebuildSourceIndex();
  }

  /**
   * Remove a range of entries.
   */
  removeRange(start: number, end: number): void {
    this.store.redactStateItems(this.stateId, start, end);
    this.rebuildSourceIndex();
  }

  /**
   * Replace the entire context log with new entries.
   * Useful for strategies that rebuild the context.
   */
  replaceAll(entries: Array<{
    participant: string;
    content: ContentBlock[];
    sourceMessageId?: MessageId;
    sourceRelation?: SourceRelation;
    cacheMarker?: boolean;
  }>): ContextEntry[] {
    // An entry that doesn't match, or holds inline media the store can't
    // keep, is refused before the log is cleared, so that refusal leaves the
    // log as it was rather than half replaced. What a write mends, append
    // mends. An index loop, as the write loop below meets every index: a
    // hole is an entry with no content.
    for (let i = 0; i < entries.length; i++) {
      const places = malformedContentPlaces(entries[i]?.content);
      if (places.length > 0) throw new MalformedContentError(`Context entry ${i} of the replacement refused`, places);
    }
    // Clear existing entries
    const len = this.length();
    if (len > 0) {
      this.store.redactStateItems(this.stateId, 0, len);
    }

    // Add new entries
    const result: ContextEntry[] = [];
    for (const entry of entries) {
      result.push(this.append(
        entry.participant,
        entry.content,
        entry.sourceMessageId,
        entry.sourceRelation,
        entry.cacheMarker
      ));
    }

    return result;
  }

  /**
   * Get an entry by index.
   */
  get(index: number): ContextEntry | null {
    const internal = this.getInternal(index);
    if (!internal) {
      return null;
    }
    return this.internalToEntry(internal);
  }

  /**
   * Get all entries.
   */
  getAll(): ContextEntry[] {
    return this.getAllInternal().map((internal) => this.internalToEntry(internal));
  }

  /**
   * Get entries from a specific index.
   */
  getFrom(index: number): ContextEntry[] {
    return this.getAll().slice(index);
  }

  /**
   * Get the last N entries.
   */
  getTail(count: number): ContextEntry[] {
    const all = this.getAll();
    return all.slice(Math.max(0, all.length - count));
  }

  /**
   * Get the total number of entries.
   */
  length(): number {
    return this.store.getStateLen(this.stateId) ?? 0;
  }

  /**
   * Find all entries that reference a specific source message.
   */
  findBySource(sourceMessageId: MessageId): ContextEntry[] {
    const indices = this.sourceToIndices.get(sourceMessageId);
    if (!indices) {
      return [];
    }

    const entries: ContextEntry[] = [];
    for (const index of indices) {
      const entry = this.get(index);
      if (entry) {
        entries.push(entry);
      }
    }
    return entries;
  }

  /**
   * Get the source relation for entries referencing a message.
   */
  getSourceRelation(sourceMessageId: MessageId): Map<number, SourceRelation | undefined> {
    const result = new Map<number, SourceRelation | undefined>();
    const indices = this.sourceToIndices.get(sourceMessageId);
    if (!indices) {
      return result;
    }

    for (const index of indices) {
      const entry = this.get(index);
      if (entry) {
        result.set(index, entry.sourceRelation);
      }
    }
    return result;
  }

  /**
   * Estimate tokens for an entry.
   */
  estimateTokens(entry: ContextEntry): number {
    let tokens = 0;
    for (const block of entry.content) {
      tokens += this.estimateBlockTokens(block);
    }
    return tokens;
  }

  private estimateBlockTokens(block: ContentBlock): number {
    switch (block.type) {
      case 'text':
        return this.tokenEstimator(block.text);
      case 'thinking': {
        // Mirrors MessageStore.computeBlockTokensRaw: stamped price wins;
        // a signed block is a full hidden chain of thought, priced by the
        // larger of its visible text and its signature length.
        const stamped = (block as { tokenEstimate?: number }).tokenEstimate;
        if (typeof stamped === 'number') return stamped;
        const signature = (block as { signature?: string }).signature;
        const textTokens = this.tokenEstimator(block.thinking ?? '');
        if (typeof signature === 'string' && signature.length > 0) {
          return Math.max(textTokens, MessageStore.signedThinkingTokens(signature));
        }
        return textTokens;
      }
      case 'redacted_thinking': {
        // Encrypted reasoning payload, round-tripped verbatim — rough
        // estimate from the data length so budgeting isn't blind to it.
        const stamped = (block as { tokenEstimate?: number }).tokenEstimate;
        if (typeof stamped === 'number') return stamped;
        const data = (block as { data?: string }).data;
        return typeof data === 'string' && data.length > 0
          ? Math.round(data.length / MessageStore.ENCRYPTED_CARRIER_CHARS_PER_TOKEN)
          : MessageStore.HIDDEN_THINKING_TOKENS_DEFAULT;
      }
      case 'tool_use':
        return this.tokenEstimator(JSON.stringify(block.input)) + 20;
      case 'tool_result':
        if (!block.content) return 0;
        if (typeof block.content === 'string') {
          return this.tokenEstimator(block.content);
        }
        return block.content.reduce((sum, b) => sum + this.estimateBlockTokens(b), 0);
      case 'image':
        return block.tokenEstimate ?? 1600; // ~1568px image ≈ 1600 tokens (Anthropic)
      case 'generated_image': // as MessageStore prices it: an image without a stamp
        return 1600;
      case 'document':
      case 'audio':
      case 'video':
        return 1000;
      case 'system_change':
        // Mirrors MessageStore.computeBlockTokensRaw: priced from its JSON.
        return this.tokenEstimator(JSON.stringify(block));
      default:
        // Mirrors MessageStore.computeBlockTokensRaw: membrane's XML-history
        // carriers (tool_attempt, tool_notice) are priced as the markup they
        // replay as; any other unknown block stays at 0.
        return MessageStore.xmlHistoryCarrierTokens(block);
    }
  }

  /**
   * Create a read-only view of the log for strategies.
   */
  createView(): ContextLogView {
    return {
      getAll: () => this.getAll(),
      getFrom: (index) => this.getFrom(index),
      getTail: (count) => this.getTail(count),
      length: () => this.length(),
      estimateTokens: (entry) => this.estimateTokens(entry),
    };
  }

  private getAllInternal(): ContextEntryInternal[] {
    const state = this.store.getStateJson(this.stateId);
    if (!state || !Array.isArray(state)) {
      return [];
    }
    return state as ContextEntryInternal[];
  }

  private getInternal(index: number): ContextEntryInternal | null {
    // Point lookup through chronicle's per-item cache — O(item size).
    // See MessageStore.getInternal for why this must never fetch the
    // full state per index.
    //
    // Feature-detect: getStateItemJson landed in chronicle 0.2.2; boxes
    // still on <= 0.2.1 (npm copies) fall back to the full-materialization
    // path so a routine `git pull` of this package can never crash them.
    if (typeof (this.store as { getStateItemJson?: unknown }).getStateItemJson === 'function') {
      const item = this.store.getStateItemJson(this.stateId, index);
      return (item as ContextEntryInternal | null) ?? null;
    }
    const all = this.getAllInternal();
    return all[index] ?? null;
  }

  private internalToEntry(internal: ContextEntryInternal): ContextEntry {
    return {
      index: internal.index,
      sourceMessageId: internal.sourceMessageId,
      sourceRelation: internal.sourceRelation,
      participant: internal.participant,
      content: this.blobManager.resolveBlobs(
        wellFormedContent(internal.content, `context entry ${internal.index}`, this.malformedLogged, this.log),
      ),
      cacheMarker: internal.cacheMarker,
    };
  }
}

/**
 * Default token estimator: chars / 4
 */
function defaultTokenEstimator(text: string): number {
  return Math.ceil(text.length / 4);
}
