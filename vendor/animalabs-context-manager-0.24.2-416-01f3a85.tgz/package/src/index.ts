// Main class
export { ContextManager, ContextDerivationUnsupportedError, InitializationSupersededError } from './context-manager.js';
export type { ContextManagerConfig, DeriveContextOptions, ContextDerivation, ReopenDerivedOptions } from './context-manager.js';

// Phase channel (liveness-watchdog observability hook)
export { phaseChannel, enterPhase, withPhase, withPhaseAsync } from './phase-channel.js';

// Storage
export { MessageStore, defaultTokenEstimator, jsonTokenEstimator } from './message-store.js';
export type { MessageStoreEvent, MessageStoreListener, MessageWindow, MessageWindowOptions } from './message-store.js';
export { concatBodyGroups } from './adaptive/render.js';
export { continuesBody, bodyStart, bodyEnd, bodyBounds, bodyBoundsIn, type BodyShard } from './body-runs.js';
export { ContextLog } from './context-log.js';
export { BlobManager, blockAsStored } from './blob-manager.js';
export { MalformedContentError, malformedContentPlaces } from './well-formed-content.js';
export {
  persistMintRequestPreimage,
  getMintRequestPreimageBytes,
  getMintRequestByHash,
  MintPreimageMaterializationError,
} from './mint-preimage.js';
export type { Diagnostics } from './diagnostics.js';

// Strategies
export { PassthroughStrategy } from './strategies/passthrough.js';
export { WindowedPassthroughStrategy } from './strategies/windowed-passthrough.js';
export type { WindowedPassthroughOptions } from './strategies/windowed-passthrough.js';
export { filterMessageStoreView, mergeMessageStoreViews } from './message-view.js';
export { AutobiographicalStrategy, type AutobiographicalProgressSnapshot, type Chunk } from './strategies/autobiographical.js';
export { KnowledgeStrategy } from './strategies/knowledge.js';

// Utilities
export { splitMixedToolMessages, stripUnpairedToolBlocks } from './normalize-tool-messages.js';
export { resolveEffectiveConfig } from './config-provenance.js';
export type { ConfigLayer, ConfigResolutionSemantics, EffectiveConfigReport } from './config-provenance.js';

// Errors — cross-package behavioral surface. agent-framework gates its
// OverBudget drain breaker on these errors (AF PR #58, framework.ts
// classifyInferenceError); exporting them from the root gives consumers a
// real `instanceof` instead of stringly-typed `err.name` matching.
export { OverBudgetError, UncoveredDropError } from './adaptive/picker.js';
export type { OverBudgetClearedBy } from './adaptive/picker.js';
export { CompressionWithdrawn } from './compression-withdrawn.js';
export { StoreTopologyError, type TopologyViolation } from './strategies/autobiographical.js';
export { planTopologyRepair, type RepairPlan, type RepairInputs, type RepairOptions } from './repair/topology.js';
export type { OverBudgetDiagnostics, OverBudgetRawPin } from './adaptive/picker.js';

// Types
export type {
  // Message types
  MessageId,
  Sequence,
  BranchId,
  MessageMetadata,
  StoredMessage,
  BlobReference,
  StoredContentBlock,
  MessageQuery,
  MessageQueryResult,
  TimeRangeQueryOptions,
  ChannelQueryOptions,
  TimeAndChannelQueryOptions,
  IndexedMessageQueryResult,
  ChannelCount,
  ChannelTokenBreakdown,
  ChannelTokenStats,
  ChannelTokenStatsOptions,
  // Context types
  SourceRelation,
  ContextEntry,
  TokenBudget,
  PendingWork,
  WaitingWork,
  BranchInfo,
  ContextInjection,
  CompileResult,
  BranchRef,
  RawBodySource,
  CompiledMessageSources,
  CompileProvenance,
  JournalMark,
  RenderedLayout,
  LayoutUnit,
  ThinkingStrip,
  // Strategy types
  RequestOverhead,
  MessageStoreView,
  ContextLogView,
  StrategyContext,
  ReadinessState,
  ContextStrategy,
  HotContextSettings,
  HotContextSettingsUpdate,
  HotContextSettingsStatus,
  HotConfigurableStrategy,
  RenderingFrontierStrategy,
  DerivationManifest,
  DerivationManifestOptions,
  DerivationManifestStrategy,
  AutobiographicalConfig,
  AutobiographicalOptions,
  LoadRepairReport,
  LoadRepairDroppedSummary,
  LoadRepairDropReason,
  RecallEnvelopeMode,
  CarrierPolicy,
  SummaryLevel,
  SummaryEntry,
  PhaseType,
  KnowledgeConfig,
  KnowledgeOptions,
  ResettableStrategy,
  TimeRangeSummaryEntry,
  SummaryOverviewStrategy,
  AddMessageOptions,
  CompressionHoldOptions,
  CompressionHoldInfo,
  RenderedSummaryInfo,
  ImageCeilings,
  ThinkingBinding,
  RequestIdentity,
} from './types/index.js';

// Accepted rounds and fold receipts
export {
  FOLD_QUERY_DEFAULT_LIMIT,
  FOLD_QUERY_MAX_LIMIT,
  ACCEPTED_LAYOUT_RECORD,
  STORE_IDENTITY_RECORD,
  storeIdentity,
} from './fold-journal.js';
export type {
  FoldReceipt,
  FoldReceiptSource,
  FoldChange,
  FoldForm,
  FoldLayoutRun,
  FoldSpanBound,
  FoldQuery,
  FoldQueryResult,
  RoundUsage,
  ReceiptSource,
  Presentation,
} from './fold-journal.js';

export {
  DEFAULT_AUTOBIOGRAPHICAL_CONFIG,
  isResettableStrategy,
  isSummaryOverviewStrategy,
  isHotConfigurableStrategy,
  isRenderingFrontierStrategy,
  isDerivationManifestStrategy,
} from './types/index.js';
