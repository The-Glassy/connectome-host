import { type Diagnostics, namespaceDiagnostics } from './diagnostics.js';
import type { JsStore } from '@animalabs/chronicle';
import type { ContentBlock } from '@animalabs/membrane';
import type {
  MessageId,
  Sequence,
  MessageMetadata,
  StoredMessage,
  StoredMessageInternal,
  MessageStoreView,
  MessageQuery,
  MessageQueryResult,
  TimeRangeQueryOptions,
  ChannelQueryOptions,
  TimeAndChannelQueryOptions,
  IndexedMessageQueryResult,
  ChannelCount,
  ChannelTokenStats,
  ChannelTokenStatsOptions,
} from './types/index.js';
import { BlobManager } from './blob-manager.js';
import { bodyBoundsIn, bodyEnd, bodyStart, continuesBody } from './body-runs.js';
import { contentForWrite, wellFormedContent } from './well-formed-content.js';
import { storedJson } from './stored-json.js';

/** Whether content, written or stored, holds a top-level block of `type`; content that isn't an array holds none. */
function holdsBlock(content: unknown, type: string): boolean {
  return Array.isArray(content) && content.some((block) => (block as { type?: unknown } | null)?.type === type);
}

/**
 * Each call content holds, by id, and whether it's still open after the
 * content's own later blocks: a result after its call in the same content,
 * as in a bundled cycle (splitMixedToolMessages), answers it.
 */
function callsInOrder(content: unknown): Map<string, boolean> {
  const calls = new Map<string, boolean>();
  if (!Array.isArray(content)) return calls;
  for (const block of content as Array<{ type?: unknown; id?: unknown; toolUseId?: unknown } | null>) {
    if (block?.type === 'tool_use' && typeof block.id === 'string') calls.set(block.id, true);
    else if (block?.type === 'tool_result' && typeof block.toolUseId === 'string' && calls.has(block.toolUseId)) calls.set(block.toolUseId, false);
  }
  return calls;
}

/** The ids of content's top-level calls (`tool_use`), or of the calls its results (`tool_result`) answer, in block order. */
function toolIds(content: unknown, type: 'tool_use' | 'tool_result'): string[] {
  if (!Array.isArray(content)) return [];
  const ids: string[] = [];
  for (const block of content as Array<{ type?: unknown; id?: unknown; toolUseId?: unknown } | null>) {
    const id = type === 'tool_use' ? block?.id : block?.toolUseId;
    if (block?.type === type && typeof id === 'string') ids.push(id);
  }
  return ids;
}

const DEFAULT_MESSAGE_STATE_ID = 'messages';

/**
 * JSON-pointer field paths registered as native chronicle secondary indexes
 * on the message slot (see MessageStore.registerHistoryIndexes). Shared
 * constants so registration and every query call agree on the exact path.
 *
 * TWO channel-id schemas are indexed, not one (2026-09, downstream
 * agent-framework review): this codebase's own `MessageQuery.metadata` docs
 * and the original single-schema design of this feature both assumed
 * `metadata.external.channelId` — but agent-framework's REAL MCPL
 * channel-ingestion path (`handleMcplChannelIncoming`,
 * `agent-framework/src/framework.ts`) writes `metadata.channelId` directly,
 * with no `external` nesting at all. Neither schema can be treated as
 * legacy/dead: Mythos/Sol-scale stores already carry months of history
 * under whichever shape was actually in effect at ingestion time, and the
 * entire point of this feature is searching THAT real history — not just
 * whatever gets written going forward. So both fields are registered as
 * independent string-kind indexes, and every channel-query method below
 * consults and merges both (see queryChannelOrdinals, getChannelCounts,
 * extractChannelId).
 */
const TIMESTAMP_FIELD = '/timestamp';
/** Real agent-framework ingestion shape — see the block comment above. */
const CHANNEL_FIELD_TOP = '/metadata/channelId';
/** Older/parallel convention this codebase's MessageQuery type already
 *  documents — kept alongside CHANNEL_FIELD_TOP since something else in
 *  this ecosystem may still rely on it, and covering it costs little. */
const CHANNEL_FIELD_EXTERNAL = '/metadata/external/channelId';

/**
 * Thrown by the query-by-time/channel methods when the underlying chronicle
 * build predates the field-index capability (registerHistoryIndexes will
 * have silently skipped registration at construction in that case — see its
 * doc for why that's a silent skip rather than a throw). Unlike the
 * point-lookup/slice feature-detects elsewhere in this file, there is no
 * slow-scan fallback to degrade to here: a best-effort O(n)
 * re-implementation would defeat the entire point of this API (callers
 * reach for it specifically to avoid materializing/scanning the whole
 * store), so callers need to know up front they can't rely on it.
 */
const HISTORY_INDEX_UNSUPPORTED_MSG = 'Chronicle history index unsupported — update @animalabs/chronicle';

/**
 * Thrown when a native index query returns `null` twice in a row — once on
 * the original call, once again after a self-heal re-registration retry
 * (see queryIndexOrHeal). Distinct from HISTORY_INDEX_UNSUPPORTED_MSG:
 * that one means this chronicle build doesn't have the capability at all
 * (checked once, up front, by each call site's own typeof guard); this one
 * means the capability exists and the index WAS registered (at
 * construction, via registerHistoryIndexes) but chronicle is reporting it
 * as currently unqueryable — e.g. a cross-branch write on the same
 * `stateId` poisoned it (chronicle drops an index rather than mix two
 * branches' ordinals — see registerStateFieldIndex's doc in
 * node_modules/@animalabs/chronicle/index.d.ts), or a parse failure. A
 * single re-register-and-retry is chronicle's documented recovery path
 * (registerStateFieldIndex is idempotent/cheap-when-fresh and does a full
 * rebuild when needed); still-null after that means something is actually
 * wrong and callers need to know they can't rely on the fast path right
 * now, rather than silently getting an empty/degraded result.
 */
const HISTORY_INDEX_UNAVAILABLE_MSG = 'Chronicle history index unavailable (registered but not queryable — see logs)';

/**
 * Local mirrors of chronicle's JsIndexRangeQuery/JsIndexEqQuery (index.d.ts)
 * — a plain inline object type can't be self-referenced via `typeof` inside
 * a capability-checked method signature (TS2502), so these are named
 * separately instead of importing the chronicle types directly (this
 * package's chronicle dependency range doesn't guarantee they exist on
 * every install — see HISTORY_INDEX_UNSUPPORTED_MSG).
 */
interface NativeIndexRangeOpts {
  gte?: number;
  lte?: number;
  limit?: number;
  offset?: number;
  reverse?: boolean;
}
interface NativeIndexEqOpts {
  limit?: number;
  offset?: number;
}

/**
 * Cross-instance write versions, keyed by the shared JsStore object and
 * state id. Multiple MessageStore instances can share one JsStore (same
 * process only — the store LOCK forbids cross-process sharing), and the
 * cheap `getAllInternal` revalidation (item count + tail identity) cannot
 * see an EDIT of an earlier item made through a sibling instance: count
 * and tail are unchanged, so the first instance would serve stale content
 * (2026-07-25 review finding on the mythos-wedge ingest fix). Every
 * mutator bumps the shared version; the cache stores the version it was
 * built at and revalidates against it — O(1), and the quadratic-ingest fix
 * stays intact. WeakMap so stores never leak.
 */
const sharedWriteVersions = new WeakMap<object, Map<string, number>>();

/**
 * Its `[cm-cache]` line goes through `log`, the bumping store's diagnostics (#239).
 *
 * An append moves the version by one and adds one record; every other
 * mutation moves it and adds no record. getAllInternal reads "only appends
 * since" from that: a slot grown by exactly the versions moved. That holds
 * only while the slot is written through MessageStore alone.
 */
function bumpWriteVersion(store: object, stateId: string, log: Diagnostics): number {
  let m = sharedWriteVersions.get(store);
  if (!m) {
    m = new Map();
    sharedWriteVersions.set(store, m);
  }
  const next = (m.get(stateId) ?? 0) + 1;
  m.set(stateId, next);
  if (typeof process !== 'undefined' && process.env?.CM_CACHE_DIAG) {
    const site = (new Error().stack ?? '').split('\n')[2]?.trim();
    log.error(`[cm-cache] writeVersion bump ${stateId} → ${next} at ${site}`);
  }
  return next;
}

function currentWriteVersion(store: object, stateId: string): number {
  return sharedWriteVersions.get(store)?.get(stateId) ?? 0;
}

/**
 * The window the counter can't see (nissa-seru, #238): a write the counter
 * doesn't count — through another handle on the branch, or a chronicle call
 * outside MessageStore — between two counted writes. Every counted write
 * records the revision it leaves (`sharedLastRevisions`); the next counted
 * write compares the revision it finds with that, and a difference is a gap:
 * `sharedGapCounts` moves, and a cache built before the move can't be
 * extended, only rebuilt. Keyed by the JsStore object, as the counter is.
 */
const sharedLastRevisions = new WeakMap<object, Map<string, number>>();
const sharedGapCounts = new WeakMap<object, Map<string, number>>();

function currentGapCount(store: object, stateId: string): number {
  return sharedGapCounts.get(store)?.get(stateId) ?? 0;
}

/** Before a counted write: a revision the last counted write didn't leave means an uncounted write happened since. */
function noteRevisionBeforeCountedWrite(store: JsStore, stateId: string): void {
  const last = sharedLastRevisions.get(store)?.get(stateId);
  if (last !== undefined && last !== slotRevision(store, stateId)) {
    let m = sharedGapCounts.get(store);
    if (!m) { m = new Map(); sharedGapCounts.set(store, m); }
    m.set(stateId, (m.get(stateId) ?? 0) + 1);
  }
}

/** The revision the last counted write left, or undefined before any. A read
 *  that finds another revision has an uncounted write since, whoever made it. */
function revisionLeftByLastCountedWrite(store: object, stateId: string): number | undefined {
  return sharedLastRevisions.get(store)?.get(stateId);
}

/** At a MessageStore's construction, before its cache is built: the slot's
 *  revision, as the baseline the first counted write on this handle compares
 *  with, where no counted write has left one. Every cache on a handle and
 *  slot belongs to a MessageStore, so none exists before the baseline, and
 *  an uncounted write after it moves the revision away from the baseline for
 *  the first counted write to see (nissa-seru's fourth case on #238: a
 *  handle just opened, with no counted write yet). */
function recordBaselineRevision(store: JsStore, stateId: string): void {
  if (revisionLeftByLastCountedWrite(store, stateId) === undefined) recordRevisionAfterCountedWrite(store, stateId);
}

/** After a counted write: the revision it leaves, for the next one to compare with. */
function recordRevisionAfterCountedWrite(store: JsStore, stateId: string): void {
  let m = sharedLastRevisions.get(store);
  if (!m) { m = new Map(); sharedLastRevisions.set(store, m); }
  m.set(stateId, slotRevision(store, stateId));
}

/** Bumped by every mutation except append (main's token for a cache of
 *  per-message facts that survives appends). On this branch getAll's mapped
 *  view is memoised per internal record (storedViews), which an edit or
 *  removal misses by construction, so nothing reads this yet; the bumps are
 *  kept where main makes them so a reader can be added without hunting. */
const sharedEditVersions = new WeakMap<object, Map<string, number>>();
function bumpEditVersion(store: object, stateId: string): void {
  let m = sharedEditVersions.get(store);
  if (!m) {
    m = new Map();
    sharedEditVersions.set(store, m);
  }
  m.set(stateId, (m.get(stateId) ?? 0) + 1);
}

/**
 * The slot's revision: current exactly while this number is unchanged.
 *
 * With a chronicle that exposes `stateHeadOffset` (branch-bound handles,
 * 2026-10), this is the log offset of the slot's newest chain record on the
 * handle's branch — changed by every write to the slot on that branch
 * (append, edit, redact, set, the store's own snapshots) and by nothing
 * else. It is the same number for every handle on the same branch, which
 * is what the process-local write version above cannot be: that map is
 * keyed by handle object, so a write through a second handle to the same
 * branch (a hospital tool holding `root.view('main')` while the resident
 * runs on the root) left the first handle's cache serving the old value
 * when the edit preserved the item count — the count-and-tail
 * revalidation could not see it. Field indexes already key freshness on
 * this offset for the same reason.
 *
 * On an older chronicle the write version is the best available token.
 */
function slotRevision(store: JsStore, stateId: string): number {
  const s = store as { stateHeadOffset?: (id: string) => number | null };
  if (typeof s.stateHeadOffset === 'function') return s.stateHeadOffset(stateId) ?? -1;
  return currentWriteVersion(store, stateId);
}

function hasSlotRevision(store: JsStore): boolean {
  return typeof (store as { stateHeadOffset?: unknown }).stateHeadOffset === 'function';
}

/** CM_CACHE_DIAG=1: log every materialization-cache miss with its REASON and
 *  cost, every invalidating mutation, and every write-through fallback. The
 *  full rebuild is ~20s of CPU on a large store on production hardware —
 *  a silent cache miss IS the latency incident (mythos, 2026-07-26). */
const CACHE_DIAG = typeof process !== 'undefined' && !!process.env?.CM_CACHE_DIAG;
/** Through `log`, the store's diagnostics, so an isolated slot's lines name its namespace (#239). */
function cacheDiag(msg: string, log: Diagnostics): void {
  if (CACHE_DIAG) log.error(`[cm-cache] ${msg}`);
}

/**
 * Memo of the caller-facing view of each materialized message, keyed by the
 * identity of its internal (chronicle round-trip) object.
 *
 * `getAll()` maps every internal to a StoredMessage — a wrapper object, a
 * Date, and blob-resolved content. That mapping used to be redone for the
 * whole history after every append, and it is redone per MessageStore
 * instance. Keying on the internal object makes it once per message per
 * materialization: an append converts only the new message, and two stores
 * holding the SAME internal objects — a store and the derived stores seeded
 * from it (see deriveOnto) — share one wrapper and one resolved copy of
 * every inherited message instead of each holding their own.
 *
 * Safe because the wrapper depends only on the internal's own fields, an
 * edit replaces the internal object rather than mutating it, and both the
 * internals and the mapped messages are immutable to callers (see
 * allCache). WeakMap: entries die with the materialization that owns them.
 */
const storedViews = new WeakMap<object, StoredMessage>();

/**
 * Internal: what a derived MessageStore starts from instead of
 * re-materializing its slot. See MessageStore.deriveOnto.
 */
interface MessageStoreSeed {
  namespace: string | undefined;
  stateId: string;
  internals: unknown[];
  blobManager: BlobManager;
  tokenCalibration: number;
}

/**
 * Event emitted when the message store changes.
 */
export type MessageStoreEvent =
  | { type: 'add'; message: StoredMessage }
  | { type: 'edit'; messageId: MessageId; oldContent: ContentBlock[]; newContent: ContentBlock[] }
  | { type: 'remove'; messageId: MessageId }
  | { type: 'removeRange'; fromId: MessageId; toId: MessageId };

/**
 * Listener for message store events.
 */
export type MessageStoreListener = (event: MessageStoreEvent) => void;

/**
 * Options for windowed message reads.
 */
export interface MessageWindowOptions {
  /**
   * Re-inline blob media (images/documents) into content blocks, matching
   * the behavior of get()/getAll(). Default true. Viewers that only need
   * text/thinking/tool blocks should pass false to avoid inflating large
   * base64 payloads.
   */
  resolveBlobs?: boolean;
  /**
   * Extend the window edges outward so that no bodyGroup (shard run of a
   * single large message) is split across the window boundary. Default
   * false (exact offset/limit semantics).
   */
  alignToBodyGroups?: boolean;
}

/**
 * A window of messages plus enough metadata to page through the store.
 */
export interface MessageWindow {
  messages: StoredMessage[];
  /**
   * Actual first slot index of the returned window. May be lower than the
   * requested offset when alignToBodyGroups extended the window backward.
   */
  startIndex: number;
  /** Total number of messages in the store at read time. */
  totalCount: number;
}

/**
 * Options for token estimation.
 */
export interface TokenEstimatorOptions {
  /** Custom token estimator function */
  estimator?: (text: string) => number;
}

/**
 * Wrapper around Chronicle append_log state for message storage.
 * Handles blob extraction and provides a clean interface for message operations.
 */
export class MessageStore {
  private blobManager: BlobManager;
  /** Messages whose malformed content a read has already logged (wellFormedContent). */
  private malformedLogged = new Set<string>();
  private listeners: Set<MessageStoreListener> = new Set();
  private idToIndex: Map<MessageId, number> = new Map();
  private tokenEstimator: (text: string) => number;
  private stateId: string;
  /** The slot's namespace as configured (undefined = the shared slot). */
  private namespace: string | undefined;

  /**
   * Where its stderr lines go, its `[cm-cache]` lines included: a slot of one
   * namespace (an isolated manager's, or an auxiliary slot named by its
   * namespace) names it; the shared slot is no one namespace's, and its lines
   * name none (#239).
   */
  private readonly log: Diagnostics;

  constructor(
    private store: JsStore,
    options: TokenEstimatorOptions & {
      /** Namespace for multi-agent support. Creates state ID: `{namespace}/messages` */
      namespace?: string;
      /** @internal Seed for a derived store; use {@link deriveOnto}. */
      seed?: MessageStoreSeed;
    } = {}
  ) {
    this.tokenEstimator = options.estimator ?? defaultTokenEstimator;
    const seed = options.seed;
    // A derived store's diagnostics name the namespace it shares with its parent.
    const namespace = seed ? seed.namespace : options.namespace;
    this.log = namespace ? namespaceDiagnostics(() => namespace) : console;
    if (seed) {
      this.namespace = seed.namespace;
      this.stateId = seed.stateId;
      // Blobs are content-addressed and global to the store, so the parent's
      // resolve cache is valid here and must not be rebuilt per child.
      this.blobManager = seed.blobManager;
      this.tokenCalibration = seed.tokenCalibration;
      recordBaselineRevision(store, this.stateId);
      this.allCache = {
        branchId: store.currentBranch().id,
        sequence: store.currentSequence(),
        internals: seed.internals as StoredMessageInternal[],
        writeVersion: slotRevision(store, this.stateId),
        writeCount: currentWriteVersion(store, this.stateId),
        gapCount: currentGapCount(store, this.stateId),
      };
      // The id index is rebuilt from the seeded array on first lookup
      // (indexBranchId starts unset), and the native history indexes are
      // registered on first query (queryIndexOrHeal). Neither is paid for a
      // child that never asks.
      return;
    }
    this.namespace = options.namespace;
    this.stateId = options.namespace
      ? `${options.namespace}/messages`
      : DEFAULT_MESSAGE_STATE_ID;
    this.blobManager = new BlobManager(store);
    recordBaselineRevision(store, this.stateId);
    this.rebuildIndex();
    this.registerHistoryIndexes();
  }

  /**
   * A MessageStore over `view`, a branch-bound handle on a branch forked from
   * this store's branch AT ITS CURRENT HEAD, for the same message slot.
   *
   * The derived store starts from this instance's already-materialized
   * messages instead of asking chronicle to rebuild and re-parse the slot:
   * an array of references is copied, the message objects themselves are
   * shared, and so are their caller-facing views and resolved blobs. Reads
   * are shared; writes go to `view`'s branch and are never seen here.
   *
   * Call synchronously after creating the branch — the seed is this store's
   * state right now, which is the branch's state only until either side
   * writes. If the seed does not match the branch (it was not forked at
   * this store's head), the derived store falls back to a cold load.
   */
  deriveOnto(view: JsStore): MessageStore {
    const internals = this.getAllInternal();
    const length = view.getStateLen(this.stateId) ?? 0;
    let coherent = length === internals.length;
    if (coherent && length > 0) {
      const last = (view as { getStateItemJson?: (id: string, index: number) => unknown })
        .getStateItemJson?.(this.stateId, length - 1) as StoredMessageInternal | null | undefined;
      const mine = internals[length - 1]!;
      coherent = !!last && last.id === mine.id && last.sequence === mine.sequence;
    }
    if (!coherent) {
      const cold = new MessageStore(view, { estimator: this.tokenEstimator, namespace: this.namespace });
      cold.tokenCalibration = this.tokenCalibration;
      return cold;
    }
    return new MessageStore(view, {
      estimator: this.tokenEstimator,
      seed: {
        namespace: this.namespace,
        stateId: this.stateId,
        internals: internals.slice(),
        blobManager: this.blobManager,
        tokenCalibration: this.tokenCalibration,
      },
    });
  }

  /**
   * Register the native chronicle secondary indexes that back
   * queryByTime/queryByChannel/queryByTimeAndChannel/getChannelCounts/
   * getChannelTokenStats: `/timestamp` (numeric), plus TWO channel-id
   * indexes — `/metadata/channelId` and `/metadata/external/channelId`
   * (both string) — on this store's message slot. See the dual-schema
   * block comment on CHANNEL_FIELD_TOP/CHANNEL_FIELD_EXTERNAL above for
   * why there are two.
   *
   * Best-effort: `registerStateFieldIndex` is a NEW chronicle capability
   * (2026-09) that may not exist on an older `@animalabs/chronicle` install
   * — e.g. a resident whose native module hasn't been rebuilt/updated yet.
   * Feature-detected exactly like getStateItemJson/getStateSlice elsewhere
   * in this file: skip silently rather than throw, since registration is
   * purely a setup step. The query methods above throw a clear, specific
   * error if called against a store that never got indexes registered
   * (HISTORY_INDEX_UNSUPPORTED_MSG) — callers need to know they can't rely
   * on the fast path rather than have it silently degrade into a full scan
   * that would defeat the reason for calling it.
   *
   * Safe to call unconditionally on every construction (including every
   * sibling MessageStore sharing this JsStore): registration is idempotent
   * and cheap once the persisted index is fresh — chronicle checks the
   * slot's item count before doing any rebuild work.
   */
  private registerHistoryIndexes(): void {
    const s = this.store as {
      registerStateFieldIndex?: (stateId: string, field: string, kind: string) => void;
    };
    if (typeof s.registerStateFieldIndex !== 'function') return;
    s.registerStateFieldIndex(this.stateId, TIMESTAMP_FIELD, 'number');
    s.registerStateFieldIndex(this.stateId, CHANNEL_FIELD_TOP, 'string');
    s.registerStateFieldIndex(this.stateId, CHANNEL_FIELD_EXTERNAL, 'string');
  }

  /**
   * Register the message store state in Chronicle.
   * Should be called once when setting up the store.
   *
   * @param store The Chronicle store
   * @param namespace Optional namespace for multi-agent support
   */
  static register(store: JsStore, namespace?: string): void {
    // fullSnapshotEvery counts DELTA snapshots, so a full snapshot fires
    // every deltaSnapshotEvery x fullSnapshotEvery appends — and for an
    // AppendLog it copies the ENTIRE history into the log. At the old
    // 50x10=500 cadence, a long-lived store spends most of its disk on
    // these copies (2026-08-01 Mythos: 5 full snapshots = 57% of the last
    // GB, 114 MB each). 50x100=5000 keeps reconstruction bounded while
    // cutting that dominant growth term 10x.
    //
    // NOTE: registrations persist in the store; changing these numbers
    // does nothing for existing stores by itself. ContextManager.open
    // catches the StateExists error and applies the same values via
    // updateStateStrategy (using registrationFor below).
    store.registerState(MessageStore.registrationFor(namespace));
  }

  /** Registration constants, shared with the update-on-existing-store path. */
  static registrationFor(namespace?: string): {
    id: string; strategy: 'append_log'; deltaSnapshotEvery: number; fullSnapshotEvery: number;
  } {
    return {
      id: namespace ? `${namespace}/messages` : DEFAULT_MESSAGE_STATE_ID,
      strategy: 'append_log',
      deltaSnapshotEvery: 50,
      fullSnapshotEvery: 100,
    };
  }

  /**
   * Add a listener for store events.
   */
  addListener(listener: MessageStoreListener): () => void {
    this.listeners.add(listener);
    return () => this.listeners.delete(listener);
  }

  private emit(event: MessageStoreEvent): void {
    for (const listener of this.listeners) {
      listener(event);
    }
  }


  private indexWriteVersion = -1;
  private indexBranchId = '';

  /**
   * Id→index lookup that survives both sibling-instance writes and Chronicle
   * branch switches. Same-instance mutators maintain the index themselves and
   * stamp indexWriteVersion at their bump; a version the stamp hasn't seen
   * means a SIBLING MessageStore on this JsStore wrote. Branches can expose
   * different append-log shapes without changing that process-local version,
   * so native branch ID is an independent freshness key. Names can be reused
   * after deletion, including through direct Chronicle calls with no observed
   * intermediate switch (issue #92). Rebuild once, then
   * resolve. O(1) on every same-instance, same-branch path (2026-07-25 review
   * class: a stale index previously threw "Message not found" or, after
   * shifts, would have mutated or branched from the wrong item).
   */
  private lookupIndex(messageId: MessageId): number | undefined {
    if (
      this.indexBranchId !== this.store.currentBranch().id ||
      this.indexWriteVersion !== slotRevision(this.store, this.stateId)
    ) {
      this.rebuildIndex();
    }
    return this.idToIndex.get(messageId);
  }

  /** Whether the materialized cache reflects every write made so far on this branch. */
  private cacheIsCurrent(): boolean {
    return (
      this.allCache !== null &&
      this.allCache.branchId === this.store.currentBranch().id &&
      this.allCache.writeVersion === slotRevision(this.store, this.stateId)
    );
  }

  private rebuildIndex(): void {
    this.indexBranchId = this.store.currentBranch().id;
    this.indexWriteVersion = slotRevision(this.store, this.stateId);
    this.idToIndex.clear();
    const messages = this.getAllInternal();
    for (let i = 0; i < messages.length; i++) {
      this.idToIndex.set(messages[i].id, i);
    }
  }

  /**
   * Memo of the fully-materialized internal state (2026-07-18, sonn5 OOM /
   * CPU-churn class, companion to the BlobManager resolve cache).
   *
   * A miss in `getAllInternal()` is a full chronicle `getStateJson` — serde
   * serialize + JS parse of the ENTIRE message state — unless only appends
   * happened since the cache was built, which it reads by point lookup
   * (#251). Compile calls it ~6× per pass (postStripEstimates,
   * getRecentWindowStart, getHeadWindowEnd, getCompressibleMessages,
   * selectAdaptive, rebuildChunks), and compression catch-up repeats those passes
   * continuously: on a 19.5k-message store, perf showed the agent pinning
   * a full core in serde_json between LLM calls.
   *
   * Freshness tokens: (native branch ID, head sequence) — with a cheap same-slot
   * revalidation for foreign-state writes — PLUS the process-wide
   * per-(store, stateId) write version (sharedWriteVersions above), which
   * makes edits/removals through SIBLING MessageStore instances visible:
   * count+tail revalidation alone cannot see an in-place edit of an
   * earlier item. (An instance-local counter was tried first and broke
   * multi-instance sharing — integration.test.ts Multi-Agent Namespacing;
   * the shared-map version is cross-instance by construction.)
   *
   * The cached array and its objects MUST be treated as immutable by all
   * callers. Strategy code copies before mutating (verified 2026-07-18:
   * window entries own their `content` pointers; collapseConsecutive
   * spreads; image cap/strip replace blocks rather than mutating).
   */
  private allCache: {
    branchId: string;
    sequence: number;
    internals: StoredMessageInternal[];
    /** Freshness: slotRevision at the last point the cache was known current. */
    writeVersion: number;
    /** Main's in-process write counter at that point (currentWriteVersion):
     *  how many writes through a MessageStore on this store moved since,
     *  which is how many appends an appends-only extension expects. */
    writeCount: number;
    /** sharedGapCounts at that point: an uncounted write seen since makes the cache rebuild-only. */
    gapCount: number;
  } | null = null;

  /**
   * Optional extra fields for `append`, used by callers that need to set
   * adaptive-resolution metadata (bodyGroupId for shards, initial
   * resolution state, etc.) at ingestion time.
   */
  static readonly _appendExtraKeys = ['bodyGroupId', 'shardIndex', 'shardCount', 'currentResolution', 'lockedByAgent'] as const;

  /**
   * Append a new message to the store.
   *
   * `extra` is an optional bag of adaptive-resolution metadata
   * (bodyGroupId / shardIndex / shardCount / currentResolution /
   * lockedByAgent) that callers may set at ingestion. Field semantics match
   * StoredMessage.
   */
  append(
    participant: string,
    content: ContentBlock[],
    metadata?: MessageMetadata,
    causedBy?: MessageId[],
    extra?: {
      bodyGroupId?: string;
      shardIndex?: number;
      shardCount?: number;
      currentResolution?: number;
      lockedByAgent?: boolean;
    }
  ): StoredMessage {
    content = contentForWrite(content, 'Message refused');
    this.refuseToolPairSplit(content, 'Message refused');
    // Extract blobs from content
    const storedContent = this.blobManager.extractBlobs(content);

    const partialInternal = {
      participant,
      content: storedContent,
      metadata,
      timestamp: Date.now(),
      causedBy,
      ...(extra ?? {}),
    };

    // Single atomic op: chronicle peeks the next record id+sequence under its
    // write lock, splices them into the payload as `id` and `sequence`, and
    // writes one record. The reconstructed state sees a fully-populated
    // StoredMessageInternal, and `branchAt(messageId)` forks at this
    // message's own sequence — exactly the post-fork-visible point.
    //
    // Whether this instance's caches reflected every write to the slot
    // BEFORE this append, including writes made through other handles to
    // the same branch. A local write may re-certify only state that was
    // current going in: a stale id index or materialized cache stays
    // stale and is rebuilt on the next lookup (Astra's reproducer,
    // 2026-10-07 — another handle removed an earlier message, this one
    // appended, and the stamped-but-stale index returned the wrong
    // message under the right id).
    const indexWasCurrent =
      this.indexBranchId === this.store.currentBranch().id &&
      this.indexWriteVersion === slotRevision(this.store, this.stateId);
    const cacheWasCurrent = this.cacheIsCurrent();
    noteRevisionBeforeCountedWrite(this.store, this.stateId);
    const version = bumpWriteVersion(this.store, this.stateId, this.log);
    const record = this.store.appendToStateJsonWithIdentity(
      this.stateId,
      partialInternal,
      'id',
      'sequence',
    );
    recordRevisionAfterCountedWrite(this.store, this.stateId);
    const index = this.length() - 1;

    const message: StoredMessage = {
      id: record.id,
      sequence: record.sequence,
      participant,
      content, // Original content with inline data
      metadata,
      timestamp: new Date(partialInternal.timestamp),
      causedBy,
      ...(extra ?? {}),
    };

    // Write-through: keep the materialized cache hot across appends.
    // Ingest-time rebuilds (rebuildChunks in the autobiographical strategy)
    // call getAll() on every new message; without write-through each append
    // invalidates the cache and forces a full state-slot re-materialization
    // — quadratic ingest (2026-07-25 mythos "wedge": ~10s/message at 13.5k
    // messages, event loop starved for hours by ambient traffic + backfill).
    //
    // The cached entry MUST be the chronicle round-trip (serde) form, not a
    // hand-built object: the round trip drops undefined fields, gives a lone
    // surrogate back as U+FFFD and, on chronicle before 0.5.1, sorts keys,
    // and downstream request hashing stringifies message content — a shape
    // that differs between a warm cache and a fresh rebuild breaks hash-keyed
    // dedup (compression in-flight registry, quarantine keys). Fetch the
    // just-written record back through the point lookup; on chronicle
    // versions without it, fall back to plain invalidation (old behavior).
    const canPointLookup =
      typeof (this.store as { getStateItemJson?: unknown }).getStateItemJson === 'function';
    const canonical = canPointLookup ? this.getInternal(index) : null;
    if (
      canonical &&
      cacheWasCurrent &&
      this.allCache &&
      this.allCache.branchId === this.store.currentBranch().id &&
      this.allCache.internals.length === index
    ) {
      this.allCache.internals.push(canonical);
      this.allCache.sequence = this.store.currentSequence();
      // Stamp the post-append write version: this instance made the write,
      // and the cache now reflects it. Without this, the next getAllInternal
      // sees a version mismatch and full-rebuilds on EVERY append — the
      // quadratic ingest this write-through exists to prevent.
      this.allCache.writeVersion = slotRevision(this.store, this.stateId);
      this.allCache.writeCount = currentWriteVersion(this.store, this.stateId);
    } else if (!cacheWasCurrent && this.allCache && this.allCache.branchId === this.store.currentBranch().id) {
      // The cache wasn't current before this append: a sibling wrote since
      // it was built. Where the counted writes since then explain the slot's
      // growth — siblings' appends, and now this one — the cache is extended
      // by point lookup here, so a sibling's append costs no reload; where
      // they don't (an edit or removal, or a write through another handle,
      // which moves slotRevision but no counter), it is dropped, and the next
      // read rebuilds it. Main deferred this to the next read, which on this
      // branch could extend past an uncounted edit (derive.test's surgeon).
      const added = currentWriteVersion(this.store, this.stateId) - 1 - this.allCache.writeCount; // minus this write's own bump
      // Only counted sibling writes can explain the revision's move; none
      // counted, or a gap a counted write saw since the cache was built
      // (noteRevisionBeforeCountedWrite), means an uncounted writer.
      const gapFree = this.allCache.gapCount === currentGapCount(this.store, this.stateId);
      const appended = added > 0 && gapFree ? this.appendedSince(this.allCache.internals, added + 1) : null;
      if (appended) {
        for (const record of appended) this.allCache.internals.push(record);
        this.allCache.sequence = this.store.currentSequence();
        this.allCache.writeVersion = slotRevision(this.store, this.stateId);
        this.allCache.writeCount = currentWriteVersion(this.store, this.stateId);
        this.allCache.gapCount = currentGapCount(this.store, this.stateId);
        cacheDiag(`append write-through extended (cache wasn't current before the append) stateId=${this.stateId} — ${appended.length} appended record(s), this one included, read by point lookup`, this.log);
      } else {
        cacheDiag(`append write-through dropped (cache wasn't current before the append) stateId=${this.stateId} — the writes since don't explain the slot; the next read rebuilds`, this.log);
        this.allCache = null;
      }
    } else {
      if (this.allCache) {
        cacheDiag(
          `append write-through FAILED (${!canPointLookup ? 'no point lookup' : !canonical ? 'canonical null' : `length mismatch cache=${this.allCache.internals.length} index=${index}`}) stateId=${this.stateId} — cache dropped`,
          this.log,
        );
      }
      this.allCache = null;
    }

    if (indexWasCurrent) {
      // This instance made the write and the index reflects it.
      this.idToIndex.set(message.id, index);
      this.indexWriteVersion = slotRevision(this.store, this.stateId);
    }
    // Else: leave the index stale; lookupIndex rebuilds it from the slot.
    this.emit({ type: 'add', message });
    return message;
  }

  /**
   * Refuses a write that would put a system change between a tool call and
   * a result that answers it: a message of changes while one of the nearest
   * calls before it has no result between it and the change, a tool result
   * answering a call that a change already follows, or an edit giving a
   * message a `tool_use` that a change follows before the call's results.
   * The API takes a system message with content only after a user turn, or an
   * assistant turn ending in a server tool result, so membrane sends a change
   * stored after a call after the call's result anyway, and one written after
   * the result goes out the same. Stored between them, a change parts them:
   * the autobiographical and Knowledge strategies keep a change raw and close
   * a chunk at it, so the call and its result would be folded into different
   * summaries, and a compile's pairing repair (enforceToolPairing) would drop
   * the result once the call was folded.
   *
   * It reads back from `index` over changes and messages holding results but
   * no call, to the nearest message that holds a call, reading each message
   * whole, every shard of its body, since ingress sharding puts a message's
   * calls and results on its body's first shard. It checks that message's
   * calls, by id: those a result in a later message answers, as parallel
   * calls' results in messages of their own do, and those its own later
   * blocks answer, as in a bundled cycle (splitMixedToolMessages), are
   * answered. The walk stops at a message of any other kind, so a call no
   * result answered, further back, refuses nothing. `index` is where the
   * content goes: the end for an append, the message's place for an edit.
   *
   * It leaves alone what a write can't see, as main does: a message of
   * another kind between a call and its result, which is already off the
   * API's shape; a call in an earlier message than the nearest one holding
   * a call; a shape that exists only in a view, filtered or merged from
   * several stores; and a removal, or an edit, that takes away a result or a
   * message between. Each parts the pair once the call is folded.
   */
  refuseToolPairSplit(content: ContentBlock[], what: string, index: number = this.length()): void {
    const length = this.length();
    const at = (i: number): StoredMessageInternal | null => (i >= 0 && i < length ? this.getInternal(i) : null);
    // A body is one step of either walk, read whole: ingress sharding puts a
    // message's non-text blocks, its calls and results, on its first shard.
    const bodyAt = (i: number): { from: number; to: number; shards: StoredMessageInternal[] } => {
      const from = bodyStart(at, i);
      const to = bodyEnd(length, at, i);
      const shards: StoredMessageInternal[] = [];
      for (let k = from; k <= to; k++) shards.push(at(k)!);
      return { from, to, shards };
    };
    const holds = (shards: StoredMessageInternal[], type: string): boolean => shards.some((shard) => holdsBlock(shard.content, type));
    const idsIn = (shards: StoredMessageInternal[], type: 'tool_use' | 'tool_result'): string[] =>
      shards.flatMap((shard) => toolIds(shard.content, type));
    const change = holdsBlock(content, 'system_change');
    const answers = change ? [] : toolIds(content, 'tool_result');
    if (change || answers.length > 0) {
      // Back over changes and results, to the nearest body holding a call.
      const answered = new Set<string>();
      let changeBetween: StoredMessageInternal | undefined;
      const calls = new Map<string, MessageId>();
      for (let i = index - 1; i >= 0; ) {
        const { from, shards } = bodyAt(i);
        if (holds(shards, 'tool_use')) {
          // The body's calls left open by its own blocks, read in order
          // across its shards, each by the shard that holds it.
          const holder = new Map<string, MessageId>();
          for (const shard of shards) for (const id of toolIds(shard.content, 'tool_use')) holder.set(id, shard.id);
          for (const [id, open] of callsInOrder(shards.flatMap((shard) => shard.content))) if (open) calls.set(id, holder.get(id)!);
          break;
        }
        if (holds(shards, 'system_change')) changeBetween ??= shards[0];
        else if (holds(shards, 'tool_result')) for (const id of idsIn(shards, 'tool_result')) answered.add(id);
        else break;
        i = from - 1;
      }
      if (calls.size > 0) {
        if (change) {
          const open = [...calls].filter(([id]) => !answered.has(id));
          if (open.length > 0) {
            throw new Error(
              `${what}: a system change can't go between a tool call and its result, and message ${open[0]![1]} holds a tool_use ` +
                `(${open.map(([id]) => id).join(', ')}) with no result between it and this change. Write it after the result, where membrane sends it anyway; for a call that will get none, store a result for it first or remove the call.`,
            );
          }
        } else if (changeBetween) {
          const id = answers.find((answer) => calls.has(answer));
          if (id !== undefined) {
            throw new Error(
              `${what}: a tool_result can't follow a system change (message ${changeBetween.id}) that follows its tool call ` +
                `(${id}, message ${calls.get(id)}). Remove the change and write it after the result.`,
            );
          }
        }
      }
    }
    if (index < length && holdsBlock(content, 'tool_use')) {
      // Forward over changes and results, while a call here is unanswered.
      const open = new Set([...callsInOrder(content)].filter(([, stillOpen]) => stillOpen).map(([id]) => id));
      for (let i = index + 1; i < length && open.size > 0; ) {
        const { to, shards } = bodyAt(i);
        if (holds(shards, 'tool_use')) break;
        if (holds(shards, 'system_change')) {
          throw new Error(
            `${what}: a tool_use (${[...open].join(', ')}) can't go before a system change (message ${shards[0]!.id}) that comes before its result; ` +
              "a change goes after the call's result.",
          );
        }
        if (!holds(shards, 'tool_result')) break;
        for (const id of idsIn(shards, 'tool_result')) open.delete(id);
        i = to + 1;
      }
    }
  }

  /**
   * Edit a message's content.
   *
   * Throws if `messageId` belongs to a bodyGroup (i.e., is a shard of a
   * larger sharded message). Editing one shard would silently corrupt the
   * bodyGroup's byte-faithful reassembly invariant. To replace a sharded
   * message, remove the whole bodyGroup and re-append.
   */
  edit(messageId: MessageId, newContent: ContentBlock[]): void {
    newContent = contentForWrite(newContent, `Edit of ${messageId} refused`);
    const index = this.lookupIndex(messageId);
    if (index === undefined) {
      throw new Error(`Message not found: ${messageId}`);
    }

    const oldMessage = this.getInternal(index);
    if (!oldMessage) {
      throw new Error(`Message not found at index: ${index}`);
    }

    if (oldMessage.bodyGroupId) {
      throw new Error(
        `Cannot edit shard ${messageId}: it is part of bodyGroup ${oldMessage.bodyGroupId}. ` +
          `Sharded messages are immutable — remove the whole bodyGroup and re-append instead.`,
      );
    }
    this.refuseToolPairSplit(newContent, `Edit of ${messageId} refused`, index);

    // The old content as a read gives it, so an edit can replace a message
    // whose stored content doesn't match ContentBlock.
    const oldContent = this.blobManager.resolveBlobs(
      wellFormedContent(oldMessage.content, `message ${messageId}`, this.malformedLogged, this.log),
    );
    const storedContent = this.blobManager.extractBlobs(newContent);

    // Update the stored message
    const updated: StoredMessageInternal = {
      ...oldMessage,
      content: storedContent,
    };

    const cacheWasCurrent = this.cacheIsCurrent();
    noteRevisionBeforeCountedWrite(this.store, this.stateId);
    bumpWriteVersion(this.store, this.stateId, this.log);
    bumpEditVersion(this.store, this.stateId);
    this.store.editStateItem(this.stateId, index, storedJson(updated));
    recordRevisionAfterCountedWrite(this.store, this.stateId);
    this.indexWriteVersion = slotRevision(this.store, this.stateId);

    // Write-through the materialized cache (see append — the cached entry
    // must be the chronicle round-trip form, so re-fetch it canonically).
    const canonicalEdit =
      typeof (this.store as { getStateItemJson?: unknown }).getStateItemJson === 'function'
        ? this.getInternal(index)
        : null;
    if (
      canonicalEdit &&
      this.allCache &&
      this.allCache.branchId === this.store.currentBranch().id &&
      this.allCache.internals[index]
    ) {
      this.allCache.internals[index] = canonicalEdit;
      this.allCache.sequence = this.store.currentSequence();
      // This instance made the write and the cache now reflects it: stamp
      // the new write version, as append does. Otherwise the next read sees
      // a version mismatch and re-materializes the whole slot for a
      // one-message edit — and a store sharing its messages with others
      // (see deriveOnto) would stop sharing them. Only when the cache was
      // current before the write: a sibling instance's earlier edit must
      // still force the rebuild it is owed.
      if (cacheWasCurrent) { this.allCache.writeVersion = slotRevision(this.store, this.stateId); this.allCache.writeCount = currentWriteVersion(this.store, this.stateId); }
    } else {
      this.allCache = null;
    }

    this.emit({ type: 'edit', messageId, oldContent, newContent });
  }

  /**
   * Remove a message from the store.
   *
   * For a sharded message (one shard of a bodyGroup), the caller MUST
   * remove all shards in the group together — removing one shard would
   * orphan the rest and break byte-faithful reassembly. Use
   * `removeBodyGroup(id)` for that case.
   */
  remove(messageId: MessageId): void {
    const index = this.lookupIndex(messageId);
    if (index === undefined) {
      throw new Error(`Message not found: ${messageId}`);
    }

    const target = this.getInternal(index);
    if (target?.bodyGroupId) {
      throw new Error(
        `Cannot remove shard ${messageId} in isolation: it is part of bodyGroup ${target.bodyGroupId}. ` +
          `Use removeBodyGroup(${messageId}) to remove all shards atomically.`,
      );
    }

    const cacheWasCurrent = this.cacheIsCurrent();
    noteRevisionBeforeCountedWrite(this.store, this.stateId);
    bumpWriteVersion(this.store, this.stateId, this.log);
    bumpEditVersion(this.store, this.stateId);
    this.store.redactStateItems(this.stateId, index, index + 1);
    recordRevisionAfterCountedWrite(this.store, this.stateId);
    // Write-through the materialized cache (see append); fall back to
    // invalidation if the cache wasn't current.
    if (
      this.allCache &&
      this.allCache.branchId === this.store.currentBranch().id &&
      this.allCache.internals.length === this.length() + 1
    ) {
      this.allCache.internals.splice(index, 1);
      this.allCache.sequence = this.store.currentSequence();
      // See edit(): stamp our own write so it does not cost a full rebuild.
      if (cacheWasCurrent) { this.allCache.writeVersion = slotRevision(this.store, this.stateId); this.allCache.writeCount = currentWriteVersion(this.store, this.stateId); }
    } else {
      this.allCache = null;
    }
    this.rebuildIndex();

    this.emit({ type: 'remove', messageId });
  }

  /**
   * Remove every shard of the body containing `messageId`: one ingestion,
   * so another copy of the same text, under the same group id, stays (see
   * body-runs.ts). If the message is not part of a body, falls back to
   * single-message remove. Atomic from the caller's perspective.
   */
  removeBodyGroup(messageId: MessageId): void {
    const index = this.lookupIndex(messageId);
    if (index === undefined) {
      throw new Error(`Message not found: ${messageId}`);
    }
    const target = this.getInternal(index);
    if (!target?.bodyGroupId) {
      // Not sharded — defer to normal remove path (re-look up via getInternal
      // since the normal `remove` checks bodyGroupId).
      noteRevisionBeforeCountedWrite(this.store, this.stateId);
      bumpWriteVersion(this.store, this.stateId, this.log);
      bumpEditVersion(this.store, this.stateId);
      this.store.redactStateItems(this.stateId, index, index + 1);
      recordRevisionAfterCountedWrite(this.store, this.stateId);
      this.allCache = null; // rare path: plain invalidation
      this.rebuildIndex();
      this.emit({ type: 'remove', messageId });
      return;
    }
    // Find this body's shards: stored consecutively, one ingestion at a
    // time. Another ingestion of the same text carries the same group id
    // and is another body (see body-runs.ts), so the run stops there.
    const all = this.getAllInternal();
    const { from, to } = bodyBoundsIn(all, index);
    const firstId = all[from].id;
    const lastId = all[to].id;
    noteRevisionBeforeCountedWrite(this.store, this.stateId);
    bumpWriteVersion(this.store, this.stateId, this.log);
    bumpEditVersion(this.store, this.stateId);
    this.store.redactStateItems(this.stateId, from, to + 1);
    recordRevisionAfterCountedWrite(this.store, this.stateId);
    this.allCache = null; // rare path: plain invalidation
    this.rebuildIndex();
    this.emit({ type: 'removeRange', fromId: firstId, toId: lastId });
  }

  /**
   * Remove a range of messages from the store.
   *
   * If the range starts or ends in the middle of a body, throws: removeRange
   * must align to body boundaries. A boundary between two bodies of one
   * group id (two copies of one text) is a body boundary. (Use
   * `removeBodyGroup` to remove one whole body, then call `removeRange` over
   * plain messages.)
   */
  removeRange(fromId: MessageId, toId: MessageId): void {
    const fromIndex = this.lookupIndex(fromId);
    const toIndex = this.lookupIndex(toId);

    if (fromIndex === undefined) {
      throw new Error(`Message not found: ${fromId}`);
    }
    if (toIndex === undefined) {
      throw new Error(`Message not found: ${toId}`);
    }

    // Verify the range doesn't bisect a body: neither edge may sit between
    // two shards of one body. The boundary between two ingestions of the
    // same text (one group id) is not a bisection.
    const all = this.getAllInternal();
    if (fromIndex > 0 && continuesBody(all[fromIndex - 1], all[fromIndex])) {
      throw new Error(
        `removeRange would bisect bodyGroup ${all[fromIndex].bodyGroupId} at start. Use removeBodyGroup(${fromId}) first.`,
      );
    }
    if (toIndex + 1 < all.length && continuesBody(all[toIndex], all[toIndex + 1])) {
      throw new Error(
        `removeRange would bisect bodyGroup ${all[toIndex].bodyGroupId} at end. Use removeBodyGroup(${toId}) first.`,
      );
    }

    noteRevisionBeforeCountedWrite(this.store, this.stateId);
    bumpWriteVersion(this.store, this.stateId, this.log);
    bumpEditVersion(this.store, this.stateId);
    this.store.redactStateItems(this.stateId, fromIndex, toIndex + 1);
    recordRevisionAfterCountedWrite(this.store, this.stateId);
    this.allCache = null; // rare path: plain invalidation
    this.rebuildIndex();

    this.emit({ type: 'removeRange', fromId, toId });
  }

  /**
   * Get a message by ID.
   */
  get(messageId: MessageId): StoredMessage | null {
    const index = this.lookupIndex(messageId);
    if (index === undefined) {
      return null;
    }

    const internal = this.getInternal(index);
    if (!internal) {
      return null;
    }

    return this.internalToStored(internal, messageId, index);
  }

  /**
   * A message's sequence, as `get(id)?.sequence` answers it. While the
   * materialized cache is current (a compile has just listed the slot), it
   * answers from there instead of reading the item through chronicle, which
   * get() does even to report one field (#273).
   */
  sequenceOf(messageId: MessageId): number | undefined {
    const index = this.lookupIndex(messageId);
    if (index === undefined) return undefined;
    const internal = this.cacheIsCurrent() ? this.allCache!.internals[index] : this.getInternal(index);
    return internal?.sequence;
  }

  /**
   * Get a message as it was at a specific sequence (time travel).
   */
  getAt(messageId: MessageId, atSequence: Sequence): StoredMessage | null {
    // Get historical state
    const historicalState = this.store.getStateJsonAt(this.stateId, atSequence);
    if (!historicalState || !Array.isArray(historicalState)) {
      return null;
    }

    // Find the message in historical state
    for (let i = 0; i < historicalState.length; i++) {
      const internal = historicalState[i] as StoredMessageInternal;
      if (internal.id === messageId) {
        return this.internalToStored(internal, messageId, i);
      }
    }

    return null;
  }

  /**
   * Get all messages.
   */
  getAll(): StoredMessage[] {
    const internals = this.getAllInternal();
    // Reuse the mapped StoredMessage[] view when the store is unchanged. A
    // compile calls getAll() ~10-14x with no writes in between; rebuilding the
    // view (internalToStored + resolveBlobs + new Date() per message) each time
    // dominated large moves:0 compiles (Sol, 2026-07-31). Key on the same
    // freshness tokens as allCache: appends bump sequence, edits/redacts bump
    // the shared writeVersion, branch switches change branch ID — any of which
    // misses and rebuilds. The mapped array is immutable to callers, same as
    // getAllInternal's contract.
    const branchId = this.store.currentBranch().id;
    const writeVersion = slotRevision(this.store, this.stateId);
    const c = this.allStoredCache;
    // getAllInternal already revalidates across foreign state writes (the
    // store-global sequence moves on every receipt or resolution write) and
    // hands back the same array; keying on that array, not the sequence,
    // keeps this view alive across them too. Same-instance mutators bump
    // writeVersion (edits in place, appends by push), so both still miss.
    if (
      c &&
      c.branchId === branchId &&
      c.internals === internals &&
      c.writeVersion === writeVersion &&
      c.stored.length === internals.length
    ) {
      return c.stored;
    }
    // Per-message memo (see storedViews): after an append only the new
    // message is converted, and stores sharing internals share the views.
    const stored = internals.map((internal, i) => {
      let view = storedViews.get(internal);
      if (!view) {
        view = this.internalToStored(internal, internal.id, i);
        storedViews.set(internal, view);
      }
      return view;
    });
    this.allStoredCache = { branchId, internals, writeVersion, stored };
    return stored;
  }

  /** Cached mapped view for getAll(), invalidated by the same freshness tokens
   *  as allCache (see getAll). */
  private allStoredCache: {
    branchId: string;
    internals: StoredMessageInternal[];
    writeVersion: number;
    stored: StoredMessage[];
  } | null = null;

  /**
   * Get a window of messages by slot index — O(window), not O(all).
   *
   * Backed by chronicle's `getStateSlice` (0.2.2+) with a
   * full-materialization fallback for older chronicle copies, mirroring
   * the feature-detect in getInternal().
   */
  getWindow(offset: number, limit: number, opts: MessageWindowOptions = {}): MessageWindow {
    const totalCount = this.length();
    let start = Math.max(0, Math.min(offset, totalCount));
    let end = Math.min(start + Math.max(0, limit), totalCount);

    if (start >= end) {
      return { messages: [], startIndex: Math.min(start, totalCount), totalCount };
    }

    if (opts.alignToBodyGroups) {
      // A body's shards are contiguous by construction (removeRange refuses
      // to bisect one). Walk the edges outward with O(item) point lookups to
      // the body boundary, which falls between two ingestions of the same
      // text too (see body-runs.ts).
      const at = (i: number) => this.getInternal(i);
      start = bodyStart(at, start);
      end = bodyEnd(totalCount, at, end - 1) + 1;
    }

    const internals = this.getSliceInternal(start, end - start);
    const resolveBlobs = opts.resolveBlobs !== false;
    return {
      messages: internals.map((internal, i) =>
        this.internalToStored(internal, internal.id, start + i, resolveBlobs)
      ),
      startIndex: start,
      totalCount,
    };
  }

  /**
   * Get messages from a specific index.
   * Negative indices count from the end, matching Array.prototype.slice.
   */
  getFrom(index: number): StoredMessage[] {
    const len = this.length();
    const start = index < 0 ? Math.max(0, len + index) : Math.min(index, len);
    return this.getWindow(start, len - start).messages;
  }

  /**
   * Get the last N messages.
   */
  getTail(count: number): StoredMessage[] {
    const len = this.length();
    const n = Math.max(0, Math.min(count, len));
    return this.getWindow(len - n, n).messages;
  }

  /**
   * Get the total number of messages.
   */
  length(): number {
    return this.store.getStateLen(this.stateId) ?? 0;
  }

  /**
   * Estimate tokens for a message.
   */
  estimateTokens(message: StoredMessage): number {
    const content = message.content;
    const hit = this._messageTokens.get(message);
    if (hit && hit.calibration === this.tokenCalibration && hit.blocks.length === content.length) {
      let same = true;
      for (let i = 0; same && i < content.length; i++) same = hit.blocks[i] === content[i];
      if (same) return hit.tokens;
    }
    let tokens = 0;
    for (const block of content) {
      tokens += this.estimateBlockTokens(block);
    }
    this._messageTokens.set(message, { blocks: content.slice(), calibration: this.tokenCalibration, tokens });
    return tokens;
  }

  /** Whole-message estimate per mapped message object. Guarded by the
   *  identity of every block (a caller may replace one inside the same
   *  content array) and by the calibration factor, so a changed block or a
   *  recalibration never serves a stale sum. Entries die with the message
   *  objects. */
  private _messageTokens = new WeakMap<StoredMessage, {
    blocks: readonly ContentBlock[]; calibration: number; tokens: number;
  }>();

  /**
   * Base token estimate of some content: the sum of each block's raw
   * estimate, before the calibration multiplier and its per-block rounding
   * (which `estimateTokens` applies, so dividing its result by the
   * calibration does not recover this). Identical content estimates the same
   * at any calibration.
   */
  estimateBaseTokens(content: readonly ContentBlock[]): number {
    let tokens = 0;
    for (const block of content) {
      tokens += this.estimateBlockTokensRaw(block);
    }
    return tokens;
  }

  /**
   * Closed-loop calibration multiplier applied to every estimate (default 1).
   * Owned by the strategy: it compares real `usage` totals against the
   * compile-time estimate and feeds the EMA back here, so the store's
   * numbers track the live model/content mix instead of a fixed heuristic.
   */
  private tokenCalibration = 1;

  setTokenCalibration(factor: number): void {
    if (Number.isFinite(factor) && factor > 0.25 && factor < 4) this.tokenCalibration = factor;
  }

  getTokenCalibration(): number {
    return this.tokenCalibration;
  }

  /**
   * Hidden-CoT price for a signed thinking block whose text was summarized/
   * redacted away (2026-07-12): the block estimates as EMPTY client-side, but
   * signed replay bills the FULL original chain of thought. Measured on
   * mythos production turns: median ~608 tokens/block, mean ~590, p90 ~1210.
   * A per-block `tokenEstimate` stamped at creation (from usage residuals)
   * takes precedence; this constant is the fallback for unstamped history.
   */
  static readonly HIDDEN_THINKING_TOKENS_DEFAULT = 600;

  /**
   * Fallback price for a SIGNED thinking block that carries no stamped
   * `tokenEstimate`: `signature.length / SIGNATURE_CHARS_PER_TOKEN`. On
   * keep-all models (Opus >= 4.5, Sonnet >= 4.6, Fable/Mythos) every prior
   * thinking block is replayed as input and billed at the full hidden chain
   * of thought; the signature encodes that chain, so its length is the only
   * client-side trace of the size. Measured 2026-09-21 on Opus 4.8 with
   * `count_tokens` deltas (signed block in vs out of an assistant turn):
   * 2.8-3.4 chars/token for blocks over ~3k tokens, up to ~5-9 for tiny
   * blocks (fixed header dominates). The rate is NOT constant (+-25% at any
   * size), so this is a floor-level estimate for unstamped history only —
   * the exact price is the per-block `tokenEstimate` stamped at creation
   * from the response's `usage.output_tokens` residual (agent-framework).
   * The old flat 600 under-priced agentic history ~10x (a 128-block, ~790k-
   * token replay estimated as 77k), which pinned the calibration multiplier
   * at its ceiling and left the agent at the context ceiling with dead
   * `max_tokens` turns.
   */
  static readonly SIGNATURE_CHARS_PER_TOKEN = 3.3;

  /** Price of a signed thinking block from its signature length alone. */
  static signedThinkingTokens(signature: string): number {
    return Math.round(signature.length / MessageStore.SIGNATURE_CHARS_PER_TOKEN);
  }

  /**
   * Billed-token rate for encrypted reasoning carriers (`redacted_thinking`
   * blocks round-tripped to OpenAI Responses as `reasoning.encrypted_content`).
   * The ciphertext is base64 over an encrypted serialization of the CoT, so
   * blob length tracks billed tokens at a higher chars/token rate than prose.
   * Measured on Sol (gpt-5.6, 2026-07-18) by regressing real `input_tokens`
   * against request content across 12 production calls: residual attributable
   * to carriers = blob_chars / 5.4..8.6, median ~6. With this rate the total
   * estimate lands within ±5% of billed input on every sampled call; with the
   * previous behavior (carriers priced at 0) estimates missed by 23k-75k
   * tokens per call and drove the calibration EMA into a 0.7↔1.5 limit cycle.
   */
  static readonly ENCRYPTED_CARRIER_CHARS_PER_TOKEN = 6;

  /** Per-block cache of the raw (calibration-independent) estimate. */
  private _rawBlockTokens = new WeakMap<ContentBlock, number>();

  private estimateBlockTokens(block: ContentBlock): number {
    return Math.round(this.estimateBlockTokensRaw(block) * this.tokenCalibration);
  }

  /** Cached wrapper for the raw per-block estimate. Keyed on the block object:
   *  blocks are immutable once stored (callers copy before mutating — see the
   *  allCache immutability note), so the same block reused across a compile's
   *  3-4 estimation passes is computed once; edits/redacts produce new block
   *  objects, so the WeakMap auto-invalidates. Calibration is applied on top in
   *  estimateBlockTokens, so cached raw values survive calibration changes.
   *  Removes the repeated JSON.stringify(tool_use.input) / tool_result content
   *  walks that dominated moves:0 compiles at scale (Sol, 2026-07-31). */
  private estimateBlockTokensRaw(block: ContentBlock): number {
    const cached = this._rawBlockTokens.get(block);
    if (cached !== undefined) return cached;
    const raw = this.computeBlockTokensRaw(block);
    this._rawBlockTokens.set(block, raw);
    return raw;
  }

  /**
   * Membrane's XML-history carriers (membrane#101): a `tool_attempt` is the
   * model's own tool-call block that dispatched nothing, replayed verbatim; a
   * `tool_notice` is the harness's notice about refused or warned invokes,
   * replayed as one `<tool_call_notice>` element each, escaped as membrane's
   * formatToolCallNotice escapes it. Both reach the provider
   * as text, so both are priced as the markup they replay as — never 0. Read
   * structurally, so this holds whatever membrane version typed the block.
   * Any other unknown block stays at 0. Shared with ContextLog's estimator,
   * which applies the same uncalibrated rule; the store's calibration still
   * applies on top of its own estimate, as for every block.
   */
  static xmlHistoryCarrierTokens(block: unknown): number {
    const carrier = block as { type?: unknown; rawXml?: unknown; notices?: unknown };
    if (carrier.type === 'tool_attempt' && typeof carrier.rawXml === 'string') {
      return jsonTokenEstimator(carrier.rawXml);
    }
    if (carrier.type === 'tool_notice' && Array.isArray(carrier.notices)) {
      // As membrane's formatToolCallNotice writes it: `&`, `<` and `>` escaped
      // in the message and the tool name, and `"` too in the tool attribute.
      const escapeText = (text: string): string =>
        text.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
      const rendered = carrier.notices
        .map((notice) => {
          const { invoke, toolName, kind, message } = (notice ?? {}) as Record<string, unknown>;
          const tool = escapeText(String(toolName)).replace(/"/g, '&quot;');
          return `<tool_call_notice invoke="${String(invoke)}" tool="${tool}" kind="${String(kind)}">${escapeText(String(message))}</tool_call_notice>`;
        })
        .join('\n');
      return jsonTokenEstimator(rendered);
    }
    return 0;
  }

  private computeBlockTokensRaw(block: ContentBlock): number {
    switch (block.type) {
      case 'text':
        return this.tokenEstimator(block.text);
      case 'thinking': {
        // Stamped price wins. Otherwise a signed block is a FULL chain of
        // thought whatever its visible text says (empty under
        // display:"omitted", a short summary under "summarized", the full
        // text on older models): price it by whichever of the text and the
        // signature is larger — never by a flat constant.
        const stamped = (block as { tokenEstimate?: number }).tokenEstimate;
        if (typeof stamped === 'number') return stamped;
        const signature = (block as { signature?: string }).signature;
        const textTokens = this.tokenEstimator(block.thinking ?? '');
        if (typeof signature === 'string' && signature.length > 0) {
          return Math.max(textTokens, MessageStore.signedThinkingTokens(signature));
        }
        return textTokens;
      }
      case 'redacted_thinking': {
        // Encrypted reasoning carrier: billed in full when replayed. A per-
        // block `tokenEstimate` stamped from usage residuals wins; otherwise
        // price the ciphertext at the measured carrier rate. NEVER 0 — an
        // unpriced carrier population made real/est bimodal and see-sawed the
        // calibration multiplier (see ENCRYPTED_CARRIER_CHARS_PER_TOKEN).
        const stamped = (block as { tokenEstimate?: number }).tokenEstimate;
        if (typeof stamped === 'number') return stamped;
        const data = (block as { data?: string }).data;
        if (typeof data === 'string' && data.length > 0) {
          return Math.round(data.length / MessageStore.ENCRYPTED_CARRIER_CHARS_PER_TOKEN);
        }
        return MessageStore.HIDDEN_THINKING_TOKENS_DEFAULT;
      }
      case 'tool_use':
        return jsonTokenEstimator(JSON.stringify(block.input)) + 20; // overhead for name, id
      case 'tool_result':
        if (!block.content) return 0;
        if (typeof block.content === 'string') {
          return jsonTokenEstimator(block.content);
        }
        if (Array.isArray(block.content)) {
          return block.content.reduce((sum, b) => sum + this.estimateBlockTokensRaw(b), 0);
        }
        return 0;
      case 'image':
        return block.tokenEstimate ?? 1600; // ~1568px image ≈ 1600 tokens (Anthropic)
      // A generated image goes to the provider as an image (membrane converts
      // it), so it is priced as an image without a stamp: membrane's
      // GeneratedImageContent carries no tokenEstimate. Priced at 0, a layout
      // holding one ran larger than its estimate.
      case 'generated_image':
        return 1600;
      case 'document':
      case 'audio':
      case 'video':
        return 1000; // Default estimate for media
      case 'system_change':
        // Its tool definitions and system text go out whole, so it's priced
        // from its JSON, as a tool call's input is.
        return jsonTokenEstimator(JSON.stringify(block));
      default:
        return MessageStore.xmlHistoryCarrierTokens(block);
    }
  }

  /**
   * Create a read-only view of the store for strategies.
   */
  createView(): MessageStoreView {
    return {
      getAll: () => this.getAll(),
      get: (id) => this.get(id),
      sequenceOf: (id) => this.sequenceOf(id),
      getFrom: (index) => this.getFrom(index),
      getTail: (count) => this.getTail(count),
      length: () => this.length(),
      setTokenCalibration: (f: number) => this.setTokenCalibration(f),
      getTokenCalibration: () => this.getTokenCalibration(),
      estimateTokens: (msg) => this.estimateTokens(msg),
    };
  }

  /**
   * Query messages by filter criteria.
   * Useful for finding messages from external sources, by participant, etc.
   */
  query(filter: MessageQuery): MessageQueryResult {
    let messages = this.getAll();
    let totalCount = 0;

    // Apply filters
    const filtered: StoredMessage[] = [];
    for (const msg of messages) {
      if (this.matchesFilter(msg, filter)) {
        filtered.push(msg);
      }
    }

    totalCount = filtered.length;

    // Apply reverse if requested
    let result = filter.reverse ? filtered.reverse() : filtered;

    // Apply limit if specified
    if (filter.limit !== undefined && filter.limit < result.length) {
      result = result.slice(0, filter.limit);
    }

    return { messages: result, totalCount };
  }

  /**
   * Find a message by external source and ID.
   * Convenience method for common lookup pattern.
   */
  findByExternalId(source: string, externalId: string): StoredMessage | null {
    const result = this.query({
      source,
      externalIds: [externalId],
      limit: 1,
    });
    return result.messages[0] ?? null;
  }

  /**
   * Re-register a single field index — the self-heal step `queryIndexOrHeal`
   * takes on a `null` result, after `registerHistoryIndexes` already
   * registered both indexes at construction. `registerStateFieldIndex` is
   * documented idempotent/cheap when the persisted index is already fresh,
   * and does a full rebuild when it isn't (e.g. after the cross-branch
   * poisoning `queryStateIndexRange`'s doc describes) — so re-calling it
   * with the exact same `(stateId, field, kind)` is chronicle's own
   * prescribed recovery path, not a guess. No-ops defensively if the
   * capability has vanished entirely, same as registerHistoryIndexes
   * (shouldn't happen — queryIndexOrHeal is only reached after the caller's
   * own typeof guard on the sibling query method already passed, and the
   * two capabilities land together in one chronicle release).
   */
  private reregisterHistoryIndex(field: string, kind: 'number' | 'string'): void {
    const s = this.store as {
      registerStateFieldIndex?: (stateId: string, field: string, kind: string) => void;
    };
    if (typeof s.registerStateFieldIndex !== 'function') return;
    s.registerStateFieldIndex(this.stateId, field, kind);
  }

  /**
   * Run a native index query that can report `null` — "no such index
   * currently registered" (unregistered, wrong kind, or poisoned by a
   * cross-branch write / parse failure — see queryStateIndexRange's doc) —
   * distinct from an empty array, which is a real "no matches" result and
   * must pass through untouched.
   *
   * Since `registerHistoryIndexes` already registered this index at
   * construction, a `null` here means something disturbed it since. Self-
   * heal: re-register (reregisterHistoryIndex) and retry the query exactly
   * once. If it's STILL `null`, the index is unusable right now — throw
   * HISTORY_INDEX_UNAVAILABLE_MSG rather than let a `null` silently reach
   * `.map()`/`.length` downstream (the bug this helper exists to prevent).
   */
  private queryIndexOrHeal<T>(query: () => T | null, field: string, kind: 'number' | 'string'): T {
    const first = query();
    if (first !== null) return first;
    this.reregisterHistoryIndex(field, kind);
    const second = query();
    if (second !== null) return second;
    throw new Error(HISTORY_INDEX_UNAVAILABLE_MSG);
  }

  /**
   * Capability-checked wrapper over the native numeric-range query call
   * against the `/timestamp` field index. Throws HISTORY_INDEX_UNSUPPORTED_MSG
   * if this chronicle build never has the capability at all (see
   * registerHistoryIndexes); throws HISTORY_INDEX_UNAVAILABLE_MSG if the
   * capability exists but the specific index can't be queried right now
   * even after a self-heal retry (see queryIndexOrHeal). Returns ordinals
   * only — content is fetched separately via ordinalsToMessages.
   */
  private queryTimestampOrdinals(opts: NativeIndexRangeOpts): number[] {
    const s = this.store as {
      queryStateIndexRange?: (stateId: string, field: string, opts: NativeIndexRangeOpts) => number[] | null;
    };
    if (typeof s.queryStateIndexRange !== 'function') {
      throw new Error(HISTORY_INDEX_UNSUPPORTED_MSG);
    }
    return this.queryIndexOrHeal(
      () => s.queryStateIndexRange!(this.stateId, TIMESTAMP_FIELD, opts),
      TIMESTAMP_FIELD,
      'number',
    );
  }

  /**
   * Capability-checked wrapper over the native equality query call,
   * MERGED across both channel-id field-index schemas this store
   * maintains (see the dual-schema block comment on
   * CHANNEL_FIELD_TOP/CHANNEL_FIELD_EXTERNAL) — a message written by real
   * agent-framework ingestion (`metadata.channelId`) and one written under
   * the older `metadata.external.channelId` convention must both be
   * findable by the same `channelId` value. Same throw/ordinal-only
   * contract as queryTimestampOrdinals (including the UNSUPPORTED vs
   * UNAVAILABLE distinction and the self-heal retry, applied independently
   * per field — a poisoned/unregistered CHANNEL_FIELD_TOP index doesn't
   * imply anything about CHANNEL_FIELD_EXTERNAL's state or vice versa).
   *
   * Both native calls are always made UNBOUNDED (native `limit`/`offset`
   * left unset) — this method has no `opts` param at all, unlike
   * queryTimestampOrdinals, precisely because its callers (queryByChannel,
   * queryByTimeAndChannel) always need the FULL merged set to paginate
   * correctly and can't push pagination down into either individual native
   * call. Results are unioned via a Set — a message could in principle
   * carry both schemas at once (a real anomaly, not assumed impossible,
   * just de-duped defensively rather than double-counted) — and sorted
   * ascending. Pagination (if any) is the caller's job. This mirrors
   * queryByTimeAndChannel's own reasoning: native-side pagination on
   * either individual index can't correspond to the correct page of the
   * MERGED result, so the merge has to happen on full ordinal sets before
   * any slicing.
   */
  private queryChannelOrdinals(channelId: string): number[] {
    const s = this.store as {
      queryStateIndexEq?: (stateId: string, field: string, value: string, opts: NativeIndexEqOpts) => number[] | null;
    };
    if (typeof s.queryStateIndexEq !== 'function') {
      throw new Error(HISTORY_INDEX_UNSUPPORTED_MSG);
    }
    const topOrdinals = this.queryIndexOrHeal(
      () => s.queryStateIndexEq!(this.stateId, CHANNEL_FIELD_TOP, channelId, {}),
      CHANNEL_FIELD_TOP,
      'string',
    );
    const externalOrdinals = this.queryIndexOrHeal(
      () => s.queryStateIndexEq!(this.stateId, CHANNEL_FIELD_EXTERNAL, channelId, {}),
      CHANNEL_FIELD_EXTERNAL,
      'string',
    );
    return Array.from(new Set([...topOrdinals, ...externalOrdinals])).sort((a, b) => a - b);
  }

  /**
   * Fetch content for a set of slot ordinals (as returned by the native
   * index queries above) via point lookups — never materializes the whole
   * slot for this. Preserves the input order. An ordinal that no longer
   * resolves (e.g. a redact raced this read) is skipped rather than
   * thrown, matching this file's other defensive-read behavior.
   */
  private ordinalsToMessages(ordinals: number[]): StoredMessage[] {
    const out: StoredMessage[] = [];
    for (const ordinal of ordinals) {
      const internal = this.getInternal(ordinal);
      if (!internal) continue;
      out.push(this.internalToStored(internal, internal.id, ordinal));
    }
    return out;
  }

  /**
   * Query messages by timestamp range — O(log n + k) via the native
   * `/timestamp` index, not a full scan. Both bounds are inclusive; either
   * (or both) may be omitted for an open-ended range.
   *
   * `matchedCount` here is just the returned page's size (`limit`/`offset`
   * are applied natively, inside chronicle, before the ordinals ever cross
   * the NAPI boundary) — NOT a store-wide total match count. Getting a true
   * total would require a second, unbounded native call; queryByTime
   * intentionally avoids that extra cost since most callers page through
   * results and don't need it. Contrast with queryByTimeAndChannel, which
   * already has the full matched set in hand and reports a true total.
   */
  queryByTime(opts: TimeRangeQueryOptions): IndexedMessageQueryResult {
    const ordinals = this.queryTimestampOrdinals({
      gte: opts.fromMs,
      lte: opts.toMs,
      limit: opts.limit,
      offset: opts.offset,
      reverse: opts.reverse,
    });
    return { messages: this.ordinalsToMessages(ordinals), matchedCount: ordinals.length };
  }

  /**
   * Query messages by exact channel id — O(1) hash lookup + O(k) against
   * EACH of the two native channel-id indexes this store maintains, merged
   * (see queryChannelOrdinals and the dual-schema block comment on
   * CHANNEL_FIELD_TOP/CHANNEL_FIELD_EXTERNAL — a message ingested by real
   * agent-framework code, under `metadata.channelId`, and one written
   * under the older `metadata.external.channelId` convention are both
   * findable by the same call). A message with no channelId under EITHER
   * schema (system/autobio-injected messages, etc.) is never indexed for
   * either field (see field_index.rs's `extract_indexed_value`: a
   * missing/wrong-type field extracts to `None`, not the string
   * `"undefined"`), so it can never match here.
   *
   * `matchedCount` is the TRUE total match count across both schemas, not
   * just the returned page's size — unlike queryByTime, which still
   * delegates limit/offset straight into a single native call.
   * queryChannelOrdinals has to fetch both indexes' FULL, unbounded
   * ordinal sets to merge them correctly before any pagination, so the
   * true total is already in hand for free by the time `opts.limit`/
   * `offset` get applied.
   */
  queryByChannel(channelId: string, opts: ChannelQueryOptions = {}): IndexedMessageQueryResult {
    const ordinals = this.queryChannelOrdinals(channelId);
    const start = Math.max(0, Math.min(opts.offset ?? 0, ordinals.length));
    const end =
      opts.limit !== undefined ? Math.min(start + Math.max(0, opts.limit), ordinals.length) : ordinals.length;
    const page = ordinals.slice(start, end);
    return { messages: this.ordinalsToMessages(page), matchedCount: ordinals.length };
  }

  /**
   * Query messages matching BOTH a timestamp range and a channel. With only
   * a channel given, delegates to queryByChannel above (true total
   * `matchedCount`, per its own doc); with only a time range given,
   * delegates to queryByTime (page-size-only `matchedCount`, since that one
   * still uses a single native index with native-side pagination).
   *
   * With BOTH given, this can NOT just pass limit/offset into either native
   * call and filter the resulting page by the other criterion — that
   * paginates against the wrong universe. (Example: page 2 of "channel X in
   * the last hour" needs page 2 of the INTERSECTION of the two filters; a
   * channel-only page 2 filtered down to the last hour would both drop
   * legitimate matches that landed outside that page's channel-only
   * position and include none of the matches that landed on channel-only
   * pages 3+.) The only correct approach is to fetch the FULL, uncapped
   * ordinal set from both the time-range query and queryChannelOrdinals
   * (which itself already merges both channel-id schemas, uncapped) —
   * cheap, since these are plain integer arrays, not content — intersect
   * them, and only THEN apply limit/offset to the intersection. This also
   * means, unlike queryByTime, we already hold the true total match count
   * before slicing, so `matchedCount` here is exact, not page-size-only —
   * same as queryByChannel.
   */
  queryByTimeAndChannel(opts: TimeAndChannelQueryOptions): IndexedMessageQueryResult {
    const hasTime = opts.fromMs !== undefined || opts.toMs !== undefined;
    const hasChannel = opts.channelId !== undefined;

    if (hasChannel && !hasTime) {
      return this.queryByChannel(opts.channelId as string, { limit: opts.limit, offset: opts.offset });
    }
    if (hasTime && !hasChannel) {
      return this.queryByTime({ fromMs: opts.fromMs, toMs: opts.toMs, limit: opts.limit, offset: opts.offset });
    }
    if (!hasTime && !hasChannel) {
      // No filters at all: degenerate case, same shape as an unbounded
      // queryByTime.
      return this.queryByTime({ limit: opts.limit, offset: opts.offset });
    }

    const rangeOrdinals = this.queryTimestampOrdinals({ gte: opts.fromMs, lte: opts.toMs });
    const channelOrdinalSet = new Set(this.queryChannelOrdinals(opts.channelId as string));
    // Intersect, then re-sort ascending: rangeOrdinals comes back sorted by
    // TIMESTAMP VALUE (not necessarily ordinal, if two messages ever share a
    // timestamp or a timestamp were edited out of append order), so a plain
    // filter() would inherit that value order instead of a stable,
    // index-ascending page order. Sorting here keeps pagination
    // deterministic and matches queryByTime/queryByChannel's default
    // (non-reverse) ordinal-ascending order.
    const intersected = rangeOrdinals.filter((o) => channelOrdinalSet.has(o)).sort((a, b) => a - b);

    const start = Math.max(0, Math.min(opts.offset ?? 0, intersected.length));
    const end =
      opts.limit !== undefined
        ? Math.min(start + Math.max(0, opts.limit), intersected.length)
        : intersected.length;

    return { messages: this.ordinalsToMessages(intersected.slice(start, end)), matchedCount: intersected.length };
  }

  /**
   * Distinct channel ids and their message counts across BOTH channel-id
   * schemas this store maintains (see the dual-schema block comment on
   * CHANNEL_FIELD_TOP/CHANNEL_FIELD_EXTERNAL).
   *
   * Does NOT simply sum the two native value-count indexes' counts per
   * channelId — a real, reachable ingestion path double-counts under that
   * approach: agent-framework's `handleMcplChannelIncoming` PRESERVES any
   * incoming `metadata.external` object it's handed while ALSO adding its
   * own top-level `metadata.channelId`, so a message ingested from a
   * source that already carried legacy `{external:{channelId}}` metadata
   * ends up indexed under BOTH `CHANNEL_FIELD_TOP` and
   * `CHANNEL_FIELD_EXTERNAL` for the SAME channelId — one real message,
   * two index entries. Summing the two indexes' counts would report that
   * message twice (2026-09 downstream review finding).
   *
   * Correct approach, reusing already-verified logic rather than inventing
   * new merge math: `queryChannelOrdinals` already unions both indexes'
   * ordinal sets via a `Set` for the exact same reason (queryByChannel
   * already relies on this to avoid double-listing a dual-schema message)
   * — so for each distinct channelId VALUE seen across either index's
   * `getStateIndexValueCounts` (values only, not counts, from this first
   * pass), re-query via `queryChannelOrdinals` and use the de-duplicated
   * ordinal set's length as the true unique message count. This costs one
   * extra native eq-query round-trip per distinct channel value instead of
   * O(1) native value-count calls — acceptable since distinct channel
   * counts are realistically small (tens, not millions) even at
   * Mythos/Sol message-volume scale.
   *
   * Messages with no channelId under either schema are unindexed for both
   * fields (see queryByChannel's doc) and so never appear here — they are
   * excluded, not folded into some `"undefined"` bucket.
   */
  getChannelCounts(): ChannelCount[] {
    const s = this.store as {
      getStateIndexValueCounts?: (stateId: string, field: string) => Array<{ value: string; count: number }> | null;
    };
    if (typeof s.getStateIndexValueCounts !== 'function') {
      throw new Error(HISTORY_INDEX_UNSUPPORTED_MSG);
    }
    const topCounts = this.queryIndexOrHeal(
      () => s.getStateIndexValueCounts!(this.stateId, CHANNEL_FIELD_TOP),
      CHANNEL_FIELD_TOP,
      'string',
    );
    const externalCounts = this.queryIndexOrHeal(
      () => s.getStateIndexValueCounts!(this.stateId, CHANNEL_FIELD_EXTERNAL),
      CHANNEL_FIELD_EXTERNAL,
      'string',
    );
    const distinctChannelIds = new Set<string>();
    for (const vc of topCounts) distinctChannelIds.add(vc.value);
    for (const vc of externalCounts) distinctChannelIds.add(vc.value);

    return Array.from(distinctChannelIds).map((channelId) => ({
      channelId,
      // queryChannelOrdinals already unions both indexes' ordinal sets via
      // a Set (see its own doc) — its length is the true unique count for
      // this channelId, immune to the double-count a raw count-sum hits.
      messages: this.queryChannelOrdinals(channelId).length,
    }));
  }

  /**
   * Per-ordinal cache for getChannelTokenStats, keyed by ordinal (branch
   * identity is tracked separately — see tokenStatsCacheBranchId — rather
   * than folded into the key, since this cache is cheap enough to just
   * wipe wholesale on a branch change instead of carrying dead entries for
   * branches no longer in use).
   *
   * Caches the RAW (calibration-independent) token estimate PER TOP-LEVEL
   * CONTENT BLOCK, not pre-summed for the whole message — mirroring the
   * estimateBlockTokensRaw/estimateBlockTokens split above, and critically
   * matching `estimateTokens`' own per-block round-then-sum order: summing
   * raw block values first and rounding once for the whole message
   * (`round(sum(raw) * factor)`) is NOT generally equal to summing
   * individually-rounded calibrated block estimates
   * (`sum(round(raw * factor))`) for a fractional calibration factor and a
   * multi-block message — e.g. two 1-token raw blocks at calibration 0.6:
   * round(2 * 0.6) = 1, but round(1*0.6) + round(1*0.6) = 1 + 1 = 2, which
   * is what a live `estimateTokens` call actually returns. Storing
   * `rawBlockEstimates` and replaying the exact same per-block
   * round-then-sum at read time (see getChannelTokenStats) keeps the
   * cached and live paths in agreement for every message, not just
   * single-block ones.
   *
   * Values are NOT the calibrated estimate either, for the same reason:
   * `estimateTokens` bakes in the mutable `tokenCalibration` multiplier
   * (see setTokenCalibration), and caching ITS output would freeze each
   * entry at whatever calibration was in effect when first computed —
   * silently mixing calibration generations within one aggregate response,
   * since `setTokenCalibration` is called during normal operation (the
   * autobiographical strategy's closed-loop calibration), not just in
   * synthetic tests. Calibration is applied at READ time instead (see
   * getChannelTokenStats), so every entry always reflects the CURRENT
   * calibration with no invalidation needed when it changes.
   *
   * `channelId: undefined` means "looked up, has no (valid string)
   * channel" (still cached, so a range full of unchanneled messages
   * doesn't get re-decoded every call) as distinct from "not yet looked
   * up" (absent from the map). A non-string channelId value (`null`, a
   * number, …) is normalized to `undefined` here too — see
   * extractChannelId — matching chronicle's native String-kind field
   * index, which silently excludes non-string values rather than exposing
   * them as their own bucket (so byChannel never disagrees with
   * getChannelCounts about which messages are "channeled").
   *
   * There is no native token-estimate index — token estimation isn't a
   * field that exists on stored messages (see the design plan's "Scope
   * decision": indexing it natively would mean either rewriting every
   * historical message to stamp a field that predates the feature, or
   * leaving the index blank for all existing history; neither is
   * acceptable). This cache amortizes the one genuinely expensive part —
   * decoding content (blob resolution) and running raw token estimation —
   * across repeated getChannelTokenStats calls over overlapping ranges,
   * filled lazily only for ordinals actually requested.
   *
   * KNOWN SIMPLIFICATION, not a bug: entries are never evicted or
   * write-through'd on edit/remove within a branch — each entry is a
   * handful of tiny scalars, not message content, so this stays cheap even
   * at hundreds of thousands of messages, nothing like the content-bearing
   * allCache this file guards so carefully elsewhere. Acceptable for a
   * stats/reporting API; revisit if a caller ever needs exactness across
   * live edits.
   */
  private tokenStatsCache = new Map<number, { channelId: string | undefined; rawBlockEstimates: number[] }>();

  /**
   * Branch this cache was last warmed on, tracked by branch ID (NOT name)
   * — checked and enforced at the top of getChannelTokenStats. Chronicle
   * branch names are reusable: a non-current branch can be deleted and a
   * different branch created under the SAME name afterward, but branch ids
   * are never reused (same reasoning chronicle's own native field-index
   * fix uses for its own branch scoping — see registerStateFieldIndex's
   * doc in node_modules/@animalabs/chronicle/index.d.ts). A name-keyed
   * check would miss exactly that delete-and-recreate-under-the-same-name
   * case: the name comparison would see no change and never clear a cache
   * that in fact belongs to a branch that no longer exists. Ordinals are
   * branch-relative (chronicle's native `/timestamp` and dual channel-id
   * field indexes — see CHANNEL_FIELD_TOP/CHANNEL_FIELD_EXTERNAL — are all
   * branch-aware and self-heal across a `switchBranch` as of chronicle
   * 0.4.0), so a cached
   * ordinal→message mapping from one branch isn't just STALE on another,
   * it's WRONG: a diverged branch can reuse the exact same ordinal for a
   * completely different message. Wholesale-cleared on any detected
   * branch-id change rather than keying every cache entry by branch.
   */
  private tokenStatsCacheBranchId = '';

  /**
   * Runtime-validated, DUAL-SCHEMA channelId extraction for the token-stats
   * cache — the content-decode-side equivalent of the two merged native
   * indexes (see the block comment on CHANNEL_FIELD_TOP/CHANNEL_FIELD_EXTERNAL
   * for why there are two: real agent-framework ingestion writes
   * `metadata.channelId` directly, with no `external` nesting, while an
   * older/parallel convention this codebase's MessageQuery type already
   * documents writes `metadata.external.channelId`). Checks the direct
   * field first, falling back to the nested one, so getChannelTokenStats'
   * bucketing agrees with what queryByChannel/getChannelCounts find via
   * the native indexes for the exact same message.
   *
   * Also runtime-validates rather than just type-asserting: the TS cast on
   * `metadata`/`metadata.external` only asserts a shape at compile time, it
   * never checks the actual runtime value, so a `null`/number/etc.
   * channelId would otherwise leak through as a truthy-looking
   * `!== undefined` bucket key in getChannelTokenStats.byChannel — a
   * result the exported `{ channelId: string }` type doesn't even allow.
   * Chronicle's native String-kind indexes silently exclude non-string
   * values (see field_index.rs's `extract_indexed_value`); this matches
   * that so getChannelTokenStats never disagrees with getChannelCounts
   * about which messages are "channeled".
   */
  private extractChannelId(internal: StoredMessageInternal): string | undefined {
    const metadata = internal.metadata;
    if (typeof metadata?.channelId === 'string') return metadata.channelId;
    const external = metadata?.external as { channelId?: unknown } | undefined;
    return typeof external?.channelId === 'string' ? external.channelId : undefined;
  }

  /**
   * Aggregate message counts and token estimates by channel, optionally
   * restricted to a timestamp range. `totalMessages`/`totalTokensEstimate`
   * cover EVERY message in range, channeled or not; `byChannel` breaks down
   * only the ones that have a valid string channelId (so its entries'
   * `messages` sum to <= totalMessages when unchanneled or non-string-
   * channel messages exist in range).
   *
   * Structural filtering rides the native `/timestamp` index (same call as
   * queryByTime, unbounded — every matching ordinal is relevant to the
   * aggregate, so no limit/offset here). Token estimates are computed
   * client-side via the existing raw block-estimation machinery (no native
   * token index — see tokenStatsCache's doc) and cached per-ordinal RAW
   * across calls, with the CURRENT calibration multiplier applied here at
   * read time — see tokenStatsCache's doc for why.
   */
  getChannelTokenStats(opts: ChannelTokenStatsOptions = {}): ChannelTokenStats {
    // Branch-scope the cache before touching it, by ID (see
    // tokenStatsCacheBranchId — NOT name, which chronicle allows reusing
    // after a delete): a stale-branch cache is not just outdated but wrong
    // (ordinal reuse across diverged branches), so this must be a hard
    // wipe, not a lazy per-entry revalidation.
    const currentBranchId = this.store.currentBranch().id;
    if (currentBranchId !== this.tokenStatsCacheBranchId) {
      this.tokenStatsCache.clear();
      this.tokenStatsCacheBranchId = currentBranchId;
    }

    const ordinals = this.queryTimestampOrdinals({ gte: opts.fromMs, lte: opts.toMs });

    const byChannel = new Map<string, { messages: number; tokensEstimate: number }>();
    let totalMessages = 0;
    let totalTokensEstimate = 0;

    for (const ordinal of ordinals) {
      let cached = this.tokenStatsCache.get(ordinal);
      if (!cached) {
        const internal = this.getInternal(ordinal);
        if (!internal) continue; // stale ordinal (e.g. raced a redact); skip rather than throw
        const channelId = this.extractChannelId(internal);
        // Resolve blobs: an un-resolved blob_ref block has no raw estimate
        // of its own and would silently price as 0, undercounting any
        // message carrying inline media — resolveBlobs:true matches how
        // estimateTokens is used everywhere else in this file (getAll()'s
        // default).
        const stored = this.internalToStored(internal, internal.id, ordinal, true);
        const rawBlockEstimates = stored.content.map((block) => this.estimateBlockTokensRaw(block));
        cached = { channelId, rawBlockEstimates };
        this.tokenStatsCache.set(ordinal, cached);
      }
      // Calibration applied HERE, every call, PER BLOCK then summed — never
      // baked into the cached numbers themselves (see tokenStatsCache's
      // doc), and never pre-summed-then-rounded-once: this replays
      // estimateBlockTokens' own round(raw * calibration) for each cached
      // raw block value and sums the results, exactly matching what a live
      // estimateTokens(message) call computes for the same content.
      const tokenEstimate = cached.rawBlockEstimates.reduce(
        (sum, raw) => sum + Math.round(raw * this.tokenCalibration),
        0,
      );
      totalMessages++;
      totalTokensEstimate += tokenEstimate;
      if (cached.channelId !== undefined) {
        const agg = byChannel.get(cached.channelId) ?? { messages: 0, tokensEstimate: 0 };
        agg.messages++;
        agg.tokensEstimate += tokenEstimate;
        byChannel.set(cached.channelId, agg);
      }
    }

    return {
      totalMessages,
      totalTokensEstimate,
      byChannel: Array.from(byChannel.entries()).map(([channelId, agg]) => ({
        channelId,
        messages: agg.messages,
        tokensEstimate: agg.tokensEstimate,
      })),
    };
  }

  /**
   * Check if a message matches the query filter.
   */
  private matchesFilter(msg: StoredMessage, filter: MessageQuery): boolean {
    // Filter by source
    if (filter.source !== undefined) {
      const external = msg.metadata?.external as { source?: string } | undefined;
      if (external?.source !== filter.source) {
        return false;
      }
    }

    // Filter by external IDs
    if (filter.externalIds !== undefined && filter.externalIds.length > 0) {
      const external = msg.metadata?.external as { id?: string } | undefined;
      if (!external?.id || !filter.externalIds.includes(external.id)) {
        return false;
      }
    }

    // Filter by participant
    if (filter.participant !== undefined) {
      if (msg.participant !== filter.participant) {
        return false;
      }
    }

    // Filter by metadata fields
    if (filter.metadata !== undefined) {
      for (const [key, value] of Object.entries(filter.metadata)) {
        const actual = this.getNestedValue(msg.metadata, key);
        if (actual !== value) {
          return false;
        }
      }
    }

    return true;
  }

  /**
   * Get a nested value from an object using dot notation.
   * e.g., getNestedValue(obj, 'external.channelId')
   */
  private getNestedValue(obj: unknown, path: string): unknown {
    if (obj === undefined || obj === null) {
      return undefined;
    }

    const parts = path.split('.');
    let current: unknown = obj;

    for (const part of parts) {
      if (current === undefined || current === null || typeof current !== 'object') {
        return undefined;
      }
      current = (current as Record<string, unknown>)[part];
    }

    return current;
  }

  private getAllInternal(): StoredMessageInternal[] {
    const branchId = this.store.currentBranch().id;
    const sequence = this.store.currentSequence();
    const writeVersion = slotRevision(this.store, this.stateId);
    let missReason = 'no-cache';
    if (this.allCache) {
      missReason =
        this.allCache.branchId !== branchId
          ? `branch ${this.allCache.branchId}→${branchId}`
          : this.allCache.writeVersion !== writeVersion
            ? `writeVersion ${this.allCache.writeVersion}→${writeVersion}`
            : 'revalidate-fail';
    }
    if (this.allCache && this.allCache.branchId === branchId && this.allCache.writeVersion === writeVersion) {
      if (this.allCache.sequence === sequence) {
        return this.allCache.internals;
      }
      // With a slot revision from the store, an unchanged revision IS
      // currency: no write to this slot on this branch happened through
      // any handle. The sequence moved because other states were written.
      if (hasSlotRevision(this.store)) {
        this.allCache.sequence = sequence;
        return this.allCache.internals;
      }
      // The store-global sequence moved, but that may be writes to OTHER
      // state slots (summaries, autobio resolutions, framework/state, …).
      // All in-process mutations of THIS state flow through the mutators
      // above, which write through or invalidate the cache explicitly — so
      // if the messages slot still has the same item count and the same
      // last record id, the cached array is current: re-stamp, don't
      // re-materialize. (A full re-materialization here on every foreign
      // append made ingest quadratic — 2026-07-25 mythos wedge.)
      // Feature-detect getStateItemJson (chronicle >= 0.2.2): the fallback
      // inside getInternal() is getAllInternal() itself — calling it here
      // on an older chronicle would recurse. No point lookup → no cheap
      // revalidation → keep the old full-rebuild behavior.
      const canPointLookup =
        typeof (this.store as { getStateItemJson?: unknown }).getStateItemJson === 'function';
      const count = canPointLookup ? this.length() : -1;
      if (count === this.allCache.internals.length) {
        if (count === 0) {
          this.allCache.sequence = sequence;
          return this.allCache.internals;
        }
        const lastCached = this.allCache.internals[count - 1];
        const lastLive = this.getInternal(count - 1);
        if (
          lastCached &&
          lastLive &&
          lastLive.id === lastCached.id &&
          lastLive.sequence === lastCached.sequence
        ) {
          this.allCache.sequence = sequence;
          return this.allCache.internals;
        }
        missReason = `revalidate-fail last-item (cached ${lastCached?.id}/${lastCached?.sequence} live ${lastLive?.id}/${lastLive?.sequence})`;
      } else {
        missReason = `revalidate-fail count (cached ${this.allCache.internals.length} live ${count}${canPointLookup ? '' : ', no point lookup'})`;
      }
    }
    // Only appends since the cache was built, through any MessageStore on
    // this store: the slot grew by exactly the write versions moved
    // (bumpWriteVersion). The appended records are then read by point lookup
    // and added, rather than the slot re-materialized for a sibling's append
    // (#251). The cached records aren't looked up to confirm them: on
    // chronicle 0.4.0, a point lookup of any record but the newest after a
    // write rebuilds chronicle's per-item cache, which a read after one
    // append then avoids. Like the count-and-tail check above, this relies
    // on the slot being written only through MessageStore. A write outside
    // it moves no version, so where it adds a record beside a sibling's edit
    // or removal, the length comes out as the versions predict: the cache is
    // extended stale, and an edit or removal through its index can reach
    // another record.
    // On this branch the freshness token is slotRevision (chronicle's log
    // offset, which any writer moves), so the number of writes since the
    // cache was built comes from main's in-process counter beside it. A
    // revision that moved with no counted write is a write from outside this
    // process's MessageStores, which may be anything: reload.
    const writeCount = currentWriteVersion(this.store, this.stateId);
    if (this.allCache && this.allCache.branchId === branchId && this.allCache.writeVersion !== writeVersion) {
      const added = writeCount - this.allCache.writeCount;
      // Two tells of an uncounted write: a counted write since the cache saw a
      // gap (gapCount), or the slot's revision isn't the one the last counted
      // write left (an uncounted write after it). Either way, rebuild.
      const gapFree = this.allCache.gapCount === currentGapCount(this.store, this.stateId)
        && revisionLeftByLastCountedWrite(this.store, this.stateId) === writeVersion;
      const appended = added > 0 && gapFree ? this.appendedSince(this.allCache.internals, added) : null;
      if (appended) {
        for (const record of appended) this.allCache.internals.push(record);
        this.allCache.writeVersion = writeVersion;
        this.allCache.writeCount = writeCount;
        this.allCache.gapCount = currentGapCount(this.store, this.stateId);
        this.allCache.sequence = sequence;
        return this.allCache.internals;
      }
      missReason = `${missReason}, not appends only (cached ${this.allCache.internals.length} + ${added} writes, live ${this.length()})`;
    }
    const _t = CACHE_DIAG ? Date.now() : 0;
    const state = this.store.getStateJson(this.stateId);
    const internals =
      !state || !Array.isArray(state) ? [] : (state as StoredMessageInternal[]);
    this.allCache = { branchId, sequence, internals, writeVersion, writeCount, gapCount: currentGapCount(this.store, this.stateId) };
    cacheDiag(`getAllInternal MISS (${missReason}) stateId=${this.stateId} rebuilt ${internals.length} in ${Date.now() - _t}ms`, this.log);
    return internals;
  }

  /**
   * The `added` records appended to the slot after `cached`, an earlier
   * materialization of it, by point lookup; null where they can't be read
   * that way: a slot whose length isn't `cached`'s plus `added`, a record
   * that won't read, or a chronicle without point lookup, where getInternal
   * falls back to getAllInternal itself.
   */
  private appendedSince(cached: readonly StoredMessageInternal[], added: number): StoredMessageInternal[] | null {
    if (typeof (this.store as { getStateItemJson?: unknown }).getStateItemJson !== 'function') return null;
    const count = this.length();
    if (count !== cached.length + added) return null;
    const appended: StoredMessageInternal[] = [];
    for (let i = cached.length; i < count; i++) {
      const record = this.getInternal(i);
      if (!record) return null;
      appended.push(record);
    }
    return appended;
  }

  private getSliceInternal(offset: number, limit: number): StoredMessageInternal[] {
    // Windowed read — O(window) JSON conversion instead of materializing
    // the entire state slot. getStateSlice landed in chronicle 0.2.2 and
    // returns the window as a JSON-array Buffer; feature-detect so boxes
    // on <= 0.2.1 fall back to full materialization (same pattern as
    // getInternal below).
    const s = this.store as { getStateSlice?: (id: string, offset: number, limit: number) => Buffer | null };
    if (typeof s.getStateSlice === 'function') {
      const buf = s.getStateSlice(this.stateId, offset, limit);
      if (!buf) return [];
      return JSON.parse(buf.toString('utf-8')) as StoredMessageInternal[];
    }
    return this.getAllInternal().slice(offset, offset + limit);
  }

  private getInternal(index: number): StoredMessageInternal | null {
    // Point lookup through chronicle's per-item cache — O(item size).
    // Never fetch the full state for a single index: with a 4.6k-message
    // session, each full `getStateJson` materialization cost ~15ms, and
    // per-entry get() loops turned renders into minutes (observed on
    // Lena, 2026-07-02, /debug/context at 51–108s).
    //
    // Feature-detect: getStateItemJson landed in chronicle 0.2.2; boxes
    // still on <= 0.2.1 (npm copies) fall back to the full-materialization
    // path so a routine `git pull` of this package can never crash them.
    if (typeof (this.store as { getStateItemJson?: unknown }).getStateItemJson === 'function') {
      const item = this.store.getStateItemJson(this.stateId, index);
      return (item as StoredMessageInternal | null) ?? null;
    }
    const all = this.getAllInternal();
    return all[index] ?? null;
  }

  private internalToStored(
    internal: StoredMessageInternal,
    id: MessageId,
    _index: number,
    resolveBlobs: boolean = true,
  ): StoredMessage {
    // What doesn't match ContentBlock is left out before anything reads it,
    // blob resolution included (well-formed-content.ts).
    const content = wellFormedContent(internal.content, `message ${id}`, this.malformedLogged, this.log);
    const stored: StoredMessage = {
      id,
      // chronicle record sequence captured when the message was appended
      // (see `add()` line 131: `sequence: record.sequence`). The previous
      // implementation returned the slot index ("// Use index as sequence
      // for now"), which silently corrupted any downstream code that
      // forwarded this number to chronicle APIs expecting a real sequence
      // — most notably `ContextManager.branchAt`, which would fork the
      // chronicle at the index-mistaken-for-sequence and lose every
      // record between the intended fork point and the actual one. For
      // typical autobio sessions the index-vs-sequence ratio is ~1:2
      // (each message append is accompanied by ~1 autobio state update),
      // so /undo of a 800-message conversation forked ~400 messages back.
      sequence: internal.sequence,
      participant: internal.participant,
      // When resolveBlobs is false, blob_ref placeholder blocks are passed
      // through un-inflated (StoredContentBlock ⊂ wire-safe superset of
      // ContentBlock for viewer purposes).
      content: resolveBlobs
        ? this.blobManager.resolveBlobs(content)
        : (content as unknown as ContentBlock[]),
      metadata: internal.metadata,
      timestamp: new Date(internal.timestamp),
      causedBy: internal.causedBy,
    };
    // Carry adaptive-resolution fields through unchanged.
    if (internal.bodyGroupId !== undefined) stored.bodyGroupId = internal.bodyGroupId;
    if (internal.shardIndex !== undefined) stored.shardIndex = internal.shardIndex;
    if (internal.shardCount !== undefined) stored.shardCount = internal.shardCount;
    if (internal.currentResolution !== undefined) stored.currentResolution = internal.currentResolution;
    if (internal.lockedByAgent !== undefined) stored.lockedByAgent = internal.lockedByAgent;
    return stored;
  }
}

/**
 * Default token estimator: chars / 4
 */
/**
 * Content-class token rates (2026-07-12, measured on mythos production
 * requests by reconciling real `usage` against per-class char counts):
 *   - prose (Discord multiparty, markdown, emoji)  ≈ 2.9 chars/token
 *   - JSON / tool i/o / code                        ≈ 2.3 chars/token
 * The old flat chars/4 under-priced real windows by ~1.7-1.9x (a 183.6k
 * "hard budget" compiled to a 344k request — straight into the refusal
 * band). Rates are deliberately slightly conservative; the closed-loop
 * calibration multiplier trims the residual per agent.
 */
const PROSE_CHARS_PER_TOKEN = 2.9;
const DENSE_CHARS_PER_TOKEN = 2.3;

export function defaultTokenEstimator(text: string): number {
  if (!text) return 0;
  // Cheap density probe: JSON/code punctuation and non-ASCII share.
  let dense = 0;
  const n = Math.min(text.length, 2000);
  for (let i = 0; i < n; i++) {
    const c = text.charCodeAt(i);
    if (c > 126) { dense++; continue; } // non-ASCII (emoji, accents, CJK)
    const ch = text[i];
    if (ch === '{' || ch === '}' || ch === '[' || ch === ']' || ch === '"' || ch === ':' || ch === '_' || ch === '/' || ch === '=' || ch === '`') dense++;
  }
  const rate = dense / n > 0.12 ? DENSE_CHARS_PER_TOKEN : PROSE_CHARS_PER_TOKEN;
  return Math.ceil(text.length / rate);
}

/** JSON-ish payloads (tool inputs/results) always use the dense rate. */
export function jsonTokenEstimator(text: string): number {
  if (!text) return 0;
  return Math.ceil(text.length / DENSE_CHARS_PER_TOKEN);
}
