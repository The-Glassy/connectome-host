/**
 * An append-only journal of typed Chronicle records that does not follow
 * branch switches.
 *
 * Chronicle's branch state — snapshot, tree and log states — rewinds with a
 * historical rollback (createBranchAt + switchBranch). Typed records do not:
 * `getRecordIdsByType` enumerates them from every branch, in global order, and
 * they survive `deleteBranch`, reopen and a hard kill. A journal is for state
 * that must not rewind with the conversation but should live and die with its
 * store: what a workspace's disk last agreed with, what reached a recipient,
 * what became of a suppressed draft.
 *
 * Durability. A record append reaches the OS before `append` returns, so it
 * survives a killed process, while branch-state commits are buffered until
 * `store.sync()`: a record appended after a state commit can outlive that
 * commit. Two barriers, each named where it's needed and neither implied by
 * the `{id, sequence}` an append returns:
 *  - `afterCommittedState: true` syncs BEFORE appending — for an entry that
 *    asserts state committed just before it, so the entry can never survive
 *    without that state;
 *  - `durable: true` syncs AFTER appending — for an entry that must be on
 *    stable storage before the caller acts on it (an attempt before its
 *    outbound request, an intent before its disk effect).
 *
 * Checkpoints bound the replay at open: `checkpoint(snapshot)` records the
 * caller's reduced state together with the last entry it covers, and `load()`
 * returns the latest checkpoint's snapshot plus only the entries appended
 * after it. A journal that never checkpoints replays everything. What entries
 * mean, how they reduce, and when to checkpoint stay with the caller.
 *
 * One writer per record type: a checkpoint covers every entry up to the last
 * one THIS journal loaded or appended, so entries another instance appended
 * to the same type in between would be covered without being reduced.
 *
 * An ambiguous write must be resolved before the journal writes again. Once
 * `append` or `checkpoint` has handed a record to the store, a failure leaves
 * a record the caller didn't reduce, or may leave one, and a later checkpoint
 * would cover it without its ever entering the reducer. There are two kinds:
 *  - The store's append itself throws. Its record may still be in the store's
 *    log, outside this process's view of the store: the store writes a
 *    record to its log, syncs the log every so often, and only then indexes
 *    the record, which is what `getRecordIdsByType` reads. So a failed sync
 *    leaves a record that reopening the store will find and no `load()` on
 *    this store can. Nothing but a reopen rereads the log, so from then on
 *    every `append` and `checkpoint` throws, for the life of the journal. A
 *    journal on the store reopened, as at the next start, loads that record
 *    with its tail for the caller to reduce.
 *  - A failure after the append returned: a `durable` barrier, or reading
 *    the id it returned. The record is in this process's view, so every
 *    further `append` and `checkpoint` throws until `load()` has replayed the
 *    tail, that record included, for the caller to reduce.
 * A failure BEFORE the record reaches the store (the `afterCommittedState`
 * sync) wrote nothing and leaves the journal usable.
 */

import type { JsStore } from '@animalabs/chronicle';

/** Where an appended record landed. Not a durability receipt — see the barriers. */
export interface JournalRecordRef {
  /** Chronicle record id: global, increasing in append order. */
  id: string;
  /** The record's sequence on the branch current when it was appended. */
  sequence: number;
}

export interface JournalEntry<Entry> extends JournalRecordRef {
  entry: Entry;
}

export interface JournalLoad<Entry, Snapshot> {
  /** The latest checkpoint's snapshot, or null when none was written. */
  snapshot: Snapshot | null;
  /** Every entry appended after that checkpoint, in append order. */
  entries: Array<JournalEntry<Entry>>;
}

export interface AppendOptions {
  /** `store.sync()` before appending: the entry asserts state committed just before it. */
  afterCommittedState?: boolean;
  /** `store.sync()` after appending: the entry must be on stable storage before the caller acts. */
  durable?: boolean;
}

interface CheckpointPayload<Snapshot> {
  /** Id of the last entry the snapshot covers ("0" when it covers none). */
  through: string;
  snapshot: Snapshot;
}

const asError = (err: unknown): Error => (err instanceof Error ? err : new Error(String(err)));

/** Record ids are decimal strings from one store-wide counter. */
function idValue(id: string): bigint {
  if (!/^\d+$/.test(id)) throw new Error(`RecordJournal: unexpected chronicle record id "${id}"`);
  return BigInt(id);
}

function decode<T>(store: JsStore, id: string): { value: T; sequence: number } {
  const record = store.getRecord(id);
  if (!record) throw new Error(`RecordJournal: record ${id} is listed but cannot be read`);
  return { value: JSON.parse(Buffer.from(record.payload).toString('utf-8')) as T, sequence: record.sequence };
}

export class RecordJournal<Entry, Snapshot = never> {
  private readonly store: JsStore;
  /** Record type of the entries. */
  readonly type: string;
  /** Record type of the checkpoints. */
  readonly checkpointType: string;
  /** Highest entry id this journal has loaded or appended (0 when none). */
  private lastEntryId = 0n;
  private sinceCheckpoint = 0;
  /** Set by a failure after the store's append returned; cleared by load(). */
  private unreconciled: Error | null = null;
  /** Set when the store's append itself threw: its record may be in the log
   *  but not in this process's view of the store. Never cleared. */
  private unreadable: Error | null = null;

  constructor(store: JsStore, opts: { type: string; checkpointType?: string }) {
    if (!opts.type) throw new Error('RecordJournal: a record type is required');
    this.store = store;
    this.type = opts.type;
    this.checkpointType = opts.checkpointType ?? `${opts.type}/checkpoint`;
    if (this.checkpointType === this.type) {
      throw new Error('RecordJournal: entries and checkpoints need distinct record types');
    }
  }

  /** Entries appended since the last checkpoint (or since load, when there was none). */
  get entriesSinceCheckpoint(): number {
    return this.sinceCheckpoint;
  }

  /**
   * The latest checkpoint and every entry after it, whichever branch each was
   * appended on. The caller rebuilds its reduced state from exactly these —
   * at open, and to reconcile after an ambiguous write. Also positions the
   * journal, so later checkpoints cover what was loaded.
   */
  load(): JournalLoad<Entry, Snapshot> {
    let snapshot: Snapshot | null = null;
    let through = 0n;
    let latestCheckpoint: bigint | null = null;
    let latestCheckpointId: string | null = null;
    for (const id of this.store.getRecordIdsByType(this.checkpointType)) {
      const value = idValue(id);
      if (latestCheckpoint === null || value > latestCheckpoint) {
        latestCheckpoint = value;
        latestCheckpointId = id;
      }
    }
    if (latestCheckpointId !== null) {
      const payload = decode<CheckpointPayload<Snapshot>>(this.store, latestCheckpointId).value;
      snapshot = payload.snapshot;
      through = idValue(payload.through);
    }

    const tail = this.store.getRecordIdsByType(this.type)
      .map((id) => ({ id, value: idValue(id) }))
      .filter(({ value }) => value > through)
      .sort((a, b) => (a.value < b.value ? -1 : a.value > b.value ? 1 : 0));
    const entries = tail.map(({ id }) => {
      const { value, sequence } = decode<Entry>(this.store, id);
      return { id, sequence, entry: value };
    });

    this.lastEntryId = tail.length > 0 ? tail[tail.length - 1]!.value : through;
    this.sinceCheckpoint = entries.length;
    this.unreconciled = null;
    return { snapshot, entries };
  }

  /** True after a failure that load() can resolve, until it has replayed the
   *  tail. An append that threw inside the store is never resolved here: the
   *  journal stays unwritable until a journal on the reopened store loads it. */
  get needsReconcile(): boolean {
    return this.unreconciled !== null;
  }

  /** True once an append threw inside the store, for the rest of the
   *  journal's life. What `load()` returns may then lack that append's record,
   *  so a caller that decides from the journal's contents can't trust them
   *  until a journal on the reopened store has loaded it. */
  get needsReopen(): boolean {
    return this.unreadable !== null;
  }

  /** Append one entry. The returned ref says where it landed, not that it's durable. */
  append(entry: Entry, opts: AppendOptions = {}): JournalRecordRef {
    this.assertReconciled();
    if (opts.afterCommittedState) this.store.sync();
    return this.write(this.type, entry, opts.durable === true, (ref) => {
      const value = idValue(ref.id);
      if (value > this.lastEntryId) this.lastEntryId = value;
      this.sinceCheckpoint++;
    });
  }

  /**
   * Record the caller's reduced state as covering every entry this journal has
   * loaded or appended. Like an entry, it's durable only with `durable`.
   */
  checkpoint(snapshot: Snapshot, opts: { durable?: boolean } = {}): JournalRecordRef {
    this.assertReconciled();
    const payload: CheckpointPayload<Snapshot> = { through: this.lastEntryId.toString(), snapshot };
    return this.write(this.checkpointType, payload, opts.durable === true, () => {
      this.sinceCheckpoint = 0;
    });
  }

  /** Hand one record to the store; any failure from here on is ambiguous. */
  private write(type: string, payload: unknown, durable: boolean, onWritten: (ref: JournalRecordRef) => void): JournalRecordRef {
    let record: { id: string; sequence: number };
    try {
      record = this.store.appendJson(type, payload);
    } catch (err) {
      this.unreadable = asError(err);
      throw err;
    }
    try {
      const ref = { id: record.id, sequence: record.sequence };
      onWritten(ref);
      if (durable) this.store.sync();
      return ref;
    } catch (err) {
      this.unreconciled = asError(err);
      throw err;
    }
  }

  private assertReconciled(): void {
    if (this.unreadable) {
      throw new Error(
        `RecordJournal(${this.type}): an earlier append failed inside the store ` +
        `(${this.unreadable.message}), and its record may be in the store's log where this process can't ` +
        `read it back; nothing more is written until the store is reopened, as at the next start`,
      );
    }
    if (this.unreconciled) {
      throw new Error(
        `RecordJournal(${this.type}): an earlier write failed after reaching the store ` +
        `(${this.unreconciled.message}); load() and reduce its tail before writing again`,
      );
    }
  }
}
