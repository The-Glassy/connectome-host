/**
 * MCPL (MCP Live) Protocol Types — v0.4.0-draft
 *
 * Type definitions for the host-side implementation of the MCPL protocol.
 * Organized by spec section for easy cross-referencing with mcpl/SPEC.md.
 *
 * Naming conventions:
 *   - Types prefixed with `Mcpl` when they collide with existing framework/membrane
 *     types (e.g., McplContentBlock vs membrane's ContentBlock, McplModelInfo vs
 *     membrane's ModelInfo, McplInferenceRequestParams vs API's InferenceRequestParams).
 *   - All other types use plain names — they live in the mcpl/ module and are
 *     unambiguous when imported from here.
 */

// ============================================================================
// JSON-RPC 2.0 (Transport Layer)
// ============================================================================

/**
 * JSON-RPC 2.0 request. Notifications omit `id`.
 */
export interface JsonRpcRequest {
  jsonrpc: '2.0';
  method: string;
  id?: string | number;
  params?: Record<string, unknown>;
}

/**
 * JSON-RPC 2.0 successful response.
 */
export interface JsonRpcResponse {
  jsonrpc: '2.0';
  id: string | number;
  result?: unknown;
  error?: JsonRpcError;
}

/**
 * JSON-RPC 2.0 error object.
 */
export interface JsonRpcError {
  code: number;
  message: string;
  data?: unknown;
}

// ============================================================================
// Section 4 — MCPL Content Blocks (Wire Format)
// ============================================================================
// These represent content as it travels over the MCPL protocol.
// They differ from membrane's ContentBlock (which is LLM-provider-oriented).
// Conversion between McplContentBlock and membrane ContentBlock happens in
// the host when bridging protocol ↔ inference pipeline.

export type McplContentBlock =
  | McplTextContent
  | McplImageContent
  | McplAudioContent
  | McplResourceContent;

export interface McplTextContent {
  type: 'text';
  text: string;
}

export interface McplImageContent {
  type: 'image';
  /** Base64-encoded image data (present when using inline form) */
  data?: string;
  /** MIME type (present when using inline form) */
  mimeType?: string;
  /** URI reference (present when using URI form) */
  uri?: string;
  /** RFC-005 reference testimony (uri form only). */
  sizeBytes?: number;
  digest?: string;
  expiresAt?: string;
  name?: string;
  disposition?: 'never' | 'ref';
}

export interface McplAudioContent {
  type: 'audio';
  /** Base64-encoded audio data (present when using inline form) */
  data?: string;
  /** MIME type (present when using inline form) */
  mimeType?: string;
  /** URI reference (present when using URI form) */
  uri?: string;
  /** RFC-005 reference testimony (uri form only). */
  sizeBytes?: number;
  digest?: string;
  expiresAt?: string;
  name?: string;
  disposition?: 'never' | 'ref';
}

/** MCPL's reference block (RFC-005 §3). A `resource` block with no `uri` of
 *  its own may be MCP's embedded resource instead, its contents under
 *  `resource`, which classifyBlock tells apart and shows as its contents. */
export interface McplResourceContent {
  type: 'resource';
  /** Resource URI (e.g., "memory://facts/12345") */
  uri: string;
  /** RFC-005 §3 reference testimony (all optional, all server claims). */
  mimeType?: string;
  sizeBytes?: number;
  digest?: string;
  expiresAt?: string;
  name?: string;
  disposition?: 'never' | 'ref';
}

// ============================================================================
// Section 5 — Capability Negotiation
// ============================================================================

/**
 * MCPL capabilities as advertised by a server in `experimental.mcpl`.
 * Parsed from the server's `initialize` response.
 */
export interface McplCapabilities {
  /** MCPL protocol version (e.g., "0.5") */
  version: string;

  /** §17.2 canonical content digest; absent = manifest fixed at initialize. */
  revision?: string;

  /** Server supports push/event */
  pushEvents?: boolean;

  /**
   * Context hooks — §5.1 recursive shape. Boolean `true` at any level is
   * shorthand for every leaf beneath it. `afterInference` is REMOVED in
   * 0.5.0 (replaced by metadata-only inference/lifecycle, §10.5).
   */
  contextHooks?: {
    beforeInference?: boolean | {
      observe?: boolean;
      inject?: { system?: boolean; beforeUser?: boolean; afterUser?: boolean };
    };
  };

  /** Server-initiated inference. `true` = the capability with no refinements. */
  inferenceRequest?: boolean | { streaming?: boolean };

  /** Server consumes inference/lifecycle notifications (§10.5). */
  inferenceLifecycle?: boolean;

  /** RFC-007 tool lifecycle: observe (metadata) and inputs (requested
   *  argument fields). `true` = both leaves. */
  toolLifecycle?: boolean | { observe?: boolean; inputs?: boolean };

  /** Server supports model/info requests */
  modelInfo?: boolean;

  /** Declared feature sets (keyed by feature set name) */
  featureSets?: Record<string, FeatureSetDeclaration>;

  /** Channel capabilities — §14.1 object of leaves, or `true` for all. */
  channels?: boolean | McplChannelCapabilities;
}

/**
 * MCPL capabilities that the host advertises to servers.
 * Sent in the host's `initialize` response under `capabilities.experimental.mcpl`.
 */
export interface McplHostCapabilities {
  version: string;
  /** RFC-006 support, independent of capability grants. */
  eventCoalescing?: boolean | {
    pushEvents?: boolean;
    channelsIncoming?: boolean;
    deferred?: boolean;
    channelScopedPush?: boolean;
    /** Retry-window guarantee in ms (integer ≥ 3,600,000; default 3,600,000). */
    retryWindowMs?: number;
  };
  pushEvents?: boolean;
  contextHooks?: {
    beforeInference?: boolean | {
      observe?: boolean;
      inject?: { system?: boolean; beforeUser?: boolean; afterUser?: boolean };
    };
  };
  inferenceRequest?: boolean | { streaming?: boolean };
  inferenceLifecycle?: boolean;

  /** RFC-007 tool lifecycle: observe (metadata) and inputs (requested
   *  argument fields). `true` = both leaves. */
  toolLifecycle?: boolean | { observe?: boolean; inputs?: boolean };
  modelInfo?: boolean;
  featureSets?: boolean;
  channels?: boolean | McplChannelCapabilities;
  /** RFC-014 §6.3: this host presents tool hints. Sent to every server
   *  with hints (McplServerConfig.toolHints: on unless false). */
  toolHints?: boolean;
}

/** Channel capability leaves (§14.1). `observe` was the pre-0.5 name for
 *  what split into `incoming` — removed, not aliased. */
export interface McplChannelCapabilities {
  register?: boolean;
  lifecycle?: boolean;
  publish?: boolean;
  incoming?: boolean;
  streaming?: boolean;
  acknowledge?: boolean;
  typing?: boolean;
}

// ============================================================================
// Section 5 — Server Configuration (Host-Side)
// ============================================================================

/**
 * Configuration for connecting to a single MCPL server.
 * Provided in FrameworkConfig.mcplServers[].
 *
 * Treat a submitted configuration and its nested values as immutable for as
 * long as the server uses them. Apply changed settings with
 * `restartMcplServer(id, newConfig)`; use `accessProvider` for a network
 * server's rotating credentials (a stdio server's changed `env` goes through
 * a restart with the new configuration).
 */
export interface McplServerConfig {
  /** Unique server identifier */
  id: string;

  /**
   * Command to spawn the server process (stdio transport). Required for the
   * stdio transport; omit it (and set `url`) for a network server, over
   * WebSocket or HTTP. A configuration with both needs `transport` to say
   * which one is used, and is refused without it.
   */
  command?: string;

  /** Arguments for the command */
  args?: string[];

  /**
   * Environment variables for the child process. Stdio children do NOT inherit
   * the host environment wholesale: they get a small allowlist (PATH, HOME,
   * LANG, LC_*, TMPDIR, TLS CA bundles, and HTTP(S) proxy settings — see
   * CHILD_ENV_ALLOWLIST) plus exactly these. Proxy URLs can contain credentials.
   * This limits accidental inheritance; it does not isolate a hostile child.
   */
  env?: Record<string, string>;

  /**
   * Escape hatch: pass the host's entire environment (including secrets) to
   * the stdio child, as older versions did. Only for servers that genuinely
   * need it. Default false. Only `true` turns it on, and null counts as not
   * set. For a stdio server, `create()`, `connectMcplServer` and
   * `restartMcplServer` refuse any other value, such as a quoted "false". A
   * WebSocket server never reads it.
   */
  inheritEnv?: boolean;

  /**
   * URL for a network server, used instead of `command`. A configuration
   * with both needs `transport` to say which one is used, and is refused
   * without it. Its scheme decides the protocol family:
   * - `ws://` or `wss://` is a legacy MCPL server over MCPL's WebSocket
   *   binding. The host dials it and runs the same newline-delimited JSON-RPC
   *   as over stdio.
   * - `http://` or `https://` is a modern MCP (2026-07-28) server over
   *   Streamable HTTP.
   */
  url?: string;

  /**
   * Transport selector. When it is absent, a `command` means stdio and a
   * `url` means the transport its scheme names; with both, it is required.
   * When it is set, it decides which of the two is used and must agree with
   * it: `'stdio'` needs a `command`, `'websocket'` a ws(s):// url and
   * `'http'` an http(s):// url.
   */
  transport?: 'stdio' | 'websocket' | 'http';

  /**
   * Protocol family for a stdio (`command`) server. Defaults to `'legacy'`,
   * which is MCP 2024-11-05 + MCPL and today's behavior. `'modern'` speaks
   * MCP 2026-07-28 through the SDK-backed modern engine. A network server's
   * family comes from its url's scheme, so setting this on one is a
   * configuration error. There is no probing between families.
   */
  protocol?: 'legacy' | 'modern';

  /**
   * Bearer token for a network server. Where it travels depends on the
   * transport: on a ws(s):// url it is appended as a `token` query parameter
   * (`?token=…`) on connect, unless `tokenTransport` is `'header'`; to an
   * http(s):// server it is sent as an `Authorization: Bearer` header and
   * never put in the url. A legacy stdio server ignores it, and a modern
   * stdio server refuses it.
   */
  token?: string;

  /**
   * How a ws(s):// server's credential, `token` or what `accessProvider`
   * returns for the dial, is sent on the WebSocket upgrade. `'query'`, the
   * default: as a `token` query parameter (`?token=…`). `'header'`: as an
   * `Authorization: Bearer …` header, with no query parameter, so the
   * credential stays out of the url and of the access logs that record it.
   * A header carries a credential as configured only if it is printable
   * ASCII (U+0020 to U+007E) with no space at either end, so header mode
   * refuses any other: a static `token` when the server is added, an access
   * provider's at the dial. Set only on a WebSocket server; an http(s)://
   * server always sends the header, and a stdio server sends no credential.
   * `null` counts as not set.
   */
  tokenTransport?: 'query' | 'header';

  /**
   * Lazily resolves the connection credential at EVERY dial — first connect
   * and each background reconnect — overriding `token` when it returns a
   * value (null/throw falls back to `token`). Host-attached plumbing, never
   * serialized: the point is that credentials stay out of the agent's
   * context entirely (the agent asks for access by name; the host fetches
   * something fresh each redial, which also makes short-lived credentials
   * viable where a static `token` forced long ones).
   */
  accessProvider?: () => Promise<string | null>;

  /**
   * Host-owned authority for the `host/command` admin surface (undo / hide /
   * unstick). DEFAULT FALSE: no §6.2 capability path exists for it, and the
   * grant cannot confer it — only this config, decided by the operator, can
   * (PR #79 review blocker 9). The one legitimate fleet user is
   * discord-mcpl's slash-command relay. Only `true` turns it on, and null
   * counts as not set. `create()`, `connectMcplServer` and
   * `restartMcplServer` refuse any other value, such as a quoted "true".
   */
  allowHostCommands?: boolean;

  /**
   * Feature sets to enable on connect (`.`-segment wildcards). Omitted:
   * every declared set is a candidate. `[]`: none. Either way a set is
   * enabled only if its declared `uses` are recognized capabilities the
   * grant covers (§6.4) — a set declaring no `uses` stays disabled even when
   * listed here (logged, and traced as `mcpl:feature-set-disabled`).
   */
  enabledFeatureSets?: string[];

  /** Feature sets to explicitly disable on connect (wins over enabledFeatureSets). */
  disabledFeatureSets?: string[];

  /**
   * Tool allow-list (bare tool names as the server exports them, no toolPrefix).
   * Supports `*` as a substring wildcard (e.g. `read_*`, `*_file`, `*`).
   * If set, only tools matching at least one pattern are exposed.
   * `disabledTools` takes precedence on conflict.
   *
   * Filter is applied in two places: at tool-list time (model never sees the
   * tool) and at dispatch time (call rejected with a tool-result error, in
   * case the model imitates a prior call from message history).
   */
  enabledTools?: string[];

  /**
   * Tool deny-list (bare tool names, same wildcard syntax as enabledTools).
   * Wins over enabledTools on conflict.
   */
  disabledTools?: string[];

  /**
   * Capability allow-list: dotted paths as the server advertises them in its
   * initialize response (`pushEvents`, `contextHooks.beforeInference`,
   * `contextHooks.afterInference`, `inferenceRequest`, `modelInfo`,
   * `channels`, `channels.streaming`, …). `*` matches one dot-segment
   * (feature-set pattern rules), and a pattern matching a parent
   * (`contextHooks`) covers every flag beneath it.
   *
   * If set, only advertised capabilities matching at least one pattern
   * survive the handshake; everything else behaves as if the server had
   * never advertised it. This is the host-side gate on hook fan-out: a
   * server whose `contextHooks.afterInference` is masked never receives
   * turn text, no matter what it self-advertises. Masked server-initiated
   * capabilities (`pushEvents`, `inferenceRequest`, whole-`channels`) are
   * also enforced inbound — the connection rejects those methods with
   * CAPABILITY_DISABLED (-32002).
   *
   * `disabledCapabilities` takes precedence on conflict. `version` and
   * `featureSets` are not maskable here — feature sets have their own
   * enable/disable knobs above — and neither are RFC-014's `toolHints`,
   * `toolsets` and `surface`, which a server's own `toolHints` config turns
   * off.
   */
  enabledCapabilities?: string[];

  /**
   * Capability deny-list (same paths and wildcard syntax as
   * enabledCapabilities). Wins over enabledCapabilities on conflict.
   * `disabledCapabilities: ['contextHooks.*']` is the one-line "this server
   * gets no hook visibility" switch.
   */
  disabledCapabilities?: string[];

  /** Scope configurations per feature set */
  scopes?: Record<string, ScopeConfig>;

  /**
   * Enable automatic reconnection on unexpected disconnect or handshake failure.
   * When true, connect() resolves immediately (with null capabilities) if the
   * server is unavailable, and retries in the background.
   * Adapted from Anarchid/agent-framework@mcpl-module-proto.
   * Only `true` turns it on, and null counts as not set. `create()`,
   * `connectMcplServer` and `restartMcplServer` refuse any other value, such
   * as a quoted "false".
   */
  reconnect?: boolean;

  /**
   * Base interval between reconnection attempts in milliseconds.
   * The actual delay doubles with each consecutive failure (with ±25% jitter)
   * up to `reconnectMaxIntervalMs`, and resets after a successful handshake.
   * Default: 5000 (5 seconds).
   */
  reconnectIntervalMs?: number;

  /**
   * Ceiling for the exponential reconnect backoff in milliseconds.
   * Default: 300000 (5 minutes).
   */
  reconnectMaxIntervalMs?: number;

  /**
   * Per-request timeout in milliseconds for outbound JSON-RPC requests
   * (tools/call, tools/list, channels/*, hooks). A live-but-stuck server that
   * accepts a request and never responds would otherwise freeze the awaiting
   * agent turn forever; with the timeout the pending request rejects with a
   * descriptive error, which the framework surfaces as a normal isError
   * tool_result. Request timeouts are the only bound for a stdio server that
   * stops reading its stdin without closing it: the host's writes are
   * buffered, no error is raised, and the connection stays up. Under Bun they
   * are also the only bound for one that closes its stdin, since Bun emits no
   * 'error' event for the writes to it. requestTimeoutMs is the timeout of
   * every request that names none; the handshake's initialize has its own.
   * Set 0 to disable, except for channels/publish, channels/open and
   * channels/close, which keep the 60 s default: a publish's outcome is
   * reported to the resident and recorded for its draft, so it must end, and
   * a delivery waits for a channel's queued opens and closes.
   * Default: 60000 (60 seconds). A value above 2^31−1 is refused: Node runs a
   * longer timer after about 1 ms, so every request would time out at once.
   *
   * For a modern server it is one deadline per tool call, across every leg
   * of the call, and must be an integer from 1 to 2^31−1. It can't be
   * disabled: the SDK reads 0 as "time out now". At the deadline
   * cancellation is requested and the outcome is unknown.
   */
  requestTimeoutMs?: number;

  /**
   * Optional callback to filter which incoming channel messages should trigger
   * agent inference. Receives the text content and message metadata.
   * Return true to trigger inference, false to silently accept the message.
   *
   * Common metadata fields servers may provide:
   * - mentionIds: string[] — user IDs mentioned in the message
   * - replyToAuthorId: string — user ID of the author being replied to
   * - botUserId: string — the server's bot/self user ID
   *
   * If not provided, all incoming messages trigger inference.
   */
  shouldTriggerInference?: (content: string, metadata: Record<string, unknown>) => boolean;

  /**
   * Tool name prefix for this server's tools.
   * Tools are exposed as `{toolPrefix}--{toolName}`.
   *
   * Default: `mcpl--{id}` (e.g., `mcpl--zk--lobby_start_game`).
   * Set to the server ID for cleaner names (e.g., `toolPrefix: 'zk'`
   * gives `zk--lobby_start_game`).
   *
   * Tool-name patterns elsewhere (`toolClassOverrides` keys,
   * `toolLifecycle.*.tools`) match these full names; `enabledTools` /
   * `disabledTools` use the bare server-side names.
   *
   * Must not equal any module name or another server's prefix, nor meet
   * another server's prefix: two prefixes meet when one is the other
   * followed by `-`, or begins with the other followed by `--`, as `foo-`
   * and `foo--bar` each meet `foo` (prefixesMeet, #265).
   */
  toolPrefix?: string;

  /**
   * @deprecated One-time migration input for an installation's old auto,
   * manual, or allow-list policy. Runtime lifecycle state is persisted in
   * Chronicle and changed with channel_open/channel_close.
   */
  channelSubscription?: 'auto' | 'manual' | string[];
  /** RFC-005 autofetch envelope for this server: per-fetch eager ceiling and
   *  cumulative per-server byte budget (reference-fetcher.ts defaults apply
   *  when absent). */
  autofetch?: { maxBytes?: number; maxTotalBytes?: number };

  /**
   * RFC-007 tool lifecycle policy for this server: narrowing for the
   * `toolLifecycle.observe` and `toolLifecycle.inputs` grants, and the
   * `input` size bound. Both paths are DENIED BY DEFAULT; stating a key here
   * (or naming the path in enabledCapabilities) is the explicit grant.
   * `inputs` without a `tools` or `classes` term delivers no arguments, and
   * `comms` or unclassed tools never carry arguments whatever it says.
   * See src/mcpl/tool-lifecycle.ts.
   */
  toolLifecycle?: import('./tool-lifecycle.js').ToolLifecycleConfig;

  /**
   * MCPL RFC-014 (tool presence, toolsets and surfaces). On unless set to
   * `false`: the host advertises `experimental.mcpl.toolHints` and honours
   * hints (through the `toolsets` meta-tools) only from a server that
   * advertised `toolHints` too. Such a server's static tools stay in the tool
   * list as before, and its dynamic tools (toolset tools, `mcpl/presence:
   * "dynamic"`) leave it: they are announced in the conversation as they
   * become visible and invisible, and called through `toolsets--act`, opened
   * with `toolsets--open`, inspected with `toolsets--look` and closed with
   * `toolsets--close`. A server that doesn't advertise `toolHints` lists every
   * tool as before. `false` advertises nothing and treats every tool as
   * static. Omitted and null are on unless a module given to `create()`
   * holds the name `toolsets` (or a restart is moving a server to that
   * prefix, which is refused); `true` with such a module is refused.
   */
  toolHints?: boolean;

  /**
   * How this server is presented to agents at first (the host's own
   * toolsets, src/host-presentation.ts): `'full'` (the default) puts its
   * tools in the tool list, as before; `'tab'` keeps it connected, its events
   * still arriving, with none of its tools in the tool list until an agent
   * opens its tab (`toolsets--open {server}`) and calls them through
   * `toolsets--act`; `'closed-tab'` leaves it disconnected until an agent
   * opens it. Each agent can switch it later (`toolsets--close {server}`,
   * with `disconnect: true` for a closed tab; `toolsets--open {server,
   * full: true}` back into the tool list), and that choice is kept across
   * restarts beside the store, over this default.
   */
  presentation?: 'full' | 'tab' | 'closed-tab';
}

// ============================================================================
// Section 6 — Feature Sets
// ============================================================================

/** What a feature set can use. Maps to spec Section 6.2. */
export type FeatureSetUse =
  | 'pushEvents'
  | 'contextHooks.beforeInference'
  | 'contextHooks.afterInference'
  | 'inferenceRequest'
  | 'tools'
  | 'channels.publish'
  | 'channels.observe';

/**
 * A feature set declaration as advertised by a server.
 * Spec Section 6.1.
 */
export interface FeatureSetDeclaration {
  /** Human-readable description */
  description: string;

  /** Capabilities this feature set uses */
  uses: FeatureSetUse[];

  /** Whether this feature set uses scoped access (Section 7) */
  scoped?: boolean;

  /** Whether server supports rollback for this feature set (Section 8.1) */
  rollback?: boolean;

  /** Whether host manages state persistence for this feature set (Section 8.1) */
  hostState?: boolean;

  /** Optional, open-world tag ontology for this feature set's events
   *  (MCPL RFC-001 §5). A hint catalog — hosts tolerate undeclared tags. */
  tagOntology?: {
    coreTags?: string[];
    tags?: Record<string, unknown>;
    keyed?: Record<string, unknown>;
    defaultTreatment?: unknown[];
    open?: boolean;
  };
}

/**
 * featureSets/update params (Host → Server, Notification).
 * Spec Section 6.7.
 */
export interface FeatureSetsUpdateParams {
  /**
   * The effective capability grant (§5.4) — the sole normative allowlist.
   * Full §6.2 paths. Absence of a path is denial. In the Request form an
   * absent FIELD is a grant of nothing (§5.3 as pinned 2026-08-02), never
   * "no change".
   */
  effectiveCapabilities?: string[];

  /** Advertised-but-denied paths. Diagnostic only (§5.4) — MUST NOT
   *  participate in any authorization decision on either side. */
  deniedCapabilities?: string[];

  /** Feature sets to enable. Absent = no constraint (derivation governs);
   *  present = allowlist (§5.3 as pinned). */
  enabled?: string[];

  /** Feature sets to disable */
  disabled?: string[];
}

/**
 * featureSets/update result — the degradation receipt (§6.7). Consequence
 * testimony, never policy authority: the host MUST NOT widen any grant in
 * response to anything in here.
 */
export type FeatureSetsUpdateResult =
  | {
      accepted: true;
      /** Omitted when nothing degraded (§6.7). */
      mode?: 'degraded';
      unavailableFeatures?: Array<{
        featureSet: string;
        missingCapabilities: string[];
        effect: string;
      }>;
      notes?: string[];
    }
  | {
      accepted: false;
      /** REQUIRED on refusal (§6.7): the server names which applies. */
      fallback: 'mcp-only' | 'close';
      missingCapabilities?: string[];
      reason?: string;
    };

/**
 * featureSets/changed params (Server → Host, Notification).
 * Spec Section 6.7.
 */
export interface FeatureSetsChangedParams {
  /** Newly available feature sets */
  added?: Record<string, FeatureSetDeclaration>;

  /** Removed feature set names */
  removed?: string[];
}

// ============================================================================
// Section 7 — Scoped Access
// ============================================================================

/**
 * Scope configuration for a feature set — whitelist/blacklist patterns.
 * Pattern matching semantics (glob, regex, exact) are host-defined.
 */
export interface ScopeConfig {
  /** Patterns that are pre-approved */
  whitelist?: string[];

  /** Patterns that are always denied */
  blacklist?: string[];
}

/**
 * A scope label with optional payload, as used in scope/elevate and tools/call.
 * Spec Section 7.3.
 */
export interface ScopeLabel {
  /** Human-readable identifier for whitelist/blacklist matching */
  label: string;

  /** Arbitrary data passed back to server when approved */
  payload?: Record<string, unknown>;
}

/**
 * scope/elevate params (Server → Host, Request).
 * Spec Section 7.4.
 */
export interface ScopeElevateParams {
  /** Feature set requesting elevation */
  featureSet: string;

  /** The scope being requested */
  scope: ScopeLabel;
}

/**
 * scope/elevate result (Host → Server).
 * Spec Section 7.5.
 */
export interface ScopeElevateResult {
  /** Whether the scope was approved */
  approved: boolean;

  /** The payload from the request, returned on approval */
  payload?: Record<string, unknown>;

  /** Present if approved: false */
  reason?: string;
}

// ============================================================================
// Section 8 — State Management
// ============================================================================

/**
 * Checkpoint information returned in tool call responses.
 * Spec Section 8.2.
 */
export interface StateCheckpoint {
  /** Checkpoint identifier */
  checkpoint: string;

  /** Parent checkpoint (null for root) */
  parent: string | null;

  /**
   * Owning feature set, when the server tags it. Authoritative signal for
   * attributing this checkpoint — lets the host record it to the right set
   * instead of guessing when a server has more than one stateful feature set.
   */
  featureSet?: string;

  /**
   * Full state data (for host-managed state).
   * Mutually exclusive with `patch`.
   */
  data?: unknown;

  /**
   * JSON Patch (RFC 6902) delta from parent (for host-managed state).
   * Mutually exclusive with `data`.
   */
  patch?: JsonPatchOperation[];
}

/**
 * JSON Patch operation (RFC 6902).
 */
export interface JsonPatchOperation {
  op: 'add' | 'remove' | 'replace' | 'move' | 'copy' | 'test';
  path: string;
  value?: unknown;
  from?: string;
}

/**
 * state/rollback params (Host → Server, Request).
 * Spec Section 8.5.
 */
export interface StateRollbackParams {
  /** Feature set to rollback */
  featureSet: string;

  /** Checkpoint to rollback to */
  checkpoint: string;
}

/**
 * state/rollback result (Server → Host).
 * Spec Section 8.6.
 */
export interface StateRollbackResult {
  /** Checkpoint that was rolled back to */
  checkpoint: string;

  /** Whether rollback succeeded */
  success: boolean;

  /** Reason for failure (present if success: false) */
  reason?: string;
}

// ============================================================================
// Section 9 — Push Events
// ============================================================================

/**
 * push/event params (Server → Host, Request).
 * Spec Section 9.1.
 */
export interface PushEventParams {
  /** RFC-006 event coalescing (mcpl PR #5, revision 7). */
  coalesce?: {
    /** Subject key, 1..256 UTF-8 bytes, opaque to the host. */
    key: string;
    /** push/event only: address a registered channel's subject namespace. */
    channelId?: string;
    /** push/event only: deferred mode — the host calls push/render at assembly. */
    deferred?: boolean;
    /** The subject ceased to exist; `payload.content` is the deletion notice. */
    retract?: boolean;
    /** No earlier occurrence of this subject was ever sent (§3.3). */
    initial?: boolean;
    /** deferred only; ≤ 4 KiB serialized; server-private, echoed by push/render. */
    data?: unknown;
  };
  /** Declaring feature set */
  featureSet: string;

  /** Unique event identifier (for idempotency) */
  eventId: string;

  /** When the event occurred (ISO 8601) */
  timestamp: string;

  /** Provenance metadata (server-defined) */
  origin?: Record<string, unknown>;

  /** Semantic classification the host may route on (MCPL RFC-001). */
  tags?: string[];

  /** Event payload */
  payload: {
    /** Content for the model to interpret */
    content: McplContentBlock[];
  };
}

/**
 * push/event result (Host → Server).
 * Spec Section 9.3.
 */
export interface PushEventResult {
  coalesce?: {
    outcome: 'first' | 'replaced' | 'appended' | 'retracted' | 'noted' | 'consumed';
    priorEventId?: string;
  };
  /** Whether the event was accepted */
  accepted: boolean;

  /** Present if inference was triggered */
  inferenceId?: string;

  /** Present if accepted: false */
  reason?: string;
}

// ============================================================================
// Section 10 — Context Hooks
// ============================================================================

/**
 * Model information as provided in context hook calls.
 * Distinct from membrane's ModelInfo which tracks requested vs actual model.
 * Spec Section 10.1.
 */
/**
 * inference/lifecycle params (Host → Server, Notification). SPEC §10.5.
 *
 * BEST-EFFORT: the host attempts exactly one terminal phase per `started`
 * on every exit path it controls, but an unacknowledged Notification cannot
 * guarantee delivery — consumers MUST dedupe by inferenceId and MUST retain
 * a safety timeout. Carries no content: `modifiedResponse` and the blocking
 * hook form are gone with context/afterInference.
 */
export interface InferenceLifecycleParams {
  inferenceId: string;
  conversationId: string;
  turnIndex: number;
  phase: 'started' | 'completed' | 'aborted' | 'failed';
}

/** mcpl/manifestChanged params (Server → Host, Notification). §17.3. */
export interface ManifestChangedParams {
  /** §17.2 canonical content digest. Untrusted; equality-only. */
  revision: string;
  /** Subset of the three §17.1 domains. A hint the host MAY ignore. */
  domains: Array<'capabilities' | 'featureSets' | 'tagOntology'>;
}

export interface McplModelInfo {
  /** Model identifier (e.g., "claude-opus-4-5-20251101") */
  id: string;

  /** Model vendor (e.g., "anthropic"). Omitted when the host has no
   *  truthful source — never fabricated. */
  vendor?: string;

  /** Context window size in tokens. Omitted when unknown (a numeric field
   *  cannot express "unknown", and a fabricated 200000 was false for
   *  residents configured at 300k/600k — PR #79 review). The §12.2
   *  model/info RESULT requires it, which is why this host does not
   *  advertise modelInfo; hook params carry honesty-over-completeness. */
  contextWindow?: number;

  /** Model capabilities (e.g., ["vision", "tools"]). Omitted when the
   *  host has no truthful source. */
  capabilities?: string[];
}

/**
 * context/beforeInference params (Host → Server, Request).
 * Spec Section 10.1.
 */
export interface BeforeInferenceParams {
  /** Unique identifier for this inference */
  inferenceId: string;

  /** Persistent across turns */
  conversationId: string;

  /** 0-indexed turn number */
  turnIndex: number;

  /** User input (null for continued generation) */
  userMessage: string | null;

  /** Current model metadata */
  model: McplModelInfo;

  /** Channel context (Section 14.4, optional) */
  channels?: ChannelContext;
}

/**
 * A context injection as returned by an MCPL server.
 * This is the wire format — it gets converted to context-manager's
 * ContextInjection (which uses membrane ContentBlock[]) by the host.
 * Spec Section 10.4.
 */
export interface McplContextInjection {
  /** Server-defined namespace */
  namespace: string;

  /** Where to inject */
  position: 'system' | 'beforeUser' | 'afterUser';

  /**
   * Content to inject.
   * May be a plain string (shorthand for a single text block) or content blocks.
   */
  content: string | McplContentBlock[];

  /** Arbitrary metadata (passed through) */
  metadata?: Record<string, unknown>;
}

/**
 * context/beforeInference result (Server → Host).
 * Spec Section 10.2.
 */
export interface BeforeInferenceResult {
  /** Feature set that provided this response */
  featureSet: string;

  /** Context injections to apply */
  contextInjections: McplContextInjection[];
}

// ============================================================================
// Section 11 — Server-Initiated Inference
// ============================================================================

/**
 * A message in an MCPL inference request.
 * Simpler than membrane's NormalizedMessage — just role + content string.
 */
export interface McplMessage {
  role: 'user' | 'assistant';
  content: string;
}

/**
 * inference/request params (Server → Host, Request).
 * Prefixed to avoid collision with API's InferenceRequestParams.
 * Spec Section 11.1.
 */
export interface McplInferenceRequestParams {
  /** Declaring feature set */
  featureSet: string;

  /** Associate with conversation (optional) */
  conversationId?: string;

  /** Stream response (default: false) */
  stream?: boolean;

  /** Messages for inference */
  messages: McplMessage[];

  /** Advisory preferences (host may ignore) */
  preferences?: McplInferencePreferences;
}

/**
 * Advisory preferences for server-initiated inference.
 * Spec Section 11.2.
 */
export interface McplInferencePreferences {
  /** Max output tokens */
  maxTokens?: number;

  /** Sampling temperature */
  temperature?: number;

  /**
   * Additional advisory keys (e.g., model, modelTier, costTier).
   * Host-defined and not guaranteed to be honored.
   */
  [key: string]: unknown;
}

/**
 * inference/request result (Host → Server).
 * Spec Section 11.3.
 */
export interface McplInferenceRequestResult {
  /** Generated content */
  content: string;

  /** Actual model used */
  model: string;

  /** Why generation stopped */
  finishReason: 'end_turn' | 'max_tokens' | 'stop_sequence';

  /** Token usage */
  usage: {
    inputTokens: number;
    outputTokens: number;
  };
}

/**
 * inference/chunk params (Host → Server, Notification).
 * Sent during streaming inference.
 * Spec Section 11.4.
 */
export interface InferenceChunkParams {
  /** ID of the original inference/request */
  requestId: string | number;

  /** Chunk index (0-based) */
  index: number;

  /** Text delta */
  delta: string;
}

// ============================================================================
// Section 12 — Model Information
// ============================================================================

// model/info has no params (empty object).
// The result reuses McplModelInfo.

// ============================================================================
// Section 14 — Channels
// ============================================================================

/**
 * Descriptor for a channel registered by an MCPL server.
 * Spec Section 14.2.
 */
export interface ChannelDescriptor {
  /** Unique within this connection (e.g., "discord:#general") */
  id: string;

  /** Platform/provider type (e.g., "discord", "telegram", "ui") */
  type: string;

  /** Human-readable label */
  label: string;

  /** Message direction */
  direction: 'outbound' | 'inbound' | 'bidirectional';

  /** Platform-specific address (e.g., { guild: "acme", channel: "#general" }) */
  address?: Record<string, unknown>;

  /** Arbitrary metadata */
  metadata?: Record<string, unknown>;

  /**
   * Server bootstrap preference, consulted only when the host has no durable
   * desired state for this channel.
   */
  initiallyOpen?: boolean;

  /** Optional generic capabilities exposed by this channel. */
  capabilities?: ChannelCapabilities;
}

export interface ChannelCapabilities {
  history?: {
    maxMessages?: number;
    supportsBeforeMessage?: boolean;
    supportsSinceLastSeen?: boolean;
  };
  acknowledgment?: {
    kind?: string;
    supportsValue?: boolean;
  };
  /**
   * Outgoing streaming this channel takes beyond §14.3's. `speculative`: the
   * host may stream the text of a `channel_publish` call to this channel
   * while the model is still writing it, before the publish
   * (ChannelsOutgoingSpeculativeChunkParams), when the agent has
   * speculativeChannelChunks on. docs/speculative-channel-chunks.md.
   */
  streaming?: {
    speculative?: boolean;
  };
}

export interface ChannelHistoryRequest {
  limit: number;
  beforeMessageId?: string;
  sinceLastSeen?: boolean;
}

/**
 * Channel context included in beforeInference params.
 * Spec Section 14.4.
 */
export interface ChannelContext {
  /** Channel that triggered this inference */
  incoming?: {
    channelId: string;
    messageId: string;
    threadId?: string;
  };

  /** Default channel for outgoing messages */
  defaultOutgoing?: {
    channelId: string;
  };

  /** All candidate channels for this inference */
  candidates?: string[];
}

/**
 * channels/register params (Server → Host, Request).
 * Spec Section 14.3.
 */
export interface ChannelsRegisterParams {
  channels: ChannelDescriptor[];
}

/**
 * channels/register result (Host → Server).
 */
export interface ChannelsRegisterResult {
  /** Legacy pre-0.5 field: ids accepted. Kept for un-migrated servers. */
  registered: string[];
  /**
   * §14.5 itemized results — one entry per SUBMITTED descriptor. 0.5
   * servers key off this: a missing verdict is not a verdict, and a result
   * without `results` is read by strict servers as accepting nothing.
   */
  results: Array<{ id: string; accepted: boolean; reason?: string }>;
}

/**
 * channels/changed params (Server → Host, Notification).
 * Spec Section 14.3.
 */
export interface ChannelsChangedParams {
  added?: ChannelDescriptor[];
  removed?: string[];
  updated?: ChannelDescriptor[];
}

/**
 * channels/list result (Either direction, Request).
 * Spec Section 14.3.
 */
export interface ChannelsListResult {
  channels: ChannelDescriptor[];
}

/**
 * channels/open params (Host → Server, Request).
 * Spec Section 14.3.
 */
export interface ChannelsOpenParams {
  /**
   * The exact registered id to open. Without it, a server matches by `type`
   * and `address`, as before. A server that doesn't know the id should
   * refuse rather than open another channel: the host fails an open whose
   * answer names a different channel id, by its `channel.id` or a history
   * item's `channelId`, compared exactly, as the server's traffic is. When
   * that other channel is registered and decided closed, the host closes it
   * again.
   */
  channelId?: string;
  type: string;
  address?: Record<string, unknown>;
  metadata?: Record<string, unknown>;
  history?: ChannelHistoryRequest;
}

/**
 * channels/open result (Server → Host).
 */
export interface ChannelsOpenResult {
  channel: ChannelDescriptor;
  history?: ChannelIncomingMessage[];
  historyTruncated?: boolean;
}

/**
 * channels/close params (Host → Server, Request).
 * Spec Section 14.3.
 */
export interface ChannelsCloseParams {
  channelId: string;
}

/**
 * channels/close result (Server → Host).
 */
export interface ChannelsCloseResult {
  closed: boolean;
}

export interface ChannelsAcknowledgeParams {
  channelId: string;
  messageId: string;
  intent: string;
  value?: string;
}

export interface ChannelsAcknowledgeResult {
  acknowledged: boolean;
  representation?: string;
  reason?: string;
}

/**
 * channels/outgoing/chunk params (Host → Server, Notification).
 * For observers receiving moderated deltas.
 * Spec Section 14.3.
 */
export interface ChannelsOutgoingChunkParams {
  inferenceId: string;
  conversationId: string;
  channelId: string;
  index: number;
  delta: string;
}

/**
 * channels/outgoing/complete params (Host → Server, Notification).
 * For observers receiving final moderated content.
 * Spec Section 14.3.
 */
export interface ChannelsOutgoingCompleteParams {
  inferenceId: string;
  conversationId: string;
  channelId: string;
  content: McplContentBlock[];
}

/**
 * channels/outgoing/chunk params of a speculative stream (Host → Server,
 * Notification), to a channel whose capabilities have
 * `streaming.speculative`: a delta of the text of a `channel_publish` call
 * the model is still writing, sent before the publish and before anything
 * says the call will run. docs/speculative-channel-chunks.md.
 */
export interface ChannelsOutgoingSpeculativeChunkParams {
  channelId: string;
  /** The stream's id: the same on its chunks, its complete and its publish. */
  streamId: string;
  /** 0, 1, 2… in the order sent. */
  seq: number;
  /** The new text since the previous chunk. */
  content: string;
  speculative: true;
  /** The agent whose call this is. */
  conversationId: string;
}

/**
 * channels/outgoing/complete params ending a speculative stream (Host →
 * Server, Notification): its publish was delivered, with the full text, or
 * the stream is `cancelled` (the call was cut off, refused, failed, never
 * ran, or published elsewhere) with empty content.
 */
export interface ChannelsOutgoingSpeculativeCompleteParams {
  channelId: string;
  streamId: string;
  content: string;
  speculative: true;
  cancelled?: true;
  conversationId: string;
}

/**
 * channels/publish params (Host → Server, Notification or Request).
 * Asks connector server to deliver content to a channel.
 * Spec Section 14.3.
 */
export interface ChannelsPublishParams {
  conversationId: string;
  channelId: string;
  stream?: boolean;
  content: McplContentBlock[];
  /** The speculative stream this publish's text went out in, ahead of it
   *  (ChannelsOutgoingSpeculativeChunkParams), so the server can match the
   *  two. Only on a publish that had one. */
  streamId?: string;
}

/**
 * channels/publish result (Server → Host, when sent as Request).
 */
export interface ChannelsPublishResult {
  delivered: boolean;
  messageId?: string;
}

/**
 * A single inbound message from a channel.
 * Used inside channels/incoming params.
 * Spec Section 14.3.
 */
export interface ChannelIncomingMessage {
  eventId?: string;
  coalesce?: Omit<NonNullable<PushEventParams['coalesce']>, 'channelId' | 'deferred'>;
  /** Channel this message came from */
  channelId: string;

  /** Unique message ID from the platform */
  messageId: string;

  /** Thread/conversation ID within the channel */
  threadId?: string;

  /** Message author */
  author: {
    id: string;
    name: string;
  };

  /** When the message was sent (ISO 8601) */
  timestamp: string;

  /** Message content */
  content: McplContentBlock[];

  /** Platform-specific metadata */
  metadata?: Record<string, unknown>;

  /** Semantic classification the host may route on (MCPL RFC-001). */
  tags?: string[];
}

/**
 * channels/incoming params (Server → Host, Request).
 * Supports batching for busy channels.
 * Spec Section 14.3.
 */
export interface ChannelsIncomingParams {
  messages: ChannelIncomingMessage[];
}

/**
 * channels/incoming result (Host → Server).
 * Per-message results for partial acceptance.
 */
export interface ChannelsIncomingResult {
  results: ChannelIncomingMessageResult[];
}

/** Result for a single incoming message. */
export interface ChannelIncomingMessageResult {
  coalesce?: PushEventResult['coalesce'];
  messageId: string;
  accepted: boolean;
  conversationId?: string;
  /** §14.5: why a message was rejected (e.g. unknown/unregistered channel). */
  reason?: string;
}

// ============================================================================
// Section 11.5 — Inference Routing Policy (Host Configuration)
// ============================================================================

/**
 * Policy for routing server-initiated inference requests to models.
 * Non-normative; host-defined. See Spec Section 11.5.
 */
export interface InferenceRoutingPolicy {
  /** Model for a request no override, byFeature or wildcards entry names a
   *  model for. Left empty, such a request is refused with -32603. */
  default: string;

  /** Model override per feature set name */
  byFeature?: Record<string, string>;

  /** Model override per pattern (e.g., "memory.*" → "claude-haiku-4-5") */
  wildcards?: Record<string, string>;

  /** Model override per conversation ID */
  overrides?: Record<string, string>;
}

// ============================================================================
// MCPL Method Names (string constants for routing)
// ============================================================================

/** All MCPL method names as defined in the spec. */
export const McplMethod = {
  // Push events (Server → Host)
  PushEvent: 'push/event',

  // Context hooks (Host → Server). context/afterInference is gone with the
  // rest of its surface: removed from the spec in 0.5.0 (§10.5, replaced by
  // inference/lifecycle), never sent by the runtime, and not part of the
  // package's public API. Pre-0.5 SERVERS' wire handlers for it are their
  // own compatibility surface, retired on the fleet-on-0.5 evidence
  // schedule, not here.
  BeforeInference: 'context/beforeInference',

  // Server-initiated inference (Server → Host / Host → Server)
  InferenceRequest: 'inference/request',
  InferenceChunk: 'inference/chunk',

  // Model info (Server → Host)
  ModelInfo: 'model/info',

  // Inference lifecycle (Host → Server, Notification) — §10.5, replaces
  // context/afterInference. Metadata only; BEST-EFFORT delivery.
  InferenceLifecycle: 'inference/lifecycle',

  // Tool lifecycle (RFC-007). tools/lifecycle is Host → Server,
  // Notification, metadata plus (under its own grant) requested argument
  // fields — never results. tools/observe is Server → Host, Request: the
  // server's filter over what it is sent (interest, never authority).
  ToolsLifecycle: 'tools/lifecycle',
  ToolsObserve: 'tools/observe',

  // Server manifest changes (§17). manifestChanged is S→H Notification —
  // an opaque revision plus changed domains, NO payload, deliberately
  // ungated (§17.3: gating it would silence exactly the servers whose
  // grants just narrowed). manifest is H→S Request returning the complete
  // current experimental.mcpl object, never a delta.
  ManifestChanged: 'mcpl/manifestChanged',
  Manifest: 'mcpl/manifest',

  // Feature sets
  FeatureSetsUpdate: 'featureSets/update',
  FeatureSetsChanged: 'featureSets/changed',

  // Scoped access (Server → Host)
  ScopeElevate: 'scope/elevate',

  // State management (Host → Server)
  StateRollback: 'state/rollback',

  // Channels
  ChannelsRegister: 'channels/register',
  ChannelsChanged: 'channels/changed',
  ChannelsList: 'channels/list',
  ChannelsOpen: 'channels/open',
  ChannelsClose: 'channels/close',
  ChannelsAcknowledge: 'channels/acknowledge',
  ChannelsOutgoingChunk: 'channels/outgoing/chunk',
  ChannelsOutgoingComplete: 'channels/outgoing/complete',
  ChannelsPublish: 'channels/publish',
  ChannelsIncoming: 'channels/incoming',
  ChannelsTyping: 'channels/typing',
} as const;

export type McplMethodName = (typeof McplMethod)[keyof typeof McplMethod];

// ============================================================================
// MCP Standard Methods (not MCPL-specific, but needed for tool integration)
// ============================================================================

/**
 * Standard MCP tool definition as returned by `tools/list`.
 */
export interface McpToolDefinition {
  name: string;
  description?: string;
  inputSchema: Record<string, unknown>;
  /** Server metadata for the tool (e.g. RFC-008 `mcpl/class` hints). */
  _meta?: Record<string, unknown>;
}

/**
 * Standard MCP `tools/call` result.
 */
export interface McpToolCallResult {
  content: McpToolResultContent[];
  isError?: boolean;
  /** State checkpoint returned by stateful tools (Section 8.2). */
  state?: StateCheckpoint;
}

/**
 * A single content block in an MCP tool result.
 */
export interface McpToolResultContent {
  type: 'text' | 'image' | 'resource';
  text?: string;
  data?: string;
  mimeType?: string;
  uri?: string;
  /** RFC-005 §3 reference testimony (uri form only; server claims). */
  sizeBytes?: number;
  digest?: string;
  expiresAt?: string;
  name?: string;
  disposition?: 'never' | 'ref';
}
